This zip archive contains data files from Cricsheet in JSON format. This
archive contains 4163 female matches.


The JSON data files contained in this zip file are version 1.0.0, and 1.1.0
files. You can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/all_female_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-03-20 - international - T20 - female - 1526693 - Rwanda vs Ghana
2026-03-20 - international - T20 - female - 1491707 - South Africa vs New Zealand
2026-03-19 - international - T20 - female - 1526564 - Australia vs West Indies
2026-03-17 - international - T20 - female - 1491706 - South Africa vs New Zealand
2026-03-15 - international - T20 - female - 1491705 - New Zealand vs South Africa
2026-03-11 - international - ODI - female - 1491704 - New Zealand vs Zimbabwe
2026-03-08 - international - ODI - female - 1491703 - Zimbabwe vs New Zealand
2026-03-06 - international - Test - female - 1478918 - India vs Australia
2026-03-05 - international - ODI - female - 1491702 - New Zealand vs Zimbabwe
2026-03-03 - international - T20 - female - 1523983 - West Indies vs Sri Lanka
2026-03-01 - international - T20 - female - 1523982 - West Indies vs Sri Lanka
2026-03-01 - international - T20 - female - 1491701 - Zimbabwe vs New Zealand
2026-03-01 - international - ODI - female - 1478917 - Australia vs India
2026-03-01 - international - ODI - female - 1477603 - Pakistan vs South Africa
2026-02-28 - international - T20 - female - 1523981 - West Indies vs Sri Lanka
2026-02-27 - international - T20 - female - 1491700 - New Zealand vs Zimbabwe
2026-02-27 - international - ODI - female - 1478916 - India vs Australia
2026-02-25 - international - T20 - female - 1491699 - New Zealand vs Zimbabwe
2026-02-25 - international - ODI - female - 1523980 - Sri Lanka vs West Indies
2026-02-25 - international - ODI - female - 1477602 - South Africa vs Pakistan
2026-02-24 - international - ODI - female - 1478915 - India vs Australia
2026-02-22 - international - ODI - female - 1523979 - Sri Lanka vs West Indies
2026-02-22 - international - ODI - female - 1477601 - South Africa vs Pakistan
2026-02-21 - international - T20 - female - 1478914 - India vs Australia
2026-02-20 - international - ODI - female - 1523978 - Sri Lanka vs West Indies
2026-02-19 - international - T20 - female - 1478913 - Australia vs India
2026-02-16 - international - T20 - female - 1477599 - Pakistan vs South Africa
2026-02-15 - international - T20 - female - 1478912 - Australia vs India
2026-02-14 - international - T20 - female - 1522988 - Qatar vs Oman
2026-02-14 - international - T20 - female - 1522068 - Thailand vs Malaysia
2026-02-13 - international - T20 - female - 1522987 - Qatar vs Oman
2026-02-13 - international - T20 - female - 1477598 - Pakistan vs South Africa
2026-02-12 - international - T20 - female - 1522986 - Oman vs Qatar
2026-02-10 - international - T20 - female - 1522985 - Oman vs Qatar
2026-02-10 - international - T20 - female - 1477597 - Pakistan vs South Africa
2026-02-09 - international - T20 - female - 1522984 - Oman vs Qatar
2026-02-07 - international - T20 - female - 1520973 - Oman vs Denmark
2026-02-06 - international - T20 - female - 1520972 - Oman vs Denmark
2026-02-05 - club - WPL - female - 1513703 - Delhi Capitals vs Royal Challengers Bengaluru
2026-02-04 - international - T20 - female - 1520971 - Oman vs Denmark
2026-02-03 - international - T20 - female - 1520970 - Oman vs Denmark
2026-02-03 - club - WPL - female - 1513702 - Gujarat Giants vs Delhi Capitals
2026-02-01 - international - T20 - female - 1515236 - Scotland vs United States of America
2026-02-01 - international - T20 - female - 1515235 - Netherlands vs Bangladesh
2026-02-01 - international - T20 - female - 1515234 - Ireland vs Thailand
2026-02-01 - club - WPL - female - 1513701 - UP Warriorz vs Delhi Capitals
2026-01-31 - club - SSM - female - 1499691 - Auckland vs Wellington
2026-01-30 - international - T20 - female - 1515233 - United States of America vs Thailand
2026-01-30 - international - T20 - female - 1515232 - Ireland vs Netherlands
2026-01-30 - international - T20 - female - 1515231 - Bangladesh vs Scotland
2026-01-30 - club - WPL - female - 1513700 - Gujarat Giants vs Mumbai Indians
2026-01-30 - club - SSM - female - 1499690 - Northern Districts vs Auckland
2026-01-29 - international - T20 - female - 1519152 - Hong Kong vs Bhutan
2026-01-29 - club - WPL - female - 1513699 - UP Warriorz vs Royal Challengers Bengaluru
2026-01-28 - international - T20 - female - 1515230 - United States of America vs Netherlands
2026-01-28 - international - T20 - female - 1515229 - Bangladesh vs Thailand
2026-01-28 - international - T20 - female - 1515228 - Scotland vs Ireland
2026-01-27 - international - T20 - female - 1519151 - Malaysia vs Bhutan
2026-01-27 - club - WPL - female - 1513698 - Gujarat Giants vs Delhi Capitals
2026-01-26 - international - T20 - female - 1519150 - Malaysia vs Hong Kong
2026-01-26 - international - T20 - female - 1515227 - Netherlands vs Thailand
2026-01-26 - international - T20 - female - 1515226 - Namibia vs Ireland
2026-01-26 - international - T20 - female - 1515225 - Papua New Guinea vs United States of America
2026-01-26 - international - T20 - female - 1515224 - Scotland vs Nepal
2026-01-26 - club - WPL - female - 1513697 - Mumbai Indians vs Royal Challengers Bengaluru
2026-01-26 - club - SSM - female - 1499689 - Central Districts vs Auckland
2026-01-25 - international - T20 - female - 1519149 - Hong Kong vs Bhutan
2026-01-25 - club - SSM - female - 1499688 - Northern Districts vs Canterbury
2026-01-24 - international - T20 - female - 1519148 - Malaysia vs Bhutan
2026-01-24 - international - T20 - female - 1515223 - Bangladesh vs Ireland
2026-01-24 - international - T20 - female - 1515222 - Zimbabwe vs Nepal
2026-01-24 - international - T20 - female - 1515221 - Namibia vs Papua New Guinea
2026-01-24 - international - T20 - female - 1515220 - Thailand vs Scotland
2026-01-24 - club - WPL - female - 1513696 - Royal Challengers Bengaluru vs Delhi Capitals
2026-01-24 - club - SSM - female - 1499687 - Central Districts vs Otago
2026-01-23 - club - SSM - female - 1499686 - Wellington vs Canterbury
2026-01-22 - international - T20 - female - 1519147 - Hong Kong vs Bhutan
2026-01-22 - international - T20 - female - 1515219 - Zimbabwe vs Scotland
2026-01-22 - international - T20 - female - 1515218 - Bangladesh vs Namibia
2026-01-22 - international - T20 - female - 1515217 - Netherlands vs Nepal
2026-01-22 - international - T20 - female - 1515216 - Ireland vs United States of America
2026-01-22 - club - WPL - female - 1513695 - Gujarat Giants vs UP Warriorz
2026-01-22 - club - SSM - female - 1499685 - Auckland vs Northern Districts
2026-01-21 - international - T20 - female - 1519146 - Hong Kong vs Malaysia
2026-01-21 - club - SSM - female - 1499684 - Otago vs Canterbury
2026-01-20 - international - T20 - female - 1519145 - Malaysia vs Bhutan
2026-01-20 - international - T20 - female - 1515215 - Namibia vs United States of America
2026-01-20 - international - T20 - female - 1515214 - Netherlands vs Scotland
2026-01-20 - international - T20 - female - 1515213 - Thailand vs Zimbabwe
2026-01-20 - international - T20 - female - 1515212 - Bangladesh vs Papua New Guinea
2026-01-20 - club - WPL - female - 1513694 - Mumbai Indians vs Delhi Capitals
2026-01-19 - club - WPL - female - 1513693 - Royal Challengers Bengaluru vs Gujarat Giants
2026-01-19 - club - SSM - female - 1499682 - Wellington vs Canterbury
2026-01-18 - international - T20 - female - 1515211 - Nepal vs Thailand
2026-01-18 - international - T20 - female - 1515210 - Ireland vs Papua New Guinea
2026-01-18 - international - T20 - female - 1515209 - Bangladesh vs United States of America
2026-01-18 - international - T20 - female - 1515208 - Netherlands vs Zimbabwe
2026-01-18 - club - SSM - female - 1499681 - Otago vs Northern Districts
2026-01-17 - club - WPL - female - 1513692 - Delhi Capitals vs Royal Challengers Bengaluru
2026-01-17 - club - WPL - female - 1513691 - UP Warriorz vs Mumbai Indians
2026-01-16 - club - WPL - female - 1513690 - Royal Challengers Bengaluru vs Gujarat Giants
2026-01-16 - club - SSM - female - 1499680 - Central Districts vs Auckland
2026-01-15 - club - WPL - female - 1513689 - Mumbai Indians vs UP Warriorz
2026-01-15 - club - SSM - female - 1499679 - Wellington vs Otago
2026-01-14 - club - WPL - female - 1513688 - UP Warriorz vs Delhi Capitals
2026-01-14 - club - SSM - female - 1499678 - Canterbury vs Auckland
2026-01-13 - club - WPL - female - 1513687 - Gujarat Giants vs Mumbai Indians
2026-01-13 - club - SSM - female - 1499677 - Northern Districts vs Central Districts
2026-01-12 - club - WPL - female - 1513686 - UP Warriorz vs Royal Challengers Bengaluru
2026-01-12 - club - SSM - female - 1499676 - Auckland vs Otago
2026-01-11 - club - WPL - female - 1513685 - Gujarat Giants vs Delhi Capitals
2026-01-11 - club - SSM - female - 1499675 - Wellington vs Northern Districts
2026-01-10 - club - WPL - female - 1513684 - Mumbai Indians vs Delhi Capitals
2026-01-10 - club - WPL - female - 1513683 - Gujarat Giants vs UP Warriorz
2026-01-10 - club - SSM - female - 1499674 - Auckland vs Canterbury
2026-01-09 - club - WPL - female - 1513682 - Mumbai Indians vs Royal Challengers Bengaluru
2026-01-09 - club - SSM - female - 1499673 - Otago vs Wellington
2026-01-08 - club - SSM - female - 1499672 - Northern Districts vs Canterbury
2026-01-07 - club - SSM - female - 1499671 - Central Districts vs Wellington
2026-01-06 - club - SSM - female - 1499670 - Auckland vs Otago
2026-01-04 - club - SSM - female - 1499669 - Northern Districts vs Otago
2026-01-03 - club - SSM - female - 1499668 - Central Districts vs Canterbury
2026-01-02 - club - SSM - female - 1499667 - Wellington vs Auckland
2026-01-01 - club - SSM - female - 1499666 - Canterbury vs Central Districts
2025-12-31 - club - SSM - female - 1499665 - Wellington vs Northern Districts
2025-12-30 - international - T20 - female - 1513739 - India vs Sri Lanka
2025-12-30 - club - SSM - female - 1499664 - Central Districts vs Otago
2025-12-29 - club - SSM - female - 1499663 - Wellington vs Auckland
2025-12-28 - international - T20 - female - 1513738 - India vs Sri Lanka
2025-12-28 - club - SSM - female - 1499662 - Canterbury vs Otago
2025-12-27 - club - SSM - female - 1499661 - Wellington vs Central Districts
2025-12-26 - international - T20 - female - 1513737 - Sri Lanka vs India
2025-12-26 - club - SSM - female - 1499660 - Auckland vs Northern Districts
2025-12-23 - international - T20 - female - 1513736 - Sri Lanka vs India
2025-12-21 - international - T20 - female - 1513735 - Sri Lanka vs India
2025-12-19 - international - T20 - female - 1514529 - Oman vs United Arab Emirates
2025-12-19 - international - T20 - female - 1513764 - Malaysia vs Thailand
2025-12-19 - international - T20 - female - 1513763 - Myanmar vs Indonesia
2025-12-19 - international - ODI - female - 1477596 - Ireland vs South Africa
2025-12-18 - international - T20 - female - 1514528 - Qatar vs Oman
2025-12-18 - international - T20 - female - 1514527 - United Arab Emirates vs Bahrain
2025-12-18 - international - T20 - female - 1514526 - Saudi Arabia vs Kuwait
2025-12-18 - international - T20 - female - 1513762 - Malaysia vs Myanmar
2025-12-18 - international - T20 - female - 1513761 - Thailand vs Indonesia
2025-12-17 - international - T20 - female - 1513760 - Myanmar vs Singapore
2025-12-17 - international - T20 - female - 1513759 - Philippines vs Malaysia
2025-12-16 - international - T20 - female - 1514525 - Kuwait vs Oman
2025-12-16 - international - T20 - female - 1514524 - United Arab Emirates vs Saudi Arabia
2025-12-16 - international - T20 - female - 1514523 - Qatar vs Bahrain
2025-12-16 - international - T20 - female - 1513758 - Thailand vs Singapore
2025-12-16 - international - T20 - female - 1513757 - Indonesia vs Philippines
2025-12-16 - international - ODI - female - 1477595 - South Africa vs Ireland
2025-12-15 - international - T20 - female - 1514522 - Kuwait vs United Arab Emirates
2025-12-15 - international - T20 - female - 1514521 - Saudi Arabia vs Qatar
2025-12-15 - international - T20 - female - 1514520 - Bahrain vs Oman
2025-12-15 - international - T20 - female - 1513756 - Malaysia vs Indonesia
2025-12-15 - international - T20 - female - 1513755 - Myanmar vs Thailand
2025-12-13 - international - T20 - female - 1514519 - Bahrain vs Kuwait
2025-12-13 - international - T20 - female - 1514518 - Oman vs Saudi Arabia
2025-12-13 - international - T20 - female - 1514517 - United Arab Emirates vs Qatar
2025-12-13 - international - ODI - female - 1477594 - Ireland vs South Africa
2025-12-13 - club - WBB - female - 1494568 - Perth Scorchers vs Hobart Hurricanes
2025-12-12 - international - T20 - female - 1514516 - Bahrain vs Saudi Arabia
2025-12-12 - international - T20 - female - 1514515 - Oman vs United Arab Emirates
2025-12-12 - international - T20 - female - 1514514 - Kuwait vs Qatar
2025-12-11 - club - WBB - female - 1494567 - Perth Scorchers vs Sydney Sixers
2025-12-10 - international - T20 - female - 1514513 - Oman vs Qatar
2025-12-09 - club - WBB - female - 1494566 - Perth Scorchers vs Melbourne Stars
2025-12-07 - international - T20 - female - 1514511 - Oman vs Qatar
2025-12-07 - international - T20 - female - 1477592 - South Africa vs Ireland
2025-12-07 - club - WBB - female - 1494565 - Sydney Sixers vs Adelaide Strikers
2025-12-06 - international - T20 - female - 1514510 - Bahrain vs Oman
2025-12-06 - club - WBB - female - 1494564 - Brisbane Heat vs Perth Scorchers
2025-12-06 - club - WBB - female - 1494563 - Melbourne Stars vs Sydney Thunder
2025-12-05 - international - T20 - female - 1477591 - South Africa vs Ireland
2025-12-05 - club - WBB - female - 1494562 - Adelaide Strikers vs Hobart Hurricanes
2025-12-05 - club - WBB - female - 1494561 - Sydney Sixers vs Melbourne Renegades
2025-12-03 - club - WBB - female - 1494560 - Sydney Thunder vs Brisbane Heat
2025-12-03 - club - WBB - female - 1494559 - Sydney Sixers vs Melbourne Stars
2025-12-02 - club - WBB - female - 1494558 - Perth Scorchers vs Melbourne Renegades
2025-12-01 - club - WBB - female - 1494557 - Hobart Hurricanes vs Melbourne Stars
2025-11-30 - international - T20 - female - 1510315 - Myanmar vs Singapore
2025-11-30 - international - T20 - female - 1510312 - Papua New Guinea vs Tanzania
2025-11-30 - international - T20 - female - 1510311 - Scotland vs Thailand
2025-11-30 - international - T20 - female - 1510310 - United Arab Emirates vs Namibia
2025-11-30 - international - T20 - female - 1510309 - Uganda vs Netherlands
2025-11-30 - club - WBB - female - 1494556 - Sydney Thunder vs Sydney Sixers
2025-11-30 - club - WBB - female - 1494555 - Brisbane Heat vs Adelaide Strikers
2025-11-29 - international - T20 - female - 1510314 - Singapore vs Myanmar
2025-11-29 - club - WBB - female - 1494554 - Perth Scorchers vs Hobart Hurricanes
2025-11-29 - club - WBB - female - 1494553 - Melbourne Stars vs Melbourne Renegades
2025-11-28 - international - T20 - female - 1510308 - Netherlands vs Scotland
2025-11-28 - international - T20 - female - 1510307 - Papua New Guinea vs Namibia
2025-11-28 - international - T20 - female - 1510306 - Tanzania vs Uganda
2025-11-28 - international - T20 - female - 1510305 - United Arab Emirates vs Thailand
2025-11-28 - club - WBB - female - 1494552 - Adelaide Strikers vs Sydney Thunder
2025-11-27 - international - T20 - female - 1510313 - Singapore vs Myanmar
2025-11-27 - club - WBB - female - 1494550 - Melbourne Renegades vs Perth Scorchers
2025-11-26 - international - T20 - female - 1510304 - Papua New Guinea vs Scotland
2025-11-26 - international - T20 - female - 1510303 - Netherlands vs Namibia
2025-11-26 - international - T20 - female - 1510302 - Uganda vs Thailand
2025-11-26 - international - T20 - female - 1510301 - Tanzania vs United Arab Emirates
2025-11-26 - club - WBB - female - 1494549 - Melbourne Stars vs Hobart Hurricanes
2025-11-25 - international - T20 - female - 1510300 - Papua New Guinea vs Netherlands
2025-11-25 - international - T20 - female - 1510299 - Namibia vs Scotland
2025-11-25 - international - T20 - female - 1510298 - Uganda vs United Arab Emirates
2025-11-25 - international - T20 - female - 1510297 - Thailand vs Tanzania
2025-11-25 - club - WBB - female - 1494548 - Brisbane Heat vs Adelaide Strikers
2025-11-23 - international - T20 - female - 1510296 - Thailand vs Namibia
2025-11-23 - international - T20 - female - 1510295 - United Arab Emirates vs Scotland
2025-11-23 - international - T20 - female - 1510294 - Uganda vs Papua New Guinea
2025-11-23 - international - T20 - female - 1510293 - Tanzania vs Netherlands
2025-11-23 - club - WBB - female - 1494547 - Melbourne Stars vs Brisbane Heat
2025-11-23 - club - WBB - female - 1494546 - Sydney Thunder vs Melbourne Renegades
2025-11-22 - club - WBB - female - 1494545 - Perth Scorchers vs Adelaide Strikers
2025-11-22 - club - WBB - female - 1494544 - Sydney Sixers vs Hobart Hurricanes
2025-11-21 - international - T20 - female - 1510292 - Scotland vs Tanzania
2025-11-21 - international - T20 - female - 1510291 - Namibia vs Uganda
2025-11-21 - international - T20 - female - 1510290 - Papua New Guinea vs Thailand
2025-11-21 - international - T20 - female - 1510289 - United Arab Emirates vs Netherlands
2025-11-21 - club - WBB - female - 1494543 - Sydney Thunder vs Brisbane Heat
2025-11-20 - international - T20 - female - 1510288 - Scotland vs Uganda
2025-11-20 - international - T20 - female - 1510287 - Namibia vs Tanzania
2025-11-20 - international - T20 - female - 1510286 - Papua New Guinea vs United Arab Emirates
2025-11-20 - international - T20 - female - 1510285 - Thailand vs Netherlands
2025-11-20 - club - WBB - female - 1494542 - Melbourne Stars vs Sydney Sixers
2025-11-20 - club - WBB - female - 1494541 - Melbourne Renegades vs Hobart Hurricanes
2025-11-19 - club - WBB - female - 1494540 - Perth Scorchers vs Sydney Thunder
2025-11-18 - club - WBB - female - 1494539 - Adelaide Strikers vs Hobart Hurricanes
2025-11-17 - international - T20 - female - 1510284 - Papua New Guinea vs Thailand
2025-11-17 - international - T20 - female - 1510283 - Namibia vs Scotland
2025-11-16 - club - WBB - female - 1494538 - Melbourne Stars vs Melbourne Renegades
2025-11-16 - club - WBB - female - 1494537 - Adelaide Strikers vs Perth Scorchers
2025-11-15 - international - T20 - female - 1510282 - Thailand vs Scotland
2025-11-15 - international - T20 - female - 1510281 - Namibia vs Papua New Guinea
2025-11-15 - club - WBB - female - 1494536 - Sydney Sixers vs Sydney Thunder
2025-11-15 - club - WBB - female - 1494535 - Hobart Hurricanes vs Brisbane Heat
2025-11-14 - international - T20 - female - 1510280 - Thailand vs Namibia
2025-11-14 - international - T20 - female - 1510279 - Scotland vs Papua New Guinea
2025-11-14 - club - WBB - female - 1494534 - Melbourne Renegades vs Adelaide Strikers
2025-11-14 - club - WBB - female - 1494533 - Melbourne Stars vs Perth Scorchers
2025-11-13 - club - WBB - female - 1494532 - Sydney Sixers vs Hobart Hurricanes
2025-11-12 - club - WBB - female - 1494531 - Perth Scorchers vs Brisbane Heat
2025-11-11 - club - WBB - female - 1494530 - Sydney Thunder vs Melbourne Renegades
2025-11-10 - club - WBB - female - 1494529 - Melbourne Stars vs Adelaide Strikers
2025-11-09 - club - WBB - female - 1494528 - Perth Scorchers vs Sydney Sixers
2025-11-09 - club - WBB - female - 1494527 - Sydney Thunder vs Hobart Hurricanes
2025-11-09 - club - WBB - female - 1494526 - Brisbane Heat vs Melbourne Renegades
2025-11-05 - international - T20 - female - 1506671 - Canada vs Tanzania
2025-11-05 - international - T20 - female - 1506670 - Tanzania vs Canada
2025-11-04 - international - T20 - female - 1506669 - Canada vs Tanzania
2025-11-02 - international - ODI - female - 1490443 - India vs South Africa
2025-10-30 - international - ODI - female - 1490442 - Australia vs India
2025-10-29 - international - ODI - female - 1490441 - South Africa vs England
2025-10-26 - international - T20 - female - 1506668 - Uganda vs Canada
2025-10-26 - international - ODI - female - 1490440 - Bangladesh vs India
2025-10-26 - international - ODI - female - 1490439 - New Zealand vs England
2025-10-25 - international - ODI - female - 1490438 - South Africa vs Australia
2025-10-24 - international - T20 - female - 1506667 - Uganda vs Canada
2025-10-24 - international - ODI - female - 1490437 - Pakistan vs Sri Lanka
2025-10-23 - international - T20 - female - 1506666 - Uganda vs Canada
2025-10-23 - international - ODI - female - 1490436 - India vs New Zealand
2025-10-22 - international - ODI - female - 1490435 - England vs Australia
2025-10-21 - international - T20 - female - 1506665 - Canada vs Uganda
2025-10-21 - international - ODI - female - 1490434 - South Africa vs Pakistan
2025-10-20 - international - T20 - female - 1506664 - Canada vs Uganda
2025-10-20 - international - ODI - female - 1490433 - Sri Lanka vs Bangladesh
2025-10-19 - international - ODI - female - 1506453 - Papua New Guinea vs United Arab Emirates
2025-10-19 - international - ODI - female - 1490432 - England vs India
2025-10-18 - international - ODI - female - 1490431 - Pakistan vs New Zealand
2025-10-17 - international - ODI - female - 1506452 - United Arab Emirates vs Papua New Guinea
2025-10-17 - international - ODI - female - 1490430 - Sri Lanka vs South Africa
2025-10-16 - international - ODI - female - 1490429 - Bangladesh vs Australia
2025-10-15 - international - ODI - female - 1506451 - United Arab Emirates vs Papua New Guinea
2025-10-15 - international - ODI - female - 1490428 - England vs Pakistan
2025-10-14 - international - ODI - female - 1490427 - Sri Lanka vs New Zealand
2025-10-13 - international - ODI - female - 1506450 - Papua New Guinea vs United Arab Emirates
2025-10-13 - international - ODI - female - 1490426 - Bangladesh vs South Africa
2025-10-12 - international - T20 - female - 1506190 - Norway vs Bulgaria
2025-10-12 - international - T20 - female - 1506189 - Austria vs Norway
2025-10-12 - international - ODI - female - 1490425 - India vs Australia
2025-10-11 - international - T20 - female - 1506188 - Norway vs Romania
2025-10-11 - international - T20 - female - 1506187 - Bulgaria vs Austria
2025-10-11 - international - T20 - female - 1506186 - Norway vs Turkey
2025-10-11 - international - ODI - female - 1490424 - England vs Sri Lanka
2025-10-10 - international - T20 - female - 1506185 - Romania vs Bulgaria
2025-10-10 - international - T20 - female - 1506184 - Romania vs Turkey
2025-10-10 - international - T20 - female - 1506183 - Austria vs Turkey
2025-10-10 - international - ODI - female - 1490423 - New Zealand vs Bangladesh
2025-10-09 - international - T20 - female - 1506182 - Turkey vs Bulgaria
2025-10-09 - international - T20 - female - 1506181 - Romania vs Austria
2025-10-09 - international - ODI - female - 1490422 - India vs South Africa
2025-10-08 - international - T20 - female - 1505118 - Malaysia vs Nepal
2025-10-08 - international - ODI - female - 1490421 - Australia vs Pakistan
2025-10-07 - international - T20 - female - 1505117 - Malaysia vs Nepal
2025-10-07 - international - ODI - female - 1490420 - Bangladesh vs England
2025-10-06 - international - T20 - female - 1503566 - United Arab Emirates vs Zimbabwe
2025-10-06 - international - ODI - female - 1490419 - New Zealand vs South Africa
2025-10-05 - international - T20 - female - 1505116 - Malaysia vs Nepal
2025-10-05 - international - T20 - female - 1503565 - United Arab Emirates vs Zimbabwe
2025-10-05 - international - ODI - female - 1490418 - India vs Pakistan
2025-10-04 - international - T20 - female - 1505115 - Malaysia vs Nepal
2025-10-03 - international - ODI - female - 1490416 - South Africa vs England
2025-10-02 - international - T20 - female - 1505114 - Malaysia vs Nepal
2025-10-02 - international - ODI - female - 1503564 - United Arab Emirates vs Zimbabwe
2025-10-02 - international - ODI - female - 1490415 - Pakistan vs Bangladesh
2025-10-01 - international - ODI - female - 1490414 - Australia vs New Zealand
2025-09-30 - international - ODI - female - 1503563 - Zimbabwe vs United Arab Emirates
2025-09-30 - international - ODI - female - 1490413 - India vs Sri Lanka
2025-09-28 - international - ODI - female - 1503562 - United Arab Emirates vs Zimbabwe
2025-09-26 - international - ODI - female - 1503561 - United Arab Emirates vs Zimbabwe
2025-09-22 - international - ODI - female - 1500389 - South Africa vs Pakistan
2025-09-21 - club - WOD - female - 1462401 - Hampshire vs Lancashire
2025-09-20 - international - ODI - female - 1488250 - Australia vs India
2025-09-19 - international - ODI - female - 1500388 - South Africa vs Pakistan
2025-09-17 - international - ODI - female - 1488249 - India vs Australia
2025-09-17 - club - WOD - female - 1462400 - Surrey vs Hampshire
2025-09-17 - club - WOD - female - 1462399 - Lancashire vs The Blaze
2025-09-17 - club - WCL - female - 1489958 - Guyana Amazon Warriors vs Barbados Royals
2025-09-16 - international - ODI - female - 1500387 - Pakistan vs South Africa
2025-09-16 - club - WCL - female - 1489957 - Trinbago Knight Riders vs Barbados Royals
2025-09-15 - international - T20 - female - 1499803 - Vanuatu vs Papua New Guinea
2025-09-15 - international - T20 - female - 1499802 - Japan vs Indonesia
2025-09-15 - international - T20 - female - 1499801 - Cook Islands vs Philippines
2025-09-15 - international - T20 - female - 1499800 - Samoa vs Fiji
2025-09-14 - international - T20 - female - 1500868 - Luxembourg vs Switzerland
2025-09-14 - international - T20 - female - 1500867 - Austria vs Luxembourg
2025-09-14 - international - ODI - female - 1488248 - India vs Australia
2025-09-14 - club - WCL - female - 1489956 - Barbados Royals vs Guyana Amazon Warriors
2025-09-13 - international - T20 - female - 1500866 - Austria vs Switzerland
2025-09-13 - international - T20 - female - 1499799 - Vanuatu vs Japan
2025-09-13 - international - T20 - female - 1499798 - Indonesia vs Papua New Guinea
2025-09-13 - international - T20 - female - 1499797 - Philippines vs Fiji
2025-09-13 - international - T20 - female - 1499796 - Samoa vs Cook Islands
2025-09-13 - club - WOD - female - 1462398 - Warwickshire vs Somerset
2025-09-13 - club - WOD - female - 1462396 - Essex vs The Blaze
2025-09-13 - club - WOD - female - 1462395 - Surrey vs Durham
2025-09-13 - club - WCL - female - 1489955 - Trinbago Knight Riders vs Guyana Amazon Warriors
2025-09-12 - international - T20 - female - 1500864 - Switzerland vs Luxembourg
2025-09-12 - international - T20 - female - 1499795 - Samoa vs Papua New Guinea
2025-09-12 - international - T20 - female - 1499794 - Vanuatu vs Fiji
2025-09-12 - international - T20 - female - 1499792 - Indonesia vs Cook Islands
2025-09-10 - international - T20 - female - 1499791 - Cook Islands vs Vanuatu
2025-09-10 - international - T20 - female - 1499790 - Papua New Guinea vs Philippines
2025-09-10 - international - T20 - female - 1499789 - Indonesia vs Fiji
2025-09-10 - international - T20 - female - 1499788 - Japan vs Samoa
2025-09-10 - club - WOD - female - 1462393 - Surrey vs Essex
2025-09-10 - club - WOD - female - 1462392 - Warwickshire vs Lancashire
2025-09-10 - club - WCL - female - 1489954 - Barbados Royals vs Trinbago Knight Riders
2025-09-09 - international - T20 - female - 1499787 - Philippines vs Samoa
2025-09-09 - international - T20 - female - 1499786 - Vanuatu vs Indonesia
2025-09-09 - international - T20 - female - 1499785 - Papua New Guinea vs Japan
2025-09-09 - international - T20 - female - 1499784 - Cook Islands vs Fiji
2025-09-09 - club - WOD - female - 1462394 - Durham vs The Blaze
2025-09-07 - international - T20 - female - 1499783 - Czech Republic vs Estonia
2025-09-07 - club - WOD - female - 1462390 - Essex vs Warwickshire
2025-09-07 - club - WOD - female - 1462389 - Surrey vs Lancashire
2025-09-07 - club - WOD - female - 1462388 - The Blaze vs Somerset
2025-09-07 - club - WOD - female - 1462387 - Durham vs Hampshire
2025-09-07 - club - WCL - female - 1489953 - Guyana Amazon Warriors vs Barbados Royals
2025-09-06 - international - T20 - female - 1499782 - Estonia vs Czech Republic
2025-09-06 - international - T20 - female - 1499781 - Czech Republic vs Estonia
2025-09-06 - international - T20 - female - 1499780 - Japan vs Fiji
2025-09-06 - international - T20 - female - 1498726 - Namibia vs Zimbabwe
2025-09-06 - international - T20 - female - 1498725 - Rwanda vs Kenya
2025-09-06 - international - T20 - female - 1498724 - Nigeria vs Sierra Leone
2025-09-06 - international - T20 - female - 1498723 - Tanzania vs Uganda
2025-09-06 - club - WCL - female - 1489952 - Guyana Amazon Warriors vs Trinbago Knight Riders
2025-09-05 - international - T20 - female - 1499779 - Japan vs Fiji
2025-09-04 - international - T20 - female - 1498722 - Rwanda vs Sierra Leone
2025-09-04 - international - T20 - female - 1498721 - Tanzania vs Namibia
2025-09-04 - international - T20 - female - 1498720 - Kenya vs Nigeria
2025-09-04 - international - T20 - female - 1498719 - Uganda vs Zimbabwe
2025-09-04 - club - WOD - female - 1462385 - The Blaze vs Surrey
2025-09-04 - club - WOD - female - 1462384 - Lancashire vs Somerset
2025-09-04 - club - WOD - female - 1462383 - Hampshire vs Essex
2025-09-03 - international - T20 - female - 1498718 - Nigeria vs Zimbabwe
2025-09-03 - international - T20 - female - 1498717 - Kenya vs Uganda
2025-09-03 - international - T20 - female - 1498716 - Namibia vs Sierra Leone
2025-09-03 - international - T20 - female - 1498715 - Tanzania vs Rwanda
2025-09-02 - international - T20 - female - 1500638 - Jersey vs Isle of Man
2025-09-01 - international - T20 - female - 1500636 - Brazil vs Isle of Man
2025-09-01 - international - T20 - female - 1498714 - Rwanda vs Uganda
2025-09-01 - international - T20 - female - 1498713 - Nigeria vs Namibia
2025-09-01 - international - T20 - female - 1498712 - Tanzania vs Kenya
2025-09-01 - international - T20 - female - 1498711 - Sierra Leone vs Zimbabwe
2025-08-31 - international - T20 - female - 1500635 - Isle of Man vs Brazil
2025-08-31 - international - T20 - female - 1499030 - Sweden vs Finland
2025-08-31 - international - T20 - female - 1499029 - Germany vs Denmark
2025-08-31 - international - T20 - female - 1499028 - Germany vs Sweden
2025-08-31 - international - T20 - female - 1499027 - Norway vs Denmark
2025-08-31 - international - T20 - female - 1498710 - Tanzania vs Uganda
2025-08-31 - international - T20 - female - 1498709 - Zimbabwe vs Namibia
2025-08-31 - international - T20 - female - 1498708 - Kenya vs Rwanda
2025-08-31 - international - T20 - female - 1498707 - Nigeria vs Sierra Leone
2025-08-31 - club - HND - female - 1471069 - Southern Brave vs Northern Superchargers
2025-08-30 - international - T20 - female - 1499026 - Germany vs Norway
2025-08-30 - international - T20 - female - 1499025 - Finland vs Denmark
2025-08-30 - international - T20 - female - 1499024 - Sweden vs Denmark
2025-08-30 - international - T20 - female - 1499023 - Finland vs Norway
2025-08-30 - club - HND - female - 1471068 - Northern Superchargers vs London Spirit
2025-08-29 - international - T20 - female - 1499022 - Sweden vs Norway
2025-08-29 - international - T20 - female - 1499021 - Finland vs Germany
2025-08-28 - club - HND - female - 1471067 - Southern Brave vs Welsh Fire
2025-08-27 - international - T20 - female - 1498217 - Ireland vs Italy
2025-08-27 - international - T20 - female - 1498216 - Netherlands vs Germany
2025-08-27 - club - HND - female - 1471066 - Birmingham Phoenix vs Trent Rockets
2025-08-26 - international - T20 - female - 1498215 - Netherlands vs Ireland
2025-08-26 - international - T20 - female - 1498214 - Germany vs Italy
2025-08-26 - club - HND - female - 1471065 - Manchester Originals vs Northern Superchargers
2025-08-25 - club - HND - female - 1471064 - Oval Invincibles vs London Spirit
2025-08-24 - international - T20 - female - 1498213 - Italy vs Netherlands
2025-08-24 - international - T20 - female - 1498212 - Ireland vs Germany
2025-08-24 - club - HND - female - 1471063 - Birmingham Phoenix vs Manchester Originals
2025-08-24 - club - HND - female - 1471062 - Trent Rockets vs Welsh Fire
2025-08-23 - international - T20 - female - 1498211 - Netherlands vs Germany
2025-08-23 - international - T20 - female - 1498210 - Ireland vs Italy
2025-08-23 - club - HND - female - 1471061 - London Spirit vs Southern Brave
2025-08-23 - club - HND - female - 1471060 - Oval Invincibles vs Northern Superchargers
2025-08-22 - club - HND - female - 1471059 - Welsh Fire vs Birmingham Phoenix
2025-08-21 - international - T20 - female - 1498209 - Germany vs Italy
2025-08-21 - international - T20 - female - 1498208 - Netherlands vs Ireland
2025-08-21 - club - HND - female - 1471058 - Oval Invincibles vs Trent Rockets
2025-08-20 - international - T20 - female - 1498207 - Germany vs Ireland
2025-08-20 - international - T20 - female - 1498206 - Netherlands vs Italy
2025-08-20 - club - HND - female - 1471057 - London Spirit vs Northern Superchargers
2025-08-20 - club - HND - female - 1471056 - Welsh Fire vs Southern Brave
2025-08-19 - club - HND - female - 1471055 - Trent Rockets vs Manchester Originals
2025-08-18 - club - HND - female - 1471054 - Southern Brave vs Oval Invincibles
2025-08-17 - club - HND - female - 1471053 - London Spirit vs Birmingham Phoenix
2025-08-17 - club - HND - female - 1471052 - Manchester Originals vs Northern Superchargers
2025-08-16 - international - T20 - female - 1498205 - Singapore vs Cambodia
2025-08-16 - club - HND - female - 1471051 - Oval Invincibles vs Welsh Fire
2025-08-16 - club - HND - female - 1471050 - Trent Rockets vs Southern Brave
2025-08-15 - club - HND - female - 1471049 - Birmingham Phoenix vs Northern Superchargers
2025-08-14 - international - T20 - female - 1498204 - Singapore vs Cambodia
2025-08-14 - club - HND - female - 1471048 - Trent Rockets vs London Spirit
2025-08-13 - international - T20 - female - 1498203 - Singapore vs Cambodia
2025-08-13 - club - HND - female - 1471047 - Welsh Fire vs Manchester Originals
2025-08-13 - club - HND - female - 1471046 - Northern Superchargers vs Southern Brave
2025-08-12 - club - HND - female - 1471045 - Oval Invincibles vs Birmingham Phoenix
2025-08-11 - club - HND - female - 1471044 - Manchester Originals vs London Spirit
2025-08-10 - international - T20 - female - 1476994 - Ireland vs Pakistan
2025-08-10 - club - HND - female - 1471043 - Trent Rockets vs Northern Superchargers
2025-08-10 - club - HND - female - 1471042 - Southern Brave vs Birmingham Phoenix
2025-08-09 - club - HND - female - 1471041 - London Spirit vs Welsh Fire
2025-08-09 - club - HND - female - 1471040 - Manchester Originals vs Oval Invincibles
2025-08-08 - international - T20 - female - 1476993 - Pakistan vs Ireland
2025-08-08 - club - HND - female - 1471039 - Birmingham Phoenix vs Trent Rockets
2025-08-07 - club - HND - female - 1471038 - Northern Superchargers vs Welsh Fire
2025-08-06 - international - T20 - female - 1476992 - Ireland vs Pakistan
2025-08-06 - club - HND - female - 1471037 - Manchester Originals vs Southern Brave
2025-08-05 - club - HND - female - 1471036 - London Spirit vs Oval Invincibles
2025-07-30 - club - WOD - female - 1462382 - Warwickshire vs Surrey
2025-07-30 - club - WOD - female - 1462381 - Durham vs Somerset
2025-07-30 - club - WOD - female - 1462380 - Lancashire vs Essex
2025-07-30 - club - WOD - female - 1462379 - Hampshire vs The Blaze
2025-07-28 - international - ODI - female - 1476991 - Zimbabwe vs Ireland
2025-07-27 - club - WTB - female - 1461047 - Warwickshire vs Surrey
2025-07-27 - club - WTB - female - 1461045 - Warwickshire vs The Blaze
2025-07-26 - international - T20 - female - 1494143 - Rwanda vs Sierra Leone
2025-07-26 - international - T20 - female - 1494142 - Mozambique vs Cameroon
2025-07-26 - international - T20 - female - 1494141 - Lesotho vs Eswatini
2025-07-26 - international - T20 - female - 1494140 - Botswana vs Malawi
2025-07-26 - international - ODI - female - 1476990 - Ireland vs Zimbabwe
2025-07-24 - international - T20 - female - 1494139 - Malawi vs Sierra Leone
2025-07-24 - international - T20 - female - 1494138 - Lesotho vs Mozambique
2025-07-24 - international - T20 - female - 1494137 - Rwanda vs Botswana
2025-07-24 - international - T20 - female - 1494136 - Cameroon vs Eswatini
2025-07-24 - club - WOD - female - 1462378 - The Blaze vs Warwickshire
2025-07-24 - club - WOD - female - 1462377 - Hampshire vs Surrey
2025-07-24 - club - WOD - female - 1462376 - Somerset vs Essex
2025-07-24 - club - WOD - female - 1462375 - Durham vs Lancashire
2025-07-23 - international - T20 - female - 1494135 - Cameroon vs Rwanda
2025-07-23 - international - T20 - female - 1494134 - Botswana vs Sierra Leone
2025-07-23 - international - T20 - female - 1494133 - Mozambique vs Eswatini
2025-07-23 - international - T20 - female - 1494132 - Malawi vs Lesotho
2025-07-23 - international - T20 - female - 1476989 - Ireland vs Zimbabwe
2025-07-22 - international - T20 - female - 1476988 - Ireland vs Zimbabwe
2025-07-22 - international - ODI - female - 1448404 - India vs England
2025-07-21 - international - T20 - female - 1494131 - Cameroon vs Lesotho
2025-07-21 - international - T20 - female - 1494130 - Sierra Leone vs Eswatini
2025-07-21 - international - T20 - female - 1494129 - Rwanda vs Malawi
2025-07-21 - international - T20 - female - 1494128 - Mozambique vs Botswana
2025-07-20 - international - T20 - female - 1494581 - Finland vs Switzerland
2025-07-20 - international - T20 - female - 1494580 - Estonia vs Finland
2025-07-20 - international - T20 - female - 1494127 - Sierra Leone vs Mozambique
2025-07-20 - international - T20 - female - 1494126 - Malawi vs Cameroon
2025-07-20 - international - T20 - female - 1494125 - Botswana vs Eswatini
2025-07-20 - international - T20 - female - 1494124 - Lesotho vs Rwanda
2025-07-20 - international - T20 - female - 1476987 - Zimbabwe vs Ireland
2025-07-19 - international - T20 - female - 1494579 - Switzerland vs Estonia
2025-07-19 - international - T20 - female - 1494578 - Finland vs Switzerland
2025-07-19 - international - T20 - female - 1494577 - Estonia vs Finland
2025-07-19 - international - ODI - female - 1448403 - India vs England
2025-07-18 - club - WTB - female - 1461044 - Surrey vs Warwickshire
2025-07-18 - club - WTB - female - 1461043 - Somerset vs Lancashire
2025-07-18 - club - WTB - female - 1461042 - The Blaze vs Hampshire
2025-07-18 - club - WTB - female - 1461041 - Essex vs Durham
2025-07-16 - international - ODI - female - 1448402 - England vs India
2025-07-16 - club - WTB - female - 1461040 - The Blaze vs Somerset
2025-07-16 - club - WTB - female - 1461039 - Essex vs Lancashire
2025-07-13 - club - WTB - female - 1461037 - Surrey vs Somerset
2025-07-13 - club - WTB - female - 1461036 - Lancashire vs Durham
2025-07-13 - club - WTB - female - 1461035 - Warwickshire vs Hampshire
2025-07-13 - club - WTB - female - 1461034 - The Blaze vs Essex
2025-07-12 - international - T20 - female - 1448401 - India vs England
2025-07-11 - club - WTB - female - 1461033 - Warwickshire vs Somerset
2025-07-11 - club - WTB - female - 1461032 - Surrey vs The Blaze
2025-07-11 - club - WTB - female - 1461031 - Hampshire vs Durham
2025-07-09 - international - T20 - female - 1490861 - Turkey vs Greece
2025-07-09 - international - T20 - female - 1490860 - Bulgaria vs Serbia
2025-07-09 - international - T20 - female - 1448400 - England vs India
2025-07-09 - club - WTB - female - 1461030 - Hampshire vs Lancashire
2025-07-09 - club - WTB - female - 1461029 - Warwickshire vs Surrey
2025-07-08 - international - T20 - female - 1490859 - Turkey vs Bulgaria
2025-07-08 - international - T20 - female - 1490858 - Serbia vs Greece
2025-07-08 - international - T20 - female - 1490857 - Greece vs Bulgaria
2025-07-08 - club - WTB - female - 1461028 - Essex vs Somerset
2025-07-07 - international - T20 - female - 1490856 - Turkey vs Serbia
2025-07-07 - international - T20 - female - 1490855 - Bulgaria vs Serbia
2025-07-07 - international - T20 - female - 1490854 - Turkey vs Greece
2025-07-06 - club - WTB - female - 1461027 - Surrey vs Essex
2025-07-06 - club - WTB - female - 1461026 - Durham vs The Blaze
2025-07-06 - club - WTB - female - 1461025 - Warwickshire vs Lancashire
2025-07-06 - club - WTB - female - 1461024 - Somerset vs Hampshire
2025-07-05 - international - T20 - female - 1490227 - Indonesia vs Singapore
2025-07-05 - club - WTB - female - 1461023 - Essex vs Lancashire
2025-07-04 - international - T20 - female - 1448399 - England vs India
2025-07-04 - club - WTB - female - 1461022 - The Blaze vs Hampshire
2025-07-04 - club - WTB - female - 1461021 - Durham vs Somerset
2025-07-03 - international - T20 - female - 1490226 - Singapore vs Indonesia
2025-07-02 - international - T20 - female - 1490225 - Singapore vs Indonesia
2025-07-01 - international - T20 - female - 1448398 - India vs England
2025-06-28 - international - T20 - female - 1448397 - India vs England
2025-06-23 - international - T20 - female - 1472539 - South Africa vs West Indies
2025-06-22 - international - T20 - female - 1472538 - South Africa vs West Indies
2025-06-21 - international - T20 - female - 1489047 - Papua New Guinea vs Samoa
2025-06-20 - international - T20 - female - 1489046 - Papua New Guinea vs Vanuatu
2025-06-20 - international - T20 - female - 1472537 - South Africa vs West Indies
2025-06-20 - club - WTB - female - 1461020 - Durham vs Essex
2025-06-20 - club - WTB - female - 1461019 - Warwickshire vs The Blaze
2025-06-19 - international - T20 - female - 1489045 - Vanuatu vs Samoa
2025-06-19 - club - WTB - female - 1461018 - Hampshire vs Somerset
2025-06-19 - club - WTB - female - 1461017 - Lancashire vs The Blaze
2025-06-18 - club - WTB - female - 1461016 - Surrey vs Lancashire
2025-06-18 - club - WTB - female - 1461015 - Essex vs Warwickshire
2025-06-17 - international - T20 - female - 1489044 - Samoa vs Papua New Guinea
2025-06-17 - international - ODI - female - 1472536 - South Africa vs West Indies
2025-06-17 - club - WTB - female - 1461014 - Hampshire vs Surrey
2025-06-16 - international - T20 - female - 1489043 - Papua New Guinea vs Vanuatu
2025-06-15 - international - T20 - female - 1489042 - Vanuatu vs Samoa
2025-06-15 - club - WTB - female - 1461013 - Somerset vs Durham
2025-06-15 - club - WTB - female - 1461012 - Essex vs Surrey
2025-06-15 - club - WTB - female - 1461011 - Warwickshire vs Hampshire
2025-06-14 - international - T20 - female - 1487731 - Uganda vs Rwanda
2025-06-14 - international - ODI - female - 1472535 - South Africa vs West Indies
2025-06-13 - international - T20 - female - 1487729 - Tanzania vs Rwanda
2025-06-13 - international - T20 - female - 1487661 - Czech Republic vs Austria
2025-06-13 - international - T20 - female - 1487660 - Gibraltar vs Czech Republic
2025-06-13 - international - T20 - female - 1487655 - Netherlands vs United States of America
2025-06-13 - club - WTB - female - 1461010 - Somerset vs Lancashire
2025-06-13 - club - WTB - female - 1461009 - Durham vs The Blaze
2025-06-12 - international - T20 - female - 1487728 - Sierra Leone vs Brazil
2025-06-12 - international - T20 - female - 1487726 - Uganda vs Rwanda
2025-06-12 - international - T20 - female - 1487725 - Tanzania vs Cameroon
2025-06-12 - international - T20 - female - 1487658 - Austria vs Gibraltar
2025-06-12 - international - T20 - female - 1487654 - Netherlands vs United States of America
2025-06-12 - club - WTB - female - 1461008 - Hampshire vs Essex
2025-06-11 - international - T20 - female - 1487723 - Brazil vs Cameroon
2025-06-11 - international - T20 - female - 1487722 - Rwanda vs Tanzania
2025-06-11 - international - T20 - female - 1487721 - Nigeria vs Uganda
2025-06-11 - international - T20 - female - 1487653 - Netherlands vs United States of America
2025-06-11 - international - ODI - female - 1472534 - South Africa vs West Indies
2025-06-11 - club - WTB - female - 1461007 - The Blaze vs Surrey
2025-06-11 - club - WTB - female - 1461006 - Durham vs Warwickshire
2025-06-10 - international - T20 - female - 1487720 - Rwanda vs Brazil
2025-06-10 - international - T20 - female - 1487717 - Uganda vs Tanzania
2025-06-09 - international - T20 - female - 1487652 - Netherlands vs United States of America
2025-06-08 - international - T20 - female - 1489041 - Mongolia vs Philippines
2025-06-08 - international - T20 - female - 1487715 - Nigeria vs Sierra Leone
2025-06-08 - international - T20 - female - 1487714 - Brazil vs Tanzania
2025-06-08 - international - T20 - female - 1487713 - Uganda vs Malawi
2025-06-08 - international - T20 - female - 1485415 - Japan vs Hong Kong
2025-06-08 - international - T20 - female - 1485414 - Philippines vs China
2025-06-08 - club - WTB - female - 1461005 - Durham vs Surrey
2025-06-08 - club - WTB - female - 1461004 - Lancashire vs Warwickshire
2025-06-07 - international - T20 - female - 1487712 - Nigeria vs Cameroon
2025-06-07 - international - T20 - female - 1487710 - Malawi vs Sierra Leone
2025-06-07 - international - T20 - female - 1487709 - Brazil vs Uganda
2025-06-07 - international - T20 - female - 1485413 - Mongolia vs Hong Kong
2025-06-07 - international - T20 - female - 1485412 - Japan vs Philippines
2025-06-07 - international - ODI - female - 1448396 - West Indies vs England
2025-06-07 - club - WTB - female - 1461002 - Lancashire vs Surrey
2025-06-07 - club - WTB - female - 1461001 - Durham vs Hampshire
2025-06-06 - international - T20 - female - 1487708 - Rwanda vs Nigeria
2025-06-06 - international - T20 - female - 1487707 - Cameroon vs Malawi
2025-06-06 - international - T20 - female - 1487706 - Sierra Leone vs Uganda
2025-06-06 - international - T20 - female - 1485411 - Philippines vs Mongolia
2025-06-06 - international - T20 - female - 1485410 - Japan vs China
2025-06-06 - club - WTB - female - 1461000 - Essex vs The Blaze
2025-06-06 - club - WTB - female - 1460999 - Warwickshire vs Somerset
2025-06-05 - international - T20 - female - 1487704 - Tanzania vs Nigeria
2025-06-05 - international - T20 - female - 1487703 - Rwanda vs Malawi
2025-06-05 - international - T20 - female - 1487702 - Cameroon vs Sierra Leone
2025-06-05 - international - T20 - female - 1485409 - Mongolia vs China
2025-06-05 - club - WTB - female - 1460998 - Surrey vs Hampshire
2025-06-04 - international - T20 - female - 1487700 - Tanzania vs Malawi
2025-06-04 - international - T20 - female - 1487699 - Nigeria vs Brazil
2025-06-04 - international - T20 - female - 1487698 - Cameroon vs Uganda
2025-06-04 - international - T20 - female - 1487697 - Rwanda vs Sierra Leone
2025-06-04 - international - T20 - female - 1485407 - Philippines vs China
2025-06-04 - international - T20 - female - 1485406 - Hong Kong vs Japan
2025-06-04 - international - ODI - female - 1448395 - England vs West Indies
2025-06-04 - club - WTB - female - 1460997 - Lancashire vs Hampshire
2025-06-04 - club - WTB - female - 1460996 - Essex vs Warwickshire
2025-06-03 - international - T20 - female - 1487696 - Malawi vs Brazil
2025-06-03 - international - T20 - female - 1487695 - Tanzania vs Sierra Leone
2025-06-03 - international - T20 - female - 1487693 - Rwanda vs Cameroon
2025-06-01 - club - WTB - female - 1460995 - Essex vs Somerset
2025-06-01 - club - WTB - female - 1460994 - Lancashire vs Durham
2025-05-31 - club - WTB - female - 1460993 - Lancashire vs The Blaze
2025-05-31 - club - WTB - female - 1460992 - Warwickshire vs Durham
2025-05-30 - international - ODI - female - 1448394 - England vs West Indies
2025-05-30 - club - WTB - female - 1460991 - Somerset vs Surrey
2025-05-30 - club - WTB - female - 1460990 - Warwickshire vs The Blaze
2025-05-30 - club - WTB - female - 1460989 - Hampshire vs Essex
2025-05-29 - international - T20 - female - 1486102 - Isle of Man vs Germany
2025-05-29 - international - T20 - female - 1486101 - Sweden vs Jersey
2025-05-29 - international - T20 - female - 1486100 - Italy vs Spain
2025-05-29 - international - T20 - female - 1483811 - Switzerland vs Belgium
2025-05-29 - international - T20 - female - 1483810 - Belgium vs Switzerland
2025-05-28 - international - T20 - female - 1486099 - Jersey vs Isle of Man
2025-05-28 - international - T20 - female - 1486098 - Germany vs Sweden
2025-05-28 - international - T20 - female - 1486097 - Isle of Man vs Spain
2025-05-28 - international - T20 - female - 1486096 - Italy vs Germany
2025-05-28 - international - T20 - female - 1483809 - Belgium vs Switzerland
2025-05-28 - international - T20 - female - 1483808 - Belgium vs Switzerland
2025-05-26 - international - T20 - female - 1486095 - Sweden vs Italy
2025-05-26 - international - T20 - female - 1486094 - Spain vs Jersey
2025-05-26 - international - T20 - female - 1486093 - Sweden vs Isle of Man
2025-05-26 - international - T20 - female - 1486092 - Germany vs Jersey
2025-05-26 - international - T20 - female - 1448393 - England vs West Indies
2025-05-25 - international - T20 - female - 1486091 - Germany vs Spain
2025-05-25 - international - T20 - female - 1486090 - Isle of Man vs Italy
2025-05-25 - international - T20 - female - 1486089 - Sweden vs Spain
2025-05-25 - international - T20 - female - 1486088 - Jersey vs Italy
2025-05-23 - international - T20 - female - 1448392 - West Indies vs England
2025-05-21 - international - T20 - female - 1448391 - West Indies vs England
2025-05-20 - international - T20 - female - 1485778 - Thailand vs Nepal
2025-05-20 - club - WOD - female - 1462374 - Somerset vs The Blaze
2025-05-19 - international - T20 - female - 1483779 - United Arab Emirates vs Nepal
2025-05-19 - club - WOD - female - 1462373 - Lancashire vs Durham
2025-05-19 - club - WOD - female - 1462372 - Warwickshire vs Hampshire
2025-05-19 - club - WOD - female - 1462371 - Surrey vs Essex
2025-05-18 - international - T20 - female - 1483778 - Thailand vs United Arab Emirates
2025-05-16 - international - T20 - female - 1483777 - Qatar vs Malaysia
2025-05-16 - international - T20 - female - 1483775 - Kuwait vs Bhutan
2025-05-15 - international - T20 - female - 1483773 - Bahrain vs Nepal
2025-05-15 - international - T20 - female - 1483772 - Thailand vs Bhutan
2025-05-15 - international - T20 - female - 1477677 - Bulgaria vs Estonia
2025-05-15 - international - T20 - female - 1477676 - Bulgaria vs Estonia
2025-05-14 - club - WOD - female - 1462370 - Lancashire vs Warwickshire
2025-05-14 - club - WOD - female - 1462369 - The Blaze vs Surrey
2025-05-14 - club - WOD - female - 1462368 - Essex vs Durham
2025-05-13 - international - T20 - female - 1483770 - Nepal vs Hong Kong
2025-05-13 - club - WOD - female - 1462367 - Hampshire vs Somerset
2025-05-12 - international - T20 - female - 1483767 - Bahrain vs Hong Kong
2025-05-12 - international - T20 - female - 1483766 - Kuwait vs Bhutan
2025-05-11 - international - T20 - female - 1483073 - Greece vs Germany
2025-05-11 - international - T20 - female - 1483072 - Germany vs Greece
2025-05-11 - international - ODI - female - 1476986 - India vs Sri Lanka
2025-05-11 - club - WOD - female - 1462366 - Surrey vs Somerset
2025-05-11 - club - WOD - female - 1462365 - The Blaze vs Lancashire
2025-05-11 - club - WOD - female - 1462364 - Hampshire vs Essex
2025-05-11 - club - WOD - female - 1462363 - Warwickshire vs Durham
2025-05-10 - international - T20 - female - 1483765 - United Arab Emirates vs Qatar
2025-05-10 - international - T20 - female - 1483763 - Bahrain vs Nepal
2025-05-10 - international - T20 - female - 1483071 - Germany vs Greece
2025-05-10 - international - T20 - female - 1483070 - Germany vs Greece
2025-05-09 - international - T20 - female - 1483762 - Malaysia vs United Arab Emirates
2025-05-09 - international - T20 - female - 1483760 - Kuwait vs Thailand
2025-05-09 - international - ODI - female - 1476985 - South Africa vs Sri Lanka
2025-05-07 - international - ODI - female - 1476984 - India vs South Africa
2025-05-07 - club - WOD - female - 1462362 - Somerset vs Warwickshire
2025-05-07 - club - WOD - female - 1462361 - Surrey vs Lancashire
2025-05-07 - club - WOD - female - 1462360 - Durham vs Hampshire
2025-05-06 - international - T20 - female - 1483759 - Thailand vs United Arab Emirates
2025-05-06 - international - T20 - female - 1483758 - Hong Kong vs Kuwait
2025-05-06 - club - WOD - female - 1462359 - Essex vs The Blaze
2025-05-05 - international - T20 - female - 1483943 - Bahrain vs Oman
2025-05-05 - international - T20 - female - 1483069 - Croatia vs Malta
2025-05-05 - international - T20 - female - 1483068 - Croatia vs Malta
2025-05-04 - international - T20 - female - 1483757 - United Arab Emirates vs Kuwait
2025-05-04 - international - T20 - female - 1483756 - Thailand vs Hong Kong
2025-05-04 - international - T20 - female - 1483067 - Czech Republic vs Cyprus
2025-05-04 - international - ODI - female - 1476983 - India vs Sri Lanka
2025-05-04 - club - WOD - female - 1462358 - Hampshire vs The Blaze
2025-05-04 - club - WOD - female - 1462357 - Surrey vs Warwickshire
2025-05-04 - club - WOD - female - 1462356 - Lancashire vs Essex
2025-05-04 - club - WOD - female - 1462355 - Durham vs Somerset
2025-05-03 - international - T20 - female - 1483942 - Oman vs Bahrain
2025-05-03 - international - T20 - female - 1483755 - Kuwait vs Thailand
2025-05-03 - international - T20 - female - 1483754 - United Arab Emirates vs Hong Kong
2025-05-03 - international - T20 - female - 1483066 - Czech Republic vs Cyprus
2025-05-03 - international - T20 - female - 1483065 - Czech Republic vs Cyprus
2025-05-03 - international - ODI - female - 1481713 - Zimbabwe vs United States of America
2025-05-02 - international - T20 - female - 1483941 - Bahrain vs Oman
2025-05-02 - international - T20 - female - 1483064 - Cyprus vs Czech Republic
2025-05-02 - international - T20 - female - 1483063 - Cyprus vs Czech Republic
2025-05-02 - international - ODI - female - 1476982 - South Africa vs Sri Lanka
2025-05-01 - international - ODI - female - 1481712 - Zimbabwe vs United States of America
2025-05-01 - club - WOD - female - 1462352 - Essex vs Somerset
2025-04-30 - international - T20 - female - 1477673 - Sierra Leone vs Botswana
2025-04-30 - international - T20 - female - 1477672 - Mozambique vs Eswatini
2025-04-30 - club - WOD - female - 1462354 - The Blaze vs Warwickshire
2025-04-30 - club - WOD - female - 1462353 - Surrey vs Durham
2025-04-30 - club - WOD - female - 1462351 - Lancashire vs Hampshire
2025-04-29 - international - T20 - female - 1481711 - Zimbabwe vs United States of America
2025-04-29 - international - T20 - female - 1477675 - Mozambique vs Eswatini
2025-04-29 - international - T20 - female - 1477674 - Botswana vs Sierra Leone
2025-04-29 - international - T20 - female - 1477666 - Mozambique vs Sierra Leone
2025-04-29 - international - T20 - female - 1477664 - Eswatini vs Botswana
2025-04-29 - international - ODI - female - 1476981 - India vs South Africa
2025-04-27 - international - T20 - female - 1481710 - Zimbabwe vs United States of America
2025-04-27 - international - T20 - female - 1477670 - Botswana vs Mozambique
2025-04-27 - international - T20 - female - 1477669 - Sierra Leone vs Eswatini
2025-04-27 - international - T20 - female - 1477668 - Sierra Leone vs Botswana
2025-04-27 - international - T20 - female - 1477667 - Mozambique vs Eswatini
2025-04-27 - international - ODI - female - 1476980 - Sri Lanka vs India
2025-04-27 - club - WOD - female - 1462350 - Somerset vs Lancashire
2025-04-27 - club - WOD - female - 1462349 - Hampshire vs Surrey
2025-04-27 - club - WOD - female - 1462348 - Warwickshire vs Essex
2025-04-27 - club - WOD - female - 1462347 - Durham vs The Blaze
2025-04-26 - international - T20 - female - 1477671 - Eswatini vs Sierra Leone
2025-04-26 - international - T20 - female - 1477665 - Botswana vs Mozambique
2025-04-26 - international - T20 - female - 1477663 - Mozambique vs Sierra Leone
2025-04-26 - international - T20 - female - 1477662 - Botswana vs Eswatini
2025-04-25 - international - T20 - female - 1481709 - Zimbabwe vs United States of America
2025-04-23 - club - WOD - female - 1462346 - Hampshire vs Warwickshire
2025-04-23 - club - WOD - female - 1462345 - The Blaze vs Lancashire
2025-04-23 - club - WOD - female - 1462344 - Surrey vs Somerset
2025-04-23 - club - WOD - female - 1462343 - Essex vs Durham
2025-04-19 - international - ODI - female - 1477023 - Thailand vs West Indies
2025-04-19 - international - ODI - female - 1477022 - Bangladesh vs Pakistan
2025-04-18 - international - ODI - female - 1477021 - Scotland vs Ireland
2025-04-17 - international - ODI - female - 1477020 - Pakistan vs Thailand
2025-04-17 - international - ODI - female - 1477019 - Bangladesh vs West Indies
2025-04-15 - international - T20 - female - 1479934 - Namibia vs Uganda
2025-04-15 - international - ODI - female - 1477018 - Bangladesh vs Scotland
2025-04-15 - international - ODI - female - 1477017 - Ireland vs Thailand
2025-04-14 - international - T20 - female - 1479933 - Namibia vs Uganda
2025-04-14 - international - ODI - female - 1477016 - Pakistan vs West Indies
2025-04-13 - international - ODI - female - 1477015 - Ireland vs Bangladesh
2025-04-13 - international - ODI - female - 1477014 - Scotland vs Thailand
2025-04-12 - international - T20 - female - 1479932 - Namibia vs Uganda
2025-04-12 - international - T20 - female - 1477682 - Cook Islands vs Indonesia
2025-04-11 - international - T20 - female - 1479931 - Namibia vs Uganda
2025-04-11 - international - T20 - female - 1477681 - Cook Islands vs Philippines
2025-04-11 - international - ODI - female - 1477013 - West Indies vs Ireland
2025-04-11 - international - ODI - female - 1477012 - Scotland vs Pakistan
2025-04-10 - international - T20 - female - 1477680 - Indonesia vs Philippines
2025-04-10 - international - ODI - female - 1477011 - Bangladesh vs Thailand
2025-04-09 - international - T20 - female - 1479930 - Uganda vs Namibia
2025-04-09 - international - T20 - female - 1478413 - Norway vs Portugal
2025-04-09 - international - T20 - female - 1477679 - Cook Islands vs Indonesia
2025-04-09 - international - ODI - female - 1477010 - Scotland vs West Indies
2025-04-09 - international - ODI - female - 1477009 - Pakistan vs Ireland
2025-04-08 - international - T20 - female - 1479929 - Uganda vs Namibia
2025-04-08 - international - T20 - female - 1478412 - Portugal vs Norway
2025-04-07 - international - T20 - female - 1478411 - Portugal vs Norway
2025-03-26 - international - T20 - female - 1443576 - Australia vs New Zealand
2025-03-23 - international - T20 - female - 1443575 - Australia vs New Zealand
2025-03-21 - international - T20 - female - 1443574 - New Zealand vs Australia
2025-03-18 - international - T20 - female - 1443573 - New Zealand vs Sri Lanka
2025-03-17 - international - T20 - female - 1474992 - United States of America vs Canada
2025-03-17 - international - T20 - female - 1474991 - Argentina vs Brazil
2025-03-16 - international - T20 - female - 1476165 - Namibia vs Uganda
2025-03-16 - international - T20 - female - 1474990 - Argentina vs United States of America
2025-03-16 - international - T20 - female - 1443572 - Sri Lanka vs New Zealand
2025-03-15 - club - WPL - female - 1469319 - Mumbai Indians vs Delhi Capitals
2025-03-14 - international - T20 - female - 1476163 - Uganda vs Namibia
2025-03-14 - international - T20 - female - 1476162 - Hong Kong vs Nepal
2025-03-14 - international - T20 - female - 1474988 - United States of America vs Brazil
2025-03-14 - international - T20 - female - 1474987 - Canada vs Argentina
2025-03-14 - international - T20 - female - 1474429 - Vanuatu vs Samoa
2025-03-14 - international - T20 - female - 1443571 - New Zealand vs Sri Lanka
2025-03-13 - international - T20 - female - 1476161 - Uganda vs Nepal
2025-03-13 - international - T20 - female - 1476160 - Hong Kong vs Namibia
2025-03-13 - international - T20 - female - 1474986 - Brazil vs Canada
2025-03-13 - international - T20 - female - 1474985 - United States of America vs Argentina
2025-03-13 - international - T20 - female - 1474422 - Fiji vs France
2025-03-13 - club - WPL - female - 1469318 - Mumbai Indians vs Gujarat Giants
2025-03-12 - international - T20 - female - 1476159 - Uganda vs Hong Kong
2025-03-12 - international - T20 - female - 1476158 - Namibia vs Nepal
2025-03-12 - international - T20 - female - 1474427 - Vanuatu vs Fiji
2025-03-12 - international - T20 - female - 1474426 - France vs Samoa
2025-03-11 - international - T20 - female - 1474984 - Argentina vs Canada
2025-03-11 - international - T20 - female - 1474983 - United States of America vs Brazil
2025-03-11 - international - T20 - female - 1474424 - Vanuatu vs France
2025-03-11 - club - WPL - female - 1469317 - Royal Challengers Bengaluru vs Mumbai Indians
2025-03-10 - international - T20 - female - 1476157 - Hong Kong vs Nepal
2025-03-10 - international - T20 - female - 1476156 - Uganda vs Namibia
2025-03-10 - international - T20 - female - 1474982 - Brazil vs Argentina
2025-03-10 - international - T20 - female - 1474981 - Canada vs United States of America
2025-03-10 - international - T20 - female - 1474423 - Vanuatu vs Samoa
2025-03-10 - club - WPL - female - 1469316 - Mumbai Indians vs Gujarat Giants
2025-03-09 - international - T20 - female - 1476155 - Namibia vs Hong Kong
2025-03-09 - international - T20 - female - 1476154 - Uganda vs Nepal
2025-03-09 - international - ODI - female - 1443570 - New Zealand vs Sri Lanka
2025-03-08 - international - T20 - female - 1476153 - Nepal vs Namibia
2025-03-08 - international - T20 - female - 1476152 - Hong Kong vs Uganda
2025-03-08 - club - WPL - female - 1469315 - UP Warriorz vs Royal Challengers Bengaluru
2025-03-07 - international - ODI - female - 1443569 - New Zealand vs Sri Lanka
2025-03-07 - club - WPL - female - 1469314 - Delhi Capitals vs Gujarat Giants
2025-03-06 - club - WPL - female - 1469313 - UP Warriorz vs Mumbai Indians
2025-03-04 - international - ODI - female - 1443568 - Sri Lanka vs New Zealand
2025-03-03 - club - WPL - female - 1469312 - Gujarat Giants vs UP Warriorz
2025-03-01 - club - WPL - female - 1469311 - Royal Challengers Bengaluru vs Delhi Capitals
2025-02-28 - club - WPL - female - 1469310 - Mumbai Indians vs Delhi Capitals
2025-02-27 - club - WPL - female - 1469309 - Royal Challengers Bengaluru vs Gujarat Giants
2025-02-26 - club - WPL - female - 1469308 - UP Warriorz vs Mumbai Indians
2025-02-25 - club - WPL - female - 1469307 - Gujarat Giants vs Delhi Capitals
2025-02-24 - club - WPL - female - 1469306 - Royal Challengers Bengaluru vs UP Warriorz
2025-02-22 - club - WPL - female - 1469305 - UP Warriorz vs Delhi Capitals
2025-02-21 - club - WPL - female - 1469304 - Royal Challengers Bengaluru vs Mumbai Indians
2025-02-19 - club - WPL - female - 1469303 - UP Warriorz vs Delhi Capitals
2025-02-18 - club - WPL - female - 1469302 - Gujarat Giants vs Mumbai Indians
2025-02-17 - club - WPL - female - 1469301 - Delhi Capitals vs Royal Challengers Bengaluru
2025-02-16 - club - WPL - female - 1469300 - UP Warriorz vs Gujarat Giants
2025-02-15 - club - WPL - female - 1469299 - Mumbai Indians vs Delhi Capitals
2025-02-14 - club - WPL - female - 1469298 - Gujarat Giants vs Royal Challengers Bengaluru
2025-02-07 - international - T20 - female - 1468731 - Nepal vs Thailand
2025-02-06 - international - T20 - female - 1468732 - Thailand vs Netherlands
2025-02-05 - international - T20 - female - 1468730 - Nepal vs Netherlands
2025-02-04 - international - T20 - female - 1468728 - Thailand vs Nepal
2025-02-03 - international - T20 - female - 1468729 - Thailand vs Netherlands
2025-02-02 - international - T20 - female - 1468727 - Netherlands vs Nepal
2025-02-02 - club - SSM - female - 1452588 - Wellington vs Otago
2025-02-01 - international - T20 - female - 1468725 - Nepal vs Thailand
2025-02-01 - club - SSM - female - 1452587 - Wellington vs Northern Districts
2025-01-31 - international - T20 - female - 1468726 - Netherlands vs Thailand
2025-01-31 - international - T20 - female - 1468404 - Bangladesh vs West Indies
2025-01-30 - international - Test - female - 1426629 - England vs Australia
2025-01-30 - international - T20 - female - 1468724 - Netherlands vs Nepal
2025-01-30 - club - SSM - female - 1452586 - Wellington vs Northern Districts
2025-01-29 - international - T20 - female - 1468403 - West Indies vs Bangladesh
2025-01-29 - club - SSM - female - 1452585 - Auckland vs Central Districts
2025-01-28 - club - SSM - female - 1452584 - Canterbury vs Northern Districts
2025-01-27 - international - T20 - female - 1468402 - Bangladesh vs West Indies
2025-01-27 - club - SSM - female - 1452583 - Auckland vs Wellington
2025-01-26 - club - SSM - female - 1452582 - Canterbury vs Central Districts
2025-01-25 - international - T20 - female - 1426628 - Australia vs England
2025-01-25 - club - SSM - female - 1452581 - Northern Districts vs Otago
2025-01-24 - international - ODI - female - 1468401 - Bangladesh vs West Indies
2025-01-24 - club - SSM - female - 1452580 - Canterbury vs Wellington
2025-01-23 - international - T20 - female - 1426627 - Australia vs England
2025-01-23 - club - SSM - female - 1452579 - Auckland vs Otago
2025-01-22 - club - SSM - female - 1452578 - Wellington vs Canterbury
2025-01-21 - international - ODI - female - 1468400 - Bangladesh vs West Indies
2025-01-20 - international - T20 - female - 1426626 - Australia vs England
2025-01-20 - club - SSM - female - 1452576 - Wellington vs Auckland
2025-01-19 - international - ODI - female - 1468399 - Bangladesh vs West Indies
2025-01-19 - club - SSM - female - 1452575 - Northern Districts vs Canterbury
2025-01-18 - club - SSM - female - 1452574 - Wellington vs Otago
2025-01-17 - international - ODI - female - 1426625 - Australia vs England
2025-01-17 - club - SSM - female - 1452573 - Canterbury vs Central Districts
2025-01-16 - club - SSM - female - 1452572 - Otago vs Northern Districts
2025-01-15 - international - ODI - female - 1459899 - India vs Ireland
2025-01-15 - club - SSM - female - 1452571 - Auckland vs Central Districts
2025-01-14 - international - ODI - female - 1426624 - Australia vs England
2025-01-14 - club - SSM - female - 1452570 - Wellington vs Otago
2025-01-13 - club - SSM - female - 1452569 - Northern Districts vs Auckland
2025-01-12 - international - ODI - female - 1459898 - India vs Ireland
2025-01-12 - international - ODI - female - 1426623 - England vs Australia
2025-01-12 - club - SSM - female - 1452568 - Central Districts vs Otago
2025-01-10 - international - ODI - female - 1459897 - Ireland vs India
2025-01-10 - club - SSM - female - 1452567 - Auckland vs Canterbury
2025-01-09 - club - SSM - female - 1452566 - Central Districts vs Wellington
2025-01-07 - club - SSM - female - 1452565 - Otago vs Canterbury
2025-01-06 - club - SSM - female - 1452564 - Central Districts vs Northern Districts
2025-01-04 - club - SSM - female - 1452563 - Wellington vs Central Districts
2025-01-03 - club - SSM - female - 1452562 - Auckland vs Canterbury
2025-01-01 - club - SSM - female - 1452561 - Wellington vs Northern Districts
2024-12-31 - club - SSM - female - 1452560 - Central Districts vs Otago
2024-12-29 - club - SSM - female - 1452559 - Auckland vs Otago
2024-12-27 - international - T20 - female - 1464732 - Singapore vs Philippines
2024-12-27 - international - T20 - female - 1464728 - Bhutan vs Myanmar
2024-12-27 - international - ODI - female - 1459896 - West Indies vs India
2024-12-27 - club - SSM - female - 1452558 - Canterbury vs Otago
2024-12-26 - international - T20 - female - 1464731 - Philippines vs Singapore
2024-12-26 - international - T20 - female - 1464727 - Bhutan vs Myanmar
2024-12-26 - club - SSM - female - 1452557 - Northern Districts vs Auckland
2024-12-24 - international - T20 - female - 1464730 - Singapore vs Philippines
2024-12-24 - international - T20 - female - 1464726 - Myanmar vs Bhutan
2024-12-24 - international - ODI - female - 1459895 - India vs West Indies
2024-12-23 - international - ODI - female - 1443567 - Australia vs New Zealand
2024-12-22 - international - T20 - female - 1464725 - Bhutan vs Myanmar
2024-12-22 - international - ODI - female - 1459894 - India vs West Indies
2024-12-21 - international - ODI - female - 1443566 - Australia vs New Zealand
2024-12-19 - international - T20 - female - 1459893 - India vs West Indies
2024-12-17 - international - T20 - female - 1459892 - India vs West Indies
2024-12-16 - international - T20 - female - 1464723 - Gibraltar vs Jersey
2024-12-15 - international - Test - female - 1432231 - England vs South Africa
2024-12-15 - international - T20 - female - 1464722 - Gibraltar vs Jersey
2024-12-15 - international - T20 - female - 1459891 - India vs West Indies
2024-12-12 - international - T20 - female - 1462860 - Malaysia vs Namibia
2024-12-11 - international - ODI - female - 1432230 - South Africa vs England
2024-12-11 - international - ODI - female - 1426622 - Australia vs India
2024-12-10 - international - T20 - female - 1462858 - Malaysia vs Namibia
2024-12-09 - international - T20 - female - 1458416 - Bangladesh vs Ireland
2024-12-08 - international - T20 - female - 1463011 - Bahrain vs Qatar
2024-12-08 - international - T20 - female - 1462857 - Thailand vs Namibia
2024-12-08 - international - T20 - female - 1462856 - Hong Kong vs China
2024-12-08 - international - ODI - female - 1432229 - South Africa vs England
2024-12-08 - international - ODI - female - 1426621 - Australia vs India
2024-12-07 - international - T20 - female - 1463010 - Bahrain vs Qatar
2024-12-07 - international - T20 - female - 1462855 - Hong Kong vs Namibia
2024-12-07 - international - T20 - female - 1462854 - Thailand vs China
2024-12-07 - international - T20 - female - 1458415 - Ireland vs Bangladesh
2024-12-06 - international - T20 - female - 1463009 - Bahrain vs Qatar
2024-12-05 - international - T20 - female - 1462853 - Thailand vs Hong Kong
2024-12-05 - international - T20 - female - 1462852 - China vs Namibia
2024-12-05 - international - T20 - female - 1458414 - Ireland vs Bangladesh
2024-12-05 - international - ODI - female - 1426620 - India vs Australia
2024-12-04 - international - T20 - female - 1463008 - Bahrain vs Qatar
2024-12-04 - international - T20 - female - 1462851 - Hong Kong vs China
2024-12-04 - international - T20 - female - 1462850 - Namibia vs Thailand
2024-12-04 - international - ODI - female - 1432228 - England vs South Africa
2024-12-02 - international - ODI - female - 1458413 - Ireland vs Bangladesh
2024-12-01 - club - WBB - female - 1442688 - Melbourne Renegades vs Brisbane Heat
2024-11-30 - international - T20 - female - 1432227 - South Africa vs England
2024-11-30 - international - ODI - female - 1458412 - Ireland vs Bangladesh
2024-11-29 - club - WBB - female - 1442687 - Sydney Thunder vs Brisbane Heat
2024-11-27 - international - T20 - female - 1432226 - England vs South Africa
2024-11-27 - international - ODI - female - 1458411 - Bangladesh vs Ireland
2024-11-27 - club - WBB - female - 1442686 - Hobart Hurricanes vs Sydney Thunder
2024-11-24 - international - T20 - female - 1432225 - South Africa vs England
2024-11-24 - club - WBB - female - 1442685 - Sydney Sixers vs Brisbane Heat
2024-11-23 - club - WBB - female - 1442683 - Perth Scorchers vs Hobart Hurricanes
2024-11-23 - club - WBB - female - 1442682 - Sydney Thunder vs Melbourne Renegades
2024-11-22 - club - WBB - female - 1442681 - Melbourne Stars vs Brisbane Heat
2024-11-21 - club - WBB - female - 1442680 - Melbourne Renegades vs Hobart Hurricanes
2024-11-21 - club - WBB - female - 1442679 - Perth Scorchers vs Sydney Sixers
2024-11-20 - club - WBB - female - 1442678 - Melbourne Stars vs Sydney Thunder
2024-11-19 - club - WBB - female - 1442677 - Adelaide Strikers vs Perth Scorchers
2024-11-17 - international - T20 - female - 1459720 - Costa Rica vs Mexico
2024-11-17 - club - WBB - female - 1442676 - Sydney Thunder vs Sydney Sixers
2024-11-17 - club - WBB - female - 1442675 - Melbourne Stars vs Brisbane Heat
2024-11-16 - international - T20 - female - 1459719 - Costa Rica vs Mexico
2024-11-16 - international - T20 - female - 1459718 - Costa Rica vs Mexico
2024-11-16 - club - WBB - female - 1442674 - Adelaide Strikers vs Hobart Hurricanes
2024-11-15 - club - WBB - female - 1442673 - Melbourne Renegades vs Melbourne Stars
2024-11-15 - club - WBB - female - 1442672 - Perth Scorchers vs Sydney Thunder
2024-11-14 - club - WBB - female - 1442671 - Brisbane Heat vs Sydney Sixers
2024-11-13 - club - WBB - female - 1442670 - Hobart Hurricanes vs Adelaide Strikers
2024-11-12 - club - WBB - female - 1442669 - Perth Scorchers vs Sydney Thunder
2024-11-11 - club - WBB - female - 1442668 - Adelaide Strikers vs Melbourne Renegades
2024-11-10 - international - T20 - female - 1456865 - China vs Hong Kong
2024-11-10 - international - T20 - female - 1456864 - Mongolia vs Myanmar
2024-11-10 - club - WBB - female - 1442667 - Sydney Thunder vs Sydney Sixers
2024-11-10 - club - WBB - female - 1442666 - Hobart Hurricanes vs Perth Scorchers
2024-11-09 - international - T20 - female - 1456863 - Mongolia vs Hong Kong
2024-11-09 - international - T20 - female - 1456862 - Myanmar vs China
2024-11-09 - club - WBB - female - 1442665 - Brisbane Heat vs Adelaide Strikers
2024-11-09 - club - WBB - female - 1442664 - Melbourne Renegades vs Melbourne Stars
2024-11-08 - international - T20 - female - 1456859 - Myanmar vs Mongolia
2024-11-08 - international - T20 - female - 1456858 - China vs Hong Kong
2024-11-08 - club - WBB - female - 1442663 - Melbourne Stars vs Sydney Sixers
2024-11-07 - international - T20 - female - 1456861 - Myanmar vs Hong Kong
2024-11-07 - international - T20 - female - 1456860 - Mongolia vs China
2024-11-07 - club - WBB - female - 1442662 - Perth Scorchers vs Melbourne Renegades
2024-11-07 - club - WBB - female - 1442661 - Sydney Thunder vs Brisbane Heat
2024-11-06 - club - WBB - female - 1442660 - Sydney Sixers vs Hobart Hurricanes
2024-11-05 - club - WBB - female - 1442659 - Perth Scorchers vs Brisbane Heat
2024-11-03 - club - WBB - female - 1442658 - Adelaide Strikers vs Melbourne Renegades
2024-11-03 - club - WBB - female - 1442657 - Hobart Hurricanes vs Melbourne Stars
2024-11-02 - international - T20 - female - 1457358 - Kenya vs Rwanda
2024-11-02 - international - T20 - female - 1457357 - Kenya vs Rwanda
2024-11-02 - club - WBB - female - 1442656 - Perth Scorchers vs Melbourne Renegades
2024-11-02 - club - WBB - female - 1442655 - Brisbane Heat vs Hobart Hurricanes
2024-11-01 - club - WBB - female - 1442654 - Melbourne Stars vs Sydney Sixers
2024-11-01 - club - WBB - female - 1442653 - Sydney Thunder vs Adelaide Strikers
2024-10-31 - international - T20 - female - 1457356 - Rwanda vs Kenya
2024-10-31 - club - WBB - female - 1442652 - Sydney Thunder vs Hobart Hurricanes
2024-10-30 - international - T20 - female - 1457355 - Kenya vs Rwanda
2024-10-30 - international - T20 - female - 1456130 - Kuwait vs Myanmar
2024-10-30 - club - WBB - female - 1442651 - Brisbane Heat vs Melbourne Renegades
2024-10-29 - international - T20 - female - 1457354 - Rwanda vs Kenya
2024-10-29 - international - T20 - female - 1456129 - Singapore vs Kuwait
2024-10-29 - international - ODI - female - 1454393 - New Zealand vs India
2024-10-29 - club - WBB - female - 1442650 - Adelaide Strikers vs Sydney Sixers
2024-10-28 - international - T20 - female - 1456128 - Kuwait vs Myanmar
2024-10-28 - international - ODI - female - 1455371 - Zimbabwe vs United States of America
2024-10-28 - club - WBB - female - 1442649 - Hobart Hurricanes vs Sydney Thunder
2024-10-27 - international - T20 - female - 1456127 - Myanmar vs Singapore
2024-10-27 - international - ODI - female - 1454392 - New Zealand vs India
2024-10-27 - club - WBB - female - 1442648 - Perth Scorchers vs Melbourne Stars
2024-10-27 - club - WBB - female - 1442647 - Melbourne Renegades vs Sydney Sixers
2024-10-27 - club - WBB - female - 1442646 - Adelaide Strikers vs Brisbane Heat
2024-10-26 - international - T20 - female - 1456854 - Bulgaria vs Greece
2024-10-26 - international - T20 - female - 1456126 - Singapore vs Kuwait
2024-10-26 - international - ODI - female - 1455370 - Zimbabwe vs United States of America
2024-10-25 - international - T20 - female - 1456125 - Myanmar vs Kuwait
2024-10-24 - international - T20 - female - 1456124 - Singapore vs Myanmar
2024-10-24 - international - ODI - female - 1454391 - India vs New Zealand
2024-10-23 - international - ODI - female - 1455369 - Zimbabwe vs United States of America
2024-10-22 - international - T20 - female - 1456123 - Singapore vs Kuwait
2024-10-22 - international - T20 - female - 1456122 - Kuwait vs Myanmar
2024-10-21 - international - T20 - female - 1456121 - Singapore vs Myanmar
2024-10-20 - international - T20 - female - 1432444 - New Zealand vs South Africa
2024-10-20 - international - ODI - female - 1455368 - United States of America vs Zimbabwe
2024-10-18 - international - T20 - female - 1432443 - New Zealand vs West Indies
2024-10-17 - international - T20 - female - 1432442 - Australia vs South Africa
2024-10-17 - international - ODI - female - 1455367 - United States of America vs Zimbabwe
2024-10-15 - international - T20 - female - 1432441 - England vs West Indies
2024-10-14 - international - T20 - female - 1432440 - New Zealand vs Pakistan
2024-10-13 - international - T20 - female - 1454937 - Bulgaria vs Serbia
2024-10-13 - international - T20 - female - 1454936 - Bulgaria vs Serbia
2024-10-13 - international - T20 - female - 1451318 - South Korea vs China
2024-10-13 - international - T20 - female - 1432439 - Australia vs India
2024-10-13 - international - T20 - female - 1432438 - Scotland vs England
2024-10-12 - international - T20 - female - 1454935 - Serbia vs Bulgaria
2024-10-12 - international - T20 - female - 1451317 - Hong Kong vs South Korea
2024-10-12 - international - T20 - female - 1432437 - Bangladesh vs South Africa
2024-10-12 - international - T20 - female - 1432436 - Sri Lanka vs New Zealand
2024-10-11 - international - T20 - female - 1432435 - Pakistan vs Australia
2024-10-10 - international - T20 - female - 1432434 - Bangladesh vs West Indies
2024-10-09 - international - T20 - female - 1451311 - Hong Kong vs China
2024-10-09 - international - T20 - female - 1432433 - India vs Sri Lanka
2024-10-09 - international - T20 - female - 1432432 - South Africa vs Scotland
2024-10-08 - international - T20 - female - 1451308 - Hong Kong vs Japan
2024-10-08 - international - T20 - female - 1432431 - Australia vs New Zealand
2024-10-07 - international - T20 - female - 1432430 - South Africa vs England
2024-10-06 - international - T20 - female - 1451307 - Japan vs Singapore
2024-10-06 - international - T20 - female - 1432429 - Scotland vs West Indies
2024-10-06 - international - T20 - female - 1432428 - Pakistan vs India
2024-10-05 - international - T20 - female - 1451306 - Japan vs Singapore
2024-10-05 - international - T20 - female - 1432427 - England vs Bangladesh
2024-10-05 - international - T20 - female - 1432426 - Sri Lanka vs Australia
2024-10-04 - international - T20 - female - 1451305 - Japan vs Singapore
2024-10-04 - international - T20 - female - 1432425 - New Zealand vs India
2024-10-04 - international - T20 - female - 1432424 - West Indies vs South Africa
2024-10-03 - international - T20 - female - 1432423 - Pakistan vs Sri Lanka
2024-10-03 - international - T20 - female - 1432422 - Bangladesh vs Scotland
2024-10-02 - international - T20 - female - 1451304 - Singapore vs Japan
2024-10-01 - international - T20 - female - 1451303 - Singapore vs Japan
2024-09-24 - international - T20 - female - 1426619 - New Zealand vs Australia
2024-09-22 - international - T20 - female - 1451294 - Greece vs Spain
2024-09-22 - international - T20 - female - 1451293 - Greece vs Spain
2024-09-22 - international - T20 - female - 1426618 - Australia vs New Zealand
2024-09-21 - international - T20 - female - 1451292 - Greece vs Spain
2024-09-21 - international - T20 - female - 1451291 - Spain vs Greece
2024-09-21 - club - RHF - female - 1427864 - South East Stars vs Sunrisers
2024-09-20 - international - T20 - female - 1449013 - Pakistan vs South Africa
2024-09-19 - international - T20 - female - 1426617 - New Zealand vs Australia
2024-09-18 - international - T20 - female - 1449012 - Pakistan vs South Africa
2024-09-16 - international - T20 - female - 1449011 - South Africa vs Pakistan
2024-09-15 - international - T20 - female - 1450204 - Norway vs Luxembourg
2024-09-15 - international - T20 - female - 1450202 - Denmark vs Luxembourg
2024-09-15 - international - T20 - female - 1430821 - England vs Ireland
2024-09-14 - international - T20 - female - 1450468 - Cyprus vs Serbia
2024-09-14 - international - T20 - female - 1450467 - Serbia vs Cyprus
2024-09-14 - international - T20 - female - 1450466 - Rwanda vs Kenya
2024-09-14 - international - T20 - female - 1450200 - Austria vs Denmark
2024-09-14 - international - T20 - female - 1450199 - Austria vs Luxembourg
2024-09-14 - international - T20 - female - 1450198 - Denmark vs Norway
2024-09-14 - international - T20 - female - 1449027 - Namibia vs Zimbabwe
2024-09-14 - international - T20 - female - 1430820 - England vs Ireland
2024-09-14 - club - RHF - female - 1427863 - Southern Vipers vs South East Stars
2024-09-14 - club - RHF - female - 1427862 - Northern Diamonds vs Sunrisers
2024-09-13 - international - T20 - female - 1450465 - Kenya vs Rwanda
2024-09-13 - international - T20 - female - 1449026 - Zimbabwe vs United Arab Emirates
2024-09-12 - international - T20 - female - 1449025 - Namibia vs United Arab Emirates
2024-09-11 - international - T20 - female - 1450464 - Kenya vs Rwanda
2024-09-11 - international - T20 - female - 1450463 - Rwanda vs Kenya
2024-09-11 - international - T20 - female - 1449024 - Zimbabwe vs Namibia
2024-09-11 - international - ODI - female - 1430819 - England vs Ireland
2024-09-10 - international - T20 - female - 1450462 - Kenya vs Rwanda
2024-09-10 - international - T20 - female - 1449023 - Zimbabwe vs United Arab Emirates
2024-09-09 - international - T20 - female - 1449022 - United Arab Emirates vs Namibia
2024-09-09 - international - ODI - female - 1430818 - England vs Ireland
2024-09-08 - international - T20 - female - 1449021 - Zimbabwe vs Namibia
2024-09-07 - international - T20 - female - 1449020 - United Arab Emirates vs Zimbabwe
2024-09-07 - international - ODI - female - 1430817 - Ireland vs England
2024-09-07 - club - RHF - female - 1427861 - Sunrisers vs Southern Vipers
2024-09-07 - club - RHF - female - 1427860 - Thunder vs Western Storm
2024-09-07 - club - RHF - female - 1427859 - South East Stars vs Northern Diamonds
2024-09-06 - international - T20 - female - 1449019 - Namibia vs United Arab Emirates
2024-09-06 - club - RHF - female - 1427858 - The Blaze vs Central Sparks
2024-09-04 - club - RHF - female - 1427857 - The Blaze vs Thunder
2024-09-04 - club - RHF - female - 1427856 - South East Stars vs Central Sparks
2024-09-04 - club - RHF - female - 1427855 - Western Storm vs Sunrisers
2024-09-04 - club - RHF - female - 1427854 - Southern Vipers vs Northern Diamonds
2024-09-01 - club - RHF - female - 1427853 - Northern Diamonds vs Thunder
2024-08-31 - club - RHF - female - 1427852 - Western Storm vs South East Stars
2024-08-31 - club - RHF - female - 1427851 - Sunrisers vs The Blaze
2024-08-30 - club - RHF - female - 1427850 - Southern Vipers vs Central Sparks
2024-08-29 - club - WCL - female - 1443205 - Trinbago Knight Riders vs Barbados Royals
2024-08-27 - club - WCL - female - 1443204 - Barbados Royals vs Trinbago Knight Riders
2024-08-26 - club - WCL - female - 1443203 - Barbados Royals vs Guyana Amazon Warriors
2024-08-26 - club - RHF - female - 1427849 - The Blaze vs Southern Vipers
2024-08-26 - club - RHF - female - 1427848 - Northern Diamonds vs Sunrisers
2024-08-26 - club - RHF - female - 1427847 - Central Sparks vs Western Storm
2024-08-26 - club - RHF - female - 1427846 - Thunder vs South East Stars
2024-08-25 - international - T20 - female - 1447553 - Greece vs Isle of Man
2024-08-25 - international - T20 - female - 1447551 - Greece vs Serbia
2024-08-25 - club - WCL - female - 1443202 - Trinbago Knight Riders vs Guyana Amazon Warriors
2024-08-24 - international - T20 - female - 1447550 - Isle of Man vs Greece
2024-08-23 - club - WCL - female - 1443201 - Trinbago Knight Riders vs Guyana Amazon Warriors
2024-08-22 - club - WCL - female - 1443200 - Trinbago Knight Riders vs Barbados Royals
2024-08-21 - international - T20 - female - 1447543 - Malta vs Isle of Man
2024-08-21 - club - WCL - female - 1443199 - Guyana Amazon Warriors vs Barbados Royals
2024-08-20 - international - ODI - female - 1430816 - Ireland vs Sri Lanka
2024-08-18 - international - ODI - female - 1430815 - Ireland vs Sri Lanka
2024-08-18 - club - HND - female - 1417857 - Welsh Fire vs London Spirit
2024-08-17 - club - HND - female - 1417856 - Oval Invincibles vs London Spirit
2024-08-16 - international - T20 - female - 1444551 - Scotland vs Netherlands
2024-08-16 - international - ODI - female - 1430814 - Sri Lanka vs Ireland
2024-08-15 - international - T20 - female - 1444550 - Scotland vs Papua New Guinea
2024-08-15 - club - HND - female - 1417855 - Birmingham Phoenix vs Manchester Originals
2024-08-14 - international - T20 - female - 1444549 - Netherlands vs Papua New Guinea
2024-08-14 - club - HND - female - 1417854 - Trent Rockets vs Oval Invincibles
2024-08-14 - club - HND - female - 1417853 - Southern Brave vs Welsh Fire
2024-08-13 - international - T20 - female - 1430813 - Ireland vs Sri Lanka
2024-08-13 - club - HND - female - 1417852 - Northern Superchargers vs London Spirit
2024-08-12 - international - ODI - female - 1444548 - Scotland vs Netherlands
2024-08-12 - club - HND - female - 1417851 - Birmingham Phoenix vs Trent Rockets
2024-08-11 - international - T20 - female - 1445493 - Estonia vs Denmark
2024-08-11 - international - T20 - female - 1445489 - Norway vs Guernsey
2024-08-11 - international - T20 - female - 1445485 - Denmark vs Norway
2024-08-11 - international - T20 - female - 1430812 - Ireland vs Sri Lanka
2024-08-11 - international - ODI - female - 1444547 - Papua New Guinea vs Scotland
2024-08-11 - club - HND - female - 1417850 - Manchester Originals vs Northern Superchargers
2024-08-11 - club - HND - female - 1417849 - London Spirit vs Oval Invincibles
2024-08-10 - international - T20 - female - 1445491 - Norway vs Estonia
2024-08-10 - club - HND - female - 1417848 - Birmingham Phoenix vs Welsh Fire
2024-08-10 - club - HND - female - 1417847 - Trent Rockets vs Southern Brave
2024-08-09 - international - ODI - female - 1444546 - Papua New Guinea vs Netherlands
2024-08-09 - club - HND - female - 1417846 - Manchester Originals vs London Spirit
2024-08-08 - international - ODI - female - 1444545 - Scotland vs Netherlands
2024-08-08 - club - HND - female - 1417845 - Oval Invincibles vs Southern Brave
2024-08-07 - club - HND - female - 1417843 - Trent Rockets vs London Spirit
2024-08-06 - international - ODI - female - 1444544 - Scotland vs Papua New Guinea
2024-08-06 - club - HND - female - 1417842 - Northern Superchargers vs Birmingham Phoenix
2024-08-06 - club - HND - female - 1417841 - Manchester Originals vs Oval Invincibles
2024-08-05 - international - ODI - female - 1444543 - Papua New Guinea vs Netherlands
2024-08-05 - club - HND - female - 1417840 - Southern Brave vs Welsh Fire
2024-08-04 - club - HND - female - 1417839 - Northern Superchargers vs Manchester Originals
2024-08-04 - club - HND - female - 1417838 - London Spirit vs Oval Invincibles
2024-08-03 - club - HND - female - 1417837 - Trent Rockets vs Welsh Fire
2024-08-03 - club - HND - female - 1417836 - Birmingham Phoenix vs Southern Brave
2024-08-02 - club - HND - female - 1417835 - Northern Superchargers vs Oval Invincibles
2024-08-01 - club - HND - female - 1417834 - Southern Brave vs Manchester Originals
2024-08-01 - club - HND - female - 1417833 - London Spirit vs Welsh Fire
2024-07-31 - club - HND - female - 1417832 - Birmingham Phoenix vs Trent Rockets
2024-07-30 - club - HND - female - 1417831 - Southern Brave vs Northern Superchargers
2024-07-29 - club - HND - female - 1417830 - Manchester Originals vs Trent Rockets
2024-07-28 - international - T20 - female - 1444669 - Italy vs Germany
2024-07-28 - international - T20 - female - 1444537 - Germany vs Italy
2024-07-28 - international - T20 - female - 1426770 - India vs Sri Lanka
2024-07-28 - club - HND - female - 1417829 - Welsh Fire vs Oval Invincibles
2024-07-27 - international - T20 - female - 1444536 - Italy vs Jersey
2024-07-27 - international - T20 - female - 1444535 - Germany vs Jersey
2024-07-27 - international - T20 - female - 1444534 - Italy vs Germany
2024-07-27 - club - HND - female - 1417828 - London Spirit vs Birmingham Phoenix
2024-07-26 - international - T20 - female - 1444532 - Germany vs Jersey
2024-07-26 - international - T20 - female - 1444531 - Germany vs Italy
2024-07-26 - international - T20 - female - 1426769 - Pakistan vs Sri Lanka
2024-07-26 - international - T20 - female - 1426768 - Bangladesh vs India
2024-07-26 - club - HND - female - 1417827 - Trent Rockets vs Northern Superchargers
2024-07-25 - club - HND - female - 1417826 - Manchester Originals vs Welsh Fire
2024-07-24 - international - T20 - female - 1426767 - Thailand vs Sri Lanka
2024-07-24 - international - T20 - female - 1426766 - Bangladesh vs Malaysia
2024-07-24 - club - HND - female - 1417825 - Southern Brave vs London Spirit
2024-07-23 - international - T20 - female - 1426765 - India vs Nepal
2024-07-23 - international - T20 - female - 1426764 - United Arab Emirates vs Pakistan
2024-07-23 - club - HND - female - 1417824 - Oval Invincibles vs Birmingham Phoenix
2024-07-22 - international - T20 - female - 1426763 - Thailand vs Bangladesh
2024-07-22 - international - T20 - female - 1426762 - Sri Lanka vs Malaysia
2024-07-21 - international - T20 - female - 1426761 - Nepal vs Pakistan
2024-07-21 - international - T20 - female - 1426760 - India vs United Arab Emirates
2024-07-20 - international - T20 - female - 1426759 - Bangladesh vs Sri Lanka
2024-07-20 - international - T20 - female - 1426758 - Thailand vs Malaysia
2024-07-19 - international - T20 - female - 1426757 - Pakistan vs India
2024-07-19 - international - T20 - female - 1426756 - United Arab Emirates vs Nepal
2024-07-17 - international - T20 - female - 1398281 - England vs New Zealand
2024-07-14 - international - T20 - female - 1442996 - Jersey vs Guernsey
2024-07-14 - club - RHF - female - 1427844 - South East Stars vs Sunrisers
2024-07-14 - club - RHF - female - 1427843 - Northern Diamonds vs The Blaze
2024-07-13 - international - T20 - female - 1398280 - New Zealand vs England
2024-07-12 - club - RHF - female - 1427842 - Western Storm vs Central Sparks
2024-07-11 - international - T20 - female - 1398279 - New Zealand vs England
2024-07-10 - club - RHF - female - 1427841 - South East Stars vs Southern Vipers
2024-07-10 - club - RHF - female - 1427840 - Western Storm vs The Blaze
2024-07-10 - club - RHF - female - 1427839 - Central Sparks vs Thunder
2024-07-10 - club - RHF - female - 1427838 - Sunrisers vs Northern Diamonds
2024-07-09 - international - T20 - female - 1434293 - South Africa vs India
2024-07-09 - international - T20 - female - 1398278 - England vs New Zealand
2024-07-08 - international - T20 - female - 1440451 - Bhutan vs Singapore
2024-07-07 - international - T20 - female - 1440450 - Indonesia vs Singapore
2024-07-07 - international - T20 - female - 1440449 - Indonesia vs Bhutan
2024-07-07 - international - T20 - female - 1434292 - South Africa vs India
2024-07-07 - club - RHF - female - 1427837 - South East Stars vs Thunder
2024-07-07 - club - RHF - female - 1427836 - Central Sparks vs Sunrisers
2024-07-07 - club - RHF - female - 1427835 - Western Storm vs Northern Diamonds
2024-07-06 - international - T20 - female - 1440448 - Bhutan vs Singapore
2024-07-06 - international - T20 - female - 1398277 - England vs New Zealand
2024-07-05 - international - T20 - female - 1440447 - Indonesia vs Singapore
2024-07-05 - international - T20 - female - 1434291 - South Africa vs India
2024-07-05 - club - RHF - female - 1427834 - The Blaze vs Southern Vipers
2024-07-03 - international - T20 - female - 1440446 - Bhutan vs Indonesia
2024-07-03 - international - ODI - female - 1398276 - New Zealand vs England
2024-07-02 - international - T20 - female - 1440444 - Singapore vs Indonesia
2024-07-02 - international - T20 - female - 1440443 - Indonesia vs Bhutan
2024-06-30 - international - ODI - female - 1398275 - New Zealand vs England
2024-06-30 - club - RHF - female - 1427833 - Western Storm vs Southern Vipers
2024-06-30 - club - RHF - female - 1427832 - Sunrisers vs Thunder
2024-06-30 - club - RHF - female - 1427831 - The Blaze vs South East Stars
2024-06-30 - club - RHF - female - 1427830 - Central Sparks vs Northern Diamonds
2024-06-28 - international - Test - female - 1434290 - India vs South Africa
2024-06-28 - international - T20 - female - 1436891 - Sri Lanka vs West Indies
2024-06-26 - international - T20 - female - 1436890 - Sri Lanka vs West Indies
2024-06-26 - international - ODI - female - 1398274 - New Zealand vs England
2024-06-24 - international - T20 - female - 1436889 - West Indies vs Sri Lanka
2024-06-23 - international - ODI - female - 1434289 - South Africa vs India
2024-06-22 - club - CEC - female - 1410550 - South East Stars vs The Blaze
2024-06-22 - club - CEC - female - 1410549 - South East Stars vs Southern Vipers
2024-06-22 - club - CEC - female - 1410548 - Central Sparks vs The Blaze
2024-06-21 - international - ODI - female - 1436888 - Sri Lanka vs West Indies
2024-06-19 - international - T20 - female - 1438105 - Netherlands vs Hong Kong
2024-06-19 - international - T20 - female - 1438104 - Hong Kong vs Netherlands
2024-06-19 - international - T20 - female - 1438101 - Cyprus vs Estonia
2024-06-19 - international - ODI - female - 1434288 - India vs South Africa
2024-06-19 - club - CEC - female - 1410547 - Southern Vipers vs South East Stars
2024-06-19 - club - CEC - female - 1410546 - Central Sparks vs The Blaze
2024-06-19 - club - CEC - female - 1410545 - Thunder vs Northern Diamonds
2024-06-19 - club - CEC - female - 1410544 - Western Storm vs Sunrisers
2024-06-18 - international - T20 - female - 1438103 - Hong Kong vs Netherlands
2024-06-18 - international - T20 - female - 1438099 - Cyprus vs Estonia
2024-06-18 - international - ODI - female - 1436887 - West Indies vs Sri Lanka
2024-06-17 - international - T20 - female - 1438102 - Netherlands vs Hong Kong
2024-06-17 - international - T20 - female - 1438097 - Estonia vs Cyprus
2024-06-16 - international - T20 - female - 1438095 - Gibraltar vs Czech Republic
2024-06-16 - international - T20 - female - 1438094 - Croatia vs Gibraltar
2024-06-16 - international - ODI - female - 1434287 - India vs South Africa
2024-06-16 - club - CEC - female - 1410543 - Southern Vipers vs Central Sparks
2024-06-16 - club - CEC - female - 1410542 - Northern Diamonds vs Western Storm
2024-06-16 - club - CEC - female - 1410541 - The Blaze vs South East Stars
2024-06-15 - international - T20 - female - 1438093 - Czech Republic vs Croatia
2024-06-15 - international - T20 - female - 1438092 - Croatia vs Gibraltar
2024-06-15 - international - ODI - female - 1436886 - West Indies vs Sri Lanka
2024-06-15 - club - CEC - female - 1410540 - South East Stars vs Sunrisers
2024-06-14 - international - T20 - female - 1438091 - Croatia vs Czech Republic
2024-06-14 - international - T20 - female - 1438090 - Gibraltar vs Czech Republic
2024-06-14 - club - CEC - female - 1410539 - Thunder vs Central Sparks
2024-06-14 - club - CEC - female - 1410538 - Northern Diamonds vs Southern Vipers
2024-06-13 - club - CEC - female - 1410537 - Sunrisers vs The Blaze
2024-06-09 - club - CEC - female - 1410535 - Sunrisers vs Thunder
2024-06-09 - club - CEC - female - 1410534 - The Blaze vs Northern Diamonds
2024-06-09 - club - CEC - female - 1410533 - South East Stars vs Central Sparks
2024-06-09 - club - CEC - female - 1410532 - Southern Vipers vs Western Storm
2024-06-08 - international - T20 - female - 1435648 - Nigeria vs Rwanda
2024-06-08 - international - T20 - female - 1435647 - Kenya vs Botswana
2024-06-08 - international - T20 - female - 1435646 - Cameroon vs Malawi
2024-06-08 - club - CEC - female - 1410531 - Northern Diamonds vs Central Sparks
2024-06-07 - international - T20 - female - 1435645 - Kenya vs Botswana
2024-06-07 - international - T20 - female - 1435644 - Nigeria vs Malawi
2024-06-07 - international - T20 - female - 1435643 - Uganda vs Cameroon
2024-06-07 - club - CEC - female - 1410530 - Thunder vs Southern Vipers
2024-06-07 - club - CEC - female - 1410529 - Western Storm vs The Blaze
2024-06-06 - club - CEC - female - 1410528 - Sunrisers vs South East Stars
2024-06-05 - international - T20 - female - 1435640 - Uganda vs Rwanda
2024-06-05 - international - T20 - female - 1435639 - Botswana vs Malawi
2024-06-05 - international - T20 - female - 1435638 - Cameroon vs Kenya
2024-06-04 - international - T20 - female - 1435637 - Cameroon vs Malawi
2024-06-04 - international - T20 - female - 1435635 - Kenya vs Uganda
2024-06-04 - international - T20 - female - 1435634 - Nigeria vs Rwanda
2024-06-03 - international - T20 - female - 1435633 - Rwanda vs Kenya
2024-06-03 - international - T20 - female - 1435632 - Botswana vs Nigeria
2024-06-03 - international - T20 - female - 1435630 - Uganda vs Malawi
2024-06-02 - international - T20 - female - 1435621 - Kenya vs Nigeria
2024-06-02 - club - CEC - female - 1410527 - Northern Diamonds vs Sunrisers
2024-06-02 - club - CEC - female - 1410526 - Southern Vipers vs South East Stars
2024-06-02 - club - CEC - female - 1410525 - Thunder vs The Blaze
2024-06-01 - international - T20 - female - 1435628 - Cameroon vs Nigeria
2024-06-01 - international - T20 - female - 1435627 - Kenya vs Malawi
2024-06-01 - international - T20 - female - 1435626 - Rwanda vs Botswana
2024-05-31 - international - T20 - female - 1435625 - Malawi vs Rwanda
2024-05-31 - international - T20 - female - 1435624 - Botswana vs Cameroon
2024-05-31 - international - T20 - female - 1435623 - Uganda vs Nigeria
2024-05-31 - club - CEC - female - 1410524 - The Blaze vs Central Sparks
2024-05-31 - club - CEC - female - 1410523 - Western Storm vs Sunrisers
2024-05-31 - club - CEC - female - 1410522 - Northern Diamonds vs South East Stars
2024-05-30 - international - T20 - female - 1435620 - Uganda vs Botswana
2024-05-30 - international - T20 - female - 1435618 - Rwanda vs Cameroon
2024-05-30 - international - T20 - female - 1433775 - Italy vs Netherlands
2024-05-30 - club - CEC - female - 1410521 - Central Sparks vs Thunder
2024-05-30 - club - CEC - female - 1410520 - Southern Vipers vs Western Storm
2024-05-29 - international - ODI - female - 1398273 - England vs Pakistan
2024-05-28 - international - T20 - female - 1433772 - Netherlands vs Italy
2024-05-27 - club - CEC - female - 1410519 - Northern Diamonds vs Central Sparks
2024-05-27 - club - CEC - female - 1410518 - Western Storm vs South East Stars
2024-05-27 - club - CEC - female - 1410517 - Sunrisers vs Southern Vipers
2024-05-26 - international - ODI - female - 1398272 - Pakistan vs England
2024-05-26 - club - CEC - female - 1410516 - Thunder vs The Blaze
2024-05-24 - club - CEC - female - 1410515 - Southern Vipers vs Sunrisers
2024-05-24 - club - CEC - female - 1410514 - Thunder vs South East Stars
2024-05-23 - international - ODI - female - 1398271 - England vs Pakistan
2024-05-23 - club - CEC - female - 1410513 - The Blaze vs Northern Diamonds
2024-05-22 - club - CEC - female - 1410512 - Central Sparks vs Western Storm
2024-05-19 - international - T20 - female - 1398270 - England vs Pakistan
2024-05-19 - club - CEC - female - 1410511 - Sunrisers vs Central Sparks
2024-05-19 - club - CEC - female - 1410510 - Northern Diamonds vs Thunder
2024-05-19 - club - CEC - female - 1410509 - South East Stars vs Western Storm
2024-05-18 - club - CEC - female - 1410508 - The Blaze vs Southern Vipers
2024-05-17 - international - T20 - female - 1398269 - England vs Pakistan
2024-05-11 - international - T20 - female - 1398268 - England vs Pakistan
2024-05-09 - international - T20 - female - 1429397 - India vs Bangladesh
2024-05-08 - club - RHF - female - 1427829 - Western Storm vs The Blaze
2024-05-08 - club - RHF - female - 1427828 - Thunder vs Central Sparks
2024-05-08 - club - RHF - female - 1427827 - Southern Vipers vs Sunrisers
2024-05-08 - club - RHF - female - 1427826 - Northern Diamonds vs South East Stars
2024-05-07 - international - T20 - female - 1425660 - Sri Lanka vs Scotland
2024-05-06 - international - T20 - female - 1429396 - India vs Bangladesh
2024-05-06 - club - RHF - female - 1427825 - The Blaze vs Thunder
2024-05-05 - international - T20 - female - 1425659 - Sri Lanka vs United Arab Emirates
2024-05-05 - international - T20 - female - 1425658 - Ireland vs Scotland
2024-05-04 - club - RHF - female - 1427824 - Sunrisers vs South East Stars
2024-05-04 - club - RHF - female - 1427823 - Southern Vipers vs Western Storm
2024-05-04 - club - RHF - female - 1427822 - Northern Diamonds vs Central Sparks
2024-05-03 - international - T20 - female - 1426088 - Pakistan vs West Indies
2024-05-03 - international - T20 - female - 1425657 - Ireland vs Netherlands
2024-05-03 - international - T20 - female - 1425656 - Sri Lanka vs United States of America
2024-05-03 - international - T20 - female - 1425655 - United Arab Emirates vs Vanuatu
2024-05-03 - international - T20 - female - 1425654 - Thailand vs Scotland
2024-05-02 - international - T20 - female - 1429395 - Bangladesh vs India
2024-05-02 - international - T20 - female - 1426087 - West Indies vs Pakistan
2024-05-01 - international - T20 - female - 1425653 - United States of America vs Thailand
2024-05-01 - international - T20 - female - 1425652 - Vanuatu vs Ireland
2024-05-01 - international - T20 - female - 1425651 - Sri Lanka vs Uganda
2024-05-01 - international - T20 - female - 1425650 - Netherlands vs Zimbabwe
2024-05-01 - club - RHF - female - 1427821 - Thunder vs Southern Vipers
2024-05-01 - club - RHF - female - 1427820 - South East Stars vs Western Storm
2024-05-01 - club - RHF - female - 1427819 - Central Sparks vs Sunrisers
2024-05-01 - club - RHF - female - 1427818 - Northern Diamonds vs The Blaze
2024-04-30 - international - T20 - female - 1429394 - Bangladesh vs India
2024-04-30 - international - T20 - female - 1426086 - West Indies vs Pakistan
2024-04-29 - international - T20 - female - 1425649 - Netherlands vs United Arab Emirates
2024-04-29 - international - T20 - female - 1425648 - Uganda vs Thailand
2024-04-29 - international - T20 - female - 1425647 - Ireland vs Zimbabwe
2024-04-29 - international - T20 - female - 1425646 - Scotland vs United States of America
2024-04-28 - international - T20 - female - 1429393 - India vs Bangladesh
2024-04-28 - international - T20 - female - 1426085 - Pakistan vs West Indies
2024-04-27 - international - T20 - female - 1425645 - Scotland vs Sri Lanka
2024-04-27 - international - T20 - female - 1425644 - United Arab Emirates vs Zimbabwe
2024-04-27 - international - T20 - female - 1425643 - United States of America vs Uganda
2024-04-27 - international - T20 - female - 1425642 - Netherlands vs Vanuatu
2024-04-27 - club - RHF - female - 1427817 - Southern Vipers vs Northern Diamonds
2024-04-27 - club - RHF - female - 1427816 - Western Storm vs Thunder
2024-04-27 - club - RHF - female - 1427815 - The Blaze vs Sunrisers
2024-04-27 - club - RHF - female - 1427814 - South East Stars vs Central Sparks
2024-04-26 - international - T20 - female - 1429635 - Botswana vs Rwanda
2024-04-26 - international - T20 - female - 1429634 - Mozambique vs Lesotho
2024-04-26 - international - T20 - female - 1426084 - West Indies vs Pakistan
2024-04-25 - international - T20 - female - 1429632 - Botswana vs Rwanda
2024-04-25 - international - T20 - female - 1429631 - Botswana vs Lesotho
2024-04-25 - international - T20 - female - 1429630 - Mozambique vs Rwanda
2024-04-25 - international - T20 - female - 1425641 - Zimbabwe vs Vanuatu
2024-04-25 - international - T20 - female - 1425640 - Scotland vs Uganda
2024-04-25 - international - T20 - female - 1425639 - United Arab Emirates vs Ireland
2024-04-25 - international - T20 - female - 1425638 - Sri Lanka vs Thailand
2024-04-24 - international - T20 - female - 1429014 - Mongolia vs Indonesia
2024-04-24 - international - T20 - female - 1429013 - Indonesia vs Mongolia
2024-04-24 - club - RHF - female - 1427813 - Central Sparks vs Southern Vipers
2024-04-24 - club - RHF - female - 1427812 - Thunder vs Sunrisers
2024-04-24 - club - RHF - female - 1427811 - Northern Diamonds vs Western Storm
2024-04-24 - club - RHF - female - 1427810 - The Blaze vs South East Stars
2024-04-23 - international - T20 - female - 1429628 - Mozambique vs Botswana
2024-04-23 - international - T20 - female - 1429627 - Mozambique vs Lesotho
2024-04-23 - international - T20 - female - 1429626 - Botswana vs Rwanda
2024-04-23 - international - ODI - female - 1426083 - West Indies vs Pakistan
2024-04-22 - international - T20 - female - 1429625 - Mozambique vs Botswana
2024-04-22 - international - T20 - female - 1429624 - Lesotho vs Rwanda
2024-04-22 - international - T20 - female - 1429623 - Mozambique vs Rwanda
2024-04-22 - international - T20 - female - 1429622 - Botswana vs Lesotho
2024-04-22 - international - T20 - female - 1429012 - Indonesia vs Mongolia
2024-04-22 - international - T20 - female - 1429011 - Mongolia vs Indonesia
2024-04-21 - international - T20 - female - 1429010 - Indonesia vs Mongolia
2024-04-21 - international - T20 - female - 1429009 - Indonesia vs Mongolia
2024-04-21 - international - T20 - female - 1427422 - Gibraltar vs Estonia
2024-04-21 - international - T20 - female - 1427421 - Gibraltar vs Estonia
2024-04-21 - international - ODI - female - 1426082 - Pakistan vs West Indies
2024-04-20 - international - T20 - female - 1427420 - Gibraltar vs Estonia
2024-04-20 - club - RHF - female - 1427809 - Western Storm vs Sunrisers
2024-04-20 - club - RHF - female - 1427808 - Southern Vipers vs South East Stars
2024-04-20 - club - RHF - female - 1427807 - Central Sparks vs The Blaze
2024-04-20 - club - RHF - female - 1427806 - Thunder vs Northern Diamonds
2024-04-18 - international - T20 - female - 1429008 - Thailand vs Ireland
2024-04-18 - international - ODI - female - 1426081 - West Indies vs Pakistan
2024-04-17 - international - ODI - female - 1398267 - South Africa vs Sri Lanka
2024-04-14 - international - ODI - female - 1427425 - Scotland vs United States of America
2024-04-13 - international - ODI - female - 1398266 - Sri Lanka vs South Africa
2024-04-12 - international - ODI - female - 1427424 - Scotland vs Papua New Guinea
2024-04-11 - international - ODI - female - 1427423 - United States of America vs Papua New Guinea
2024-04-09 - international - ODI - female - 1398265 - South Africa vs Sri Lanka
2024-04-07 - international - ODI - female - 1388209 - England vs New Zealand
2024-04-04 - international - T20 - female - 1425066 - Australia vs Bangladesh
2024-04-04 - international - ODI - female - 1388208 - England vs New Zealand
2024-04-03 - international - T20 - female - 1398263 - South Africa vs Sri Lanka
2024-04-02 - international - T20 - female - 1426050 - Zimbabwe vs Papua New Guinea
2024-04-02 - international - T20 - female - 1425065 - Australia vs Bangladesh
2024-04-01 - international - ODI - female - 1388207 - New Zealand vs England
2024-03-31 - international - T20 - female - 1426049 - Zimbabwe vs Papua New Guinea
2024-03-31 - international - T20 - female - 1425064 - Bangladesh vs Australia
2024-03-30 - international - T20 - female - 1426048 - Papua New Guinea vs Zimbabwe
2024-03-30 - international - T20 - female - 1398262 - South Africa vs Sri Lanka
2024-03-29 - international - T20 - female - 1388206 - New Zealand vs England
2024-03-28 - international - ODI - female - 1426047 - Zimbabwe vs Papua New Guinea
2024-03-27 - international - T20 - female - 1398261 - South Africa vs Sri Lanka
2024-03-27 - international - T20 - female - 1388205 - England vs New Zealand
2024-03-27 - international - ODI - female - 1425063 - Bangladesh vs Australia
2024-03-26 - international - ODI - female - 1426046 - Papua New Guinea vs Zimbabwe
2024-03-24 - international - T20 - female - 1388204 - New Zealand vs England
2024-03-24 - international - ODI - female - 1425062 - Bangladesh vs Australia
2024-03-22 - international - T20 - female - 1388203 - England vs New Zealand
2024-03-21 - international - ODI - female - 1425061 - Australia vs Bangladesh
2024-03-19 - international - T20 - female - 1388202 - England vs New Zealand
2024-03-17 - club - WPL - female - 1417737 - Delhi Capitals vs Royal Challengers Bangalore
2024-03-15 - club - WPL - female - 1417736 - Royal Challengers Bangalore vs Mumbai Indians
2024-03-13 - international - T20 - female - 1423474 - Zimbabwe vs South Africa
2024-03-13 - international - T20 - female - 1423473 - Uganda vs Nigeria
2024-03-13 - club - WPL - female - 1417735 - Gujarat Giants vs Delhi Capitals
2024-03-12 - club - WPL - female - 1417734 - Mumbai Indians vs Royal Challengers Bangalore
2024-03-11 - international - T20 - female - 1423472 - Nigeria vs Zimbabwe
2024-03-11 - international - T20 - female - 1423471 - South Africa vs Uganda
2024-03-11 - club - WPL - female - 1417733 - Gujarat Giants vs UP Warriorz
2024-03-10 - international - T20 - female - 1423470 - Uganda vs Rwanda
2024-03-10 - international - T20 - female - 1423467 - Namibia vs Tanzania
2024-03-10 - club - WPL - female - 1417732 - Delhi Capitals vs Royal Challengers Bangalore
2024-03-09 - club - WPL - female - 1417731 - Gujarat Giants vs Mumbai Indians
2024-03-08 - international - T20 - female - 1423465 - Uganda vs Zimbabwe
2024-03-08 - international - T20 - female - 1423464 - Nigeria vs Namibia
2024-03-08 - international - T20 - female - 1423463 - Tanzania vs South Africa
2024-03-08 - club - WPL - female - 1417730 - UP Warriorz vs Delhi Capitals
2024-03-07 - international - T20 - female - 1423460 - Tanzania vs Nigeria
2024-03-07 - international - T20 - female - 1423459 - Namibia vs South Africa
2024-03-07 - club - WPL - female - 1417729 - Mumbai Indians vs UP Warriorz
2024-03-06 - club - WPL - female - 1417728 - Gujarat Giants vs Royal Challengers Bangalore
2024-03-05 - club - WPL - female - 1417727 - Delhi Capitals vs Mumbai Indians
2024-03-04 - club - WPL - female - 1417726 - Royal Challengers Bangalore vs UP Warriorz
2024-03-03 - club - WPL - female - 1417725 - Delhi Capitals vs Gujarat Giants
2024-03-02 - club - WPL - female - 1417724 - Royal Challengers Bangalore vs Mumbai Indians
2024-03-01 - club - WPL - female - 1417723 - Gujarat Giants vs UP Warriorz
2024-02-29 - club - WPL - female - 1417722 - Delhi Capitals vs Royal Challengers Bangalore
2024-02-28 - club - WPL - female - 1417721 - Mumbai Indians vs UP Warriorz
2024-02-27 - club - WPL - female - 1417720 - Gujarat Giants vs Royal Challengers Bangalore
2024-02-26 - club - WPL - female - 1417719 - UP Warriorz vs Delhi Capitals
2024-02-25 - club - WPL - female - 1417718 - Gujarat Giants vs Mumbai Indians
2024-02-24 - club - WPL - female - 1417717 - Royal Challengers Bangalore vs UP Warriorz
2024-02-23 - club - WPL - female - 1417716 - Delhi Capitals vs Mumbai Indians
2024-02-18 - international - T20 - female - 1419936 - United Arab Emirates vs Malaysia
2024-02-16 - international - T20 - female - 1419935 - Nepal vs Malaysia
2024-02-16 - international - T20 - female - 1419934 - United Arab Emirates vs Thailand
2024-02-15 - international - Test - female - 1375875 - South Africa vs Australia
2024-02-14 - international - T20 - female - 1419933 - Kuwait vs Nepal
2024-02-14 - international - T20 - female - 1419932 - Malaysia vs Japan
2024-02-14 - international - T20 - female - 1419931 - United Arab Emirates vs Indonesia
2024-02-14 - international - T20 - female - 1419930 - Hong Kong vs Thailand
2024-02-13 - international - T20 - female - 1419929 - Nepal vs Maldives
2024-02-13 - international - T20 - female - 1419928 - Qatar vs Indonesia
2024-02-13 - international - T20 - female - 1419927 - Japan vs United Arab Emirates
2024-02-13 - international - T20 - female - 1419926 - Thailand vs Singapore
2024-02-13 - international - T20 - female - 1419925 - Hong Kong vs Bhutan
2024-02-13 - international - T20 - female - 1419924 - Malaysia vs Bahrain
2024-02-13 - international - T20 - female - 1419923 - Oman vs China
2024-02-13 - international - T20 - female - 1419922 - Kuwait vs Myanmar
2024-02-11 - international - T20 - female - 1419921 - Hong Kong vs Maldives
2024-02-11 - international - T20 - female - 1419920 - Malaysia vs Qatar
2024-02-11 - international - T20 - female - 1419919 - China vs Japan
2024-02-11 - international - T20 - female - 1419918 - Singapore vs Myanmar
2024-02-11 - international - T20 - female - 1419917 - Bhutan vs Nepal
2024-02-11 - international - T20 - female - 1419916 - Indonesia vs Bahrain
2024-02-11 - international - T20 - female - 1419915 - United Arab Emirates vs Oman
2024-02-11 - international - T20 - female - 1419914 - Thailand vs Kuwait
2024-02-10 - international - T20 - female - 1419913 - Bhutan vs Maldives
2024-02-10 - international - T20 - female - 1419912 - Bahrain vs Qatar
2024-02-10 - international - T20 - female - 1419911 - Japan vs Oman
2024-02-10 - international - T20 - female - 1419910 - Singapore vs Kuwait
2024-02-10 - international - T20 - female - 1419909 - Hong Kong vs Nepal
2024-02-10 - international - T20 - female - 1419908 - Indonesia vs Malaysia
2024-02-10 - international - T20 - female - 1419907 - United Arab Emirates vs China
2024-02-10 - international - T20 - female - 1419906 - Myanmar vs Thailand
2024-02-10 - international - ODI - female - 1375874 - Australia vs South Africa
2024-02-07 - international - ODI - female - 1375873 - South Africa vs Australia
2024-02-05 - international - T20 - female - 1419511 - Kuwait vs Malaysia
2024-02-04 - international - T20 - female - 1419510 - Malaysia vs Kuwait
2024-02-03 - international - ODI - female - 1375872 - South Africa vs Australia
2024-02-02 - international - T20 - female - 1415987 - Ireland vs Zimbabwe
2024-02-01 - international - T20 - female - 1415986 - Zimbabwe vs Ireland
2024-01-30 - international - T20 - female - 1415985 - Ireland vs Zimbabwe
2024-01-30 - international - T20 - female - 1375871 - South Africa vs Australia
2024-01-28 - international - T20 - female - 1415984 - Ireland vs Zimbabwe
2024-01-28 - international - T20 - female - 1375870 - Australia vs South Africa
2024-01-28 - club - SSM - female - 1409537 - Wellington vs Central Districts
2024-01-27 - international - T20 - female - 1375869 - South Africa vs Australia
2024-01-26 - international - T20 - female - 1415983 - Ireland vs Zimbabwe
2024-01-26 - club - SSM - female - 1409536 - Central Districts vs Northern Districts
2024-01-23 - international - ODI - female - 1415982 - Ireland vs Zimbabwe
2024-01-23 - club - SSM - female - 1409535 - Northern Districts vs Otago
2024-01-22 - club - SSM - female - 1409534 - Canterbury vs Wellington
2024-01-21 - international - ODI - female - 1415981 - Zimbabwe vs Ireland
2024-01-20 - club - SSM - female - 1409533 - Northern Districts vs Auckland
2024-01-19 - club - SSM - female - 1409532 - Central Districts vs Otago
2024-01-18 - international - ODI - female - 1415980 - Zimbabwe vs Ireland
2024-01-18 - club - SSM - female - 1409531 - Northern Districts vs Canterbury
2024-01-16 - club - SSM - female - 1409530 - Central Districts vs Auckland
2024-01-15 - club - SSM - female - 1409529 - Northern Districts vs Wellington
2024-01-14 - club - SSM - female - 1409528 - Auckland vs Otago
2024-01-13 - club - SSM - female - 1409527 - Wellington vs Central Districts
2024-01-12 - club - SSM - female - 1409526 - Northern Districts vs Auckland
2024-01-11 - club - SSM - female - 1409525 - Wellington vs Canterbury
2024-01-10 - club - SSM - female - 1409524 - Central Districts vs Otago
2024-01-09 - international - T20 - female - 1406083 - India vs Australia
2024-01-09 - club - SSM - female - 1409523 - Northern Districts vs Canterbury
2024-01-08 - club - SSM - female - 1409522 - Central Districts vs Wellington
2024-01-07 - international - T20 - female - 1406082 - India vs Australia
2024-01-07 - club - SSM - female - 1409521 - Canterbury vs Auckland
2024-01-06 - club - SSM - female - 1409520 - Northern Districts vs Otago
2024-01-05 - international - T20 - female - 1406081 - Australia vs India
2024-01-04 - club - SSM - female - 1409518 - Auckland vs Wellington
2024-01-03 - club - SSM - female - 1409517 - Canterbury vs Otago
2024-01-02 - international - ODI - female - 1406080 - Australia vs India
2024-01-02 - club - SSM - female - 1409516 - Wellington vs Northern Districts
2024-01-01 - club - SSM - female - 1409515 - Otago vs Auckland
2023-12-30 - international - ODI - female - 1406079 - Australia vs India
2023-12-30 - club - SSM - female - 1409514 - Central Districts vs Canterbury
2023-12-28 - international - ODI - female - 1406078 - India vs Australia
2023-12-28 - club - SSM - female - 1409512 - Wellington vs Otago
2023-12-27 - club - SSM - female - 1409511 - Central Districts vs Northern Districts
2023-12-26 - club - SSM - female - 1409510 - Canterbury vs Otago
2023-12-23 - international - ODI - female - 1398260 - South Africa vs Bangladesh
2023-12-22 - club - SSM - female - 1409508 - Northern Districts vs Central Districts
2023-12-21 - international - Test - female - 1406077 - Australia vs India
2023-12-21 - club - SSM - female - 1409507 - Wellington vs Otago
2023-12-20 - international - ODI - female - 1398259 - Bangladesh vs South Africa
2023-12-19 - club - SSM - female - 1409506 - Canterbury vs Auckland
2023-12-18 - international - ODI - female - 1388201 - New Zealand vs Pakistan
2023-12-17 - international - T20 - female - 1411276 - Uganda vs Zimbabwe
2023-12-16 - international - T20 - female - 1411274 - Uganda vs Tanzania
2023-12-16 - international - T20 - female - 1411273 - Zimbabwe vs Namibia
2023-12-16 - international - ODI - female - 1398258 - Bangladesh vs South Africa
2023-12-15 - international - ODI - female - 1388200 - Pakistan vs New Zealand
2023-12-14 - international - Test - female - 1406076 - India vs England
2023-12-14 - international - T20 - female - 1411272 - Nigeria vs Uganda
2023-12-14 - international - T20 - female - 1411271 - Namibia vs Rwanda
2023-12-13 - international - T20 - female - 1411270 - Tanzania vs Zimbabwe
2023-12-13 - international - T20 - female - 1411269 - Botswana vs Kenya
2023-12-12 - international - T20 - female - 1411268 - Namibia vs Uganda
2023-12-12 - international - T20 - female - 1411267 - Rwanda vs Nigeria
2023-12-12 - international - ODI - female - 1388199 - New Zealand vs Pakistan
2023-12-11 - international - T20 - female - 1411266 - Zimbabwe vs Botswana
2023-12-11 - international - T20 - female - 1411265 - Kenya vs Tanzania
2023-12-10 - international - T20 - female - 1411264 - Rwanda vs Uganda
2023-12-10 - international - T20 - female - 1411263 - Namibia vs Nigeria
2023-12-10 - international - T20 - female - 1406075 - England vs India
2023-12-09 - international - T20 - female - 1411262 - Botswana vs Tanzania
2023-12-09 - international - T20 - female - 1411261 - Zimbabwe vs Kenya
2023-12-09 - international - T20 - female - 1406074 - India vs England
2023-12-09 - international - T20 - female - 1388198 - Pakistan vs New Zealand
2023-12-08 - international - T20 - female - 1398256 - Bangladesh vs South Africa
2023-12-06 - international - T20 - female - 1406073 - England vs India
2023-12-06 - international - T20 - female - 1398255 - Bangladesh vs South Africa
2023-12-05 - international - T20 - female - 1388197 - Pakistan vs New Zealand
2023-12-03 - international - T20 - female - 1398254 - Bangladesh vs South Africa
2023-12-03 - international - T20 - female - 1388196 - New Zealand vs Pakistan
2023-12-02 - club - WBB - female - 1387228 - Adelaide Strikers vs Brisbane Heat
2023-11-29 - club - WBB - female - 1409206 - Brisbane Heat vs Perth Scorchers
2023-11-28 - club - WBB - female - 1409205 - Brisbane Heat vs Sydney Thunder
2023-11-26 - club - WBB - female - 1387227 - Sydney Thunder vs Sydney Sixers
2023-11-26 - club - WBB - female - 1387226 - Adelaide Strikers vs Hobart Hurricanes
2023-11-25 - club - WBB - female - 1387225 - Melbourne Stars vs Melbourne Renegades
2023-11-24 - club - WBB - female - 1387224 - Perth Scorchers vs Adelaide Strikers
2023-11-24 - club - WBB - female - 1387223 - Brisbane Heat vs Sydney Thunder
2023-11-23 - club - WBB - female - 1387222 - Hobart Hurricanes vs Melbourne Renegades
2023-11-22 - club - WBB - female - 1387221 - Melbourne Stars vs Perth Scorchers
2023-11-21 - club - WBB - female - 1387220 - Brisbane Heat vs Sydney Sixers
2023-11-21 - club - WBB - female - 1387219 - Adelaide Strikers vs Sydney Thunder
2023-11-19 - international - T20 - female - 1407871 - Tanzania vs Hong Kong
2023-11-19 - international - T20 - female - 1407870 - Nepal vs Japan
2023-11-19 - club - WBB - female - 1387218 - Melbourne Stars vs Brisbane Heat
2023-11-19 - club - WBB - female - 1387217 - Melbourne Renegades vs Hobart Hurricanes
2023-11-18 - international - T20 - female - 1407865 - Tanzania vs Hong Kong
2023-11-18 - international - T20 - female - 1407864 - Nepal vs Japan
2023-11-18 - club - WBB - female - 1387216 - Sydney Sixers vs Adelaide Strikers
2023-11-18 - club - WBB - female - 1387215 - Perth Scorchers vs Sydney Thunder
2023-11-17 - club - WBB - female - 1387214 - Melbourne Renegades vs Brisbane Heat
2023-11-17 - club - WBB - female - 1387213 - Melbourne Stars vs Hobart Hurricanes
2023-11-16 - international - T20 - female - 1407867 - Nepal vs Hong Kong
2023-11-16 - international - T20 - female - 1407866 - Tanzania vs Japan
2023-11-16 - club - WBB - female - 1387212 - Perth Scorchers vs Sydney Sixers
2023-11-15 - international - T20 - female - 1407869 - Japan vs Hong Kong
2023-11-15 - international - T20 - female - 1407868 - Tanzania vs Nepal
2023-11-15 - club - WBB - female - 1387211 - Sydney Thunder vs Adelaide Strikers
2023-11-15 - club - WBB - female - 1387210 - Brisbane Heat vs Hobart Hurricanes
2023-11-13 - club - WBB - female - 1387209 - Hobart Hurricanes vs Sydney Sixers
2023-11-12 - club - WBB - female - 1387208 - Melbourne Stars vs Melbourne Renegades
2023-11-12 - club - WBB - female - 1387207 - Perth Scorchers vs Sydney Thunder
2023-11-11 - club - WBB - female - 1387206 - Adelaide Strikers vs Brisbane Heat
2023-11-11 - club - WBB - female - 1387205 - Melbourne Renegades vs Perth Scorchers
2023-11-10 - international - ODI - female - 1405126 - Pakistan vs Bangladesh
2023-11-10 - club - WBB - female - 1387204 - Sydney Sixers vs Hobart Hurricanes
2023-11-10 - club - WBB - female - 1387203 - Sydney Thunder vs Melbourne Stars
2023-11-09 - club - WBB - female - 1387202 - Perth Scorchers vs Brisbane Heat
2023-11-08 - club - WBB - female - 1387200 - Melbourne Renegades vs Adelaide Strikers
2023-11-08 - club - WBB - female - 1387199 - Sydney Sixers vs Melbourne Stars
2023-11-07 - international - ODI - female - 1405125 - Bangladesh vs Pakistan
2023-11-06 - club - WBB - female - 1387198 - Sydney Thunder vs Brisbane Heat
2023-11-05 - club - WBB - female - 1387197 - Perth Scorchers vs Adelaide Strikers
2023-11-05 - club - WBB - female - 1387196 - Melbourne Renegades vs Sydney Sixers
2023-11-04 - international - ODI - female - 1405124 - Bangladesh vs Pakistan
2023-11-04 - club - WBB - female - 1387195 - Hobart Hurricanes vs Brisbane Heat
2023-11-04 - club - WBB - female - 1387194 - Melbourne Stars vs Sydney Thunder
2023-11-03 - club - WBB - female - 1387193 - Melbourne Renegades vs Perth Scorchers
2023-11-03 - club - WBB - female - 1387192 - Sydney Sixers vs Adelaide Strikers
2023-11-02 - club - WBB - female - 1387191 - Melbourne Stars vs Hobart Hurricanes
2023-11-01 - club - WBB - female - 1387190 - Sydney Thunder vs Melbourne Renegades
2023-10-31 - club - WBB - female - 1387189 - Perth Scorchers vs Sydney Sixers
2023-10-30 - club - WBB - female - 1387188 - Hobart Hurricanes vs Sydney Thunder
2023-10-29 - international - T20 - female - 1405123 - Pakistan vs Bangladesh
2023-10-29 - club - WBB - female - 1387187 - Adelaide Strikers vs Brisbane Heat
2023-10-29 - club - WBB - female - 1387186 - Melbourne Stars vs Perth Scorchers
2023-10-28 - club - WBB - female - 1387185 - Sydney Sixers vs Melbourne Renegades
2023-10-27 - international - T20 - female - 1405122 - Bangladesh vs Pakistan
2023-10-27 - club - WBB - female - 1387184 - Brisbane Heat vs Melbourne Stars
2023-10-27 - club - WBB - female - 1387183 - Adelaide Strikers vs Hobart Hurricanes
2023-10-26 - club - WBB - female - 1387182 - Melbourne Renegades vs Sydney Thunder
2023-10-25 - international - T20 - female - 1405121 - Pakistan vs Bangladesh
2023-10-25 - club - WBB - female - 1387181 - Hobart Hurricanes vs Perth Scorchers
2023-10-24 - international - T20 - female - 1403687 - Ireland vs Scotland
2023-10-24 - club - WBB - female - 1387180 - Sydney Sixers vs Brisbane Heat
2023-10-24 - club - WBB - female - 1387179 - Melbourne Stars vs Adelaide Strikers
2023-10-23 - international - T20 - female - 1403686 - Scotland vs Ireland
2023-10-23 - club - WBB - female - 1387178 - Melbourne Renegades vs Adelaide Strikers
2023-10-22 - club - WBB - female - 1387177 - Sydney Thunder vs Sydney Sixers
2023-10-22 - club - WBB - female - 1387176 - Brisbane Heat vs Perth Scorchers
2023-10-21 - international - ODI - female - 1403685 - Ireland vs Scotland
2023-10-21 - club - WBB - female - 1387175 - Adelaide Strikers vs Melbourne Stars
2023-10-20 - club - WBB - female - 1387174 - Perth Scorchers vs Hobart Hurricanes
2023-10-20 - club - WBB - female - 1387173 - Brisbane Heat vs Melbourne Renegades
2023-10-19 - international - ODI - female - 1403684 - Ireland vs Scotland
2023-10-19 - club - WBB - female - 1387172 - Melbourne Stars vs Sydney Sixers
2023-10-17 - international - ODI - female - 1403683 - Scotland vs Ireland
2023-10-15 - international - T20 - female - 1402766 - Argentina vs Chile
2023-10-15 - international - T20 - female - 1392355 - South Africa vs New Zealand
2023-10-14 - international - T20 - female - 1402765 - Argentina vs Chile
2023-10-14 - international - T20 - female - 1392354 - South Africa vs New Zealand
2023-10-14 - international - ODI - female - 1375868 - West Indies vs Australia
2023-10-12 - international - ODI - female - 1375867 - West Indies vs Australia
2023-10-08 - international - T20 - female - 1392352 - New Zealand vs South Africa
2023-10-08 - international - ODI - female - 1375866 - West Indies vs Australia
2023-10-05 - international - T20 - female - 1375865 - Australia vs West Indies
2023-10-03 - international - T20 - female - 1400041 - Namibia vs United Arab Emirates
2023-10-02 - international - T20 - female - 1400040 - United Arab Emirates vs Namibia
2023-10-02 - international - T20 - female - 1375864 - Australia vs West Indies
2023-10-01 - international - T20 - female - 1375863 - West Indies vs Australia
2023-10-01 - international - ODI - female - 1392350 - South Africa vs New Zealand
2023-09-30 - international - T20 - female - 1400039 - Namibia vs United Arab Emirates
2023-09-29 - international - T20 - female - 1400038 - United Arab Emirates vs Namibia
2023-09-28 - international - ODI - female - 1392349 - New Zealand vs South Africa
2023-09-27 - international - T20 - female - 1400037 - United Arab Emirates vs Namibia
2023-09-26 - international - T20 - female - 1400036 - United Arab Emirates vs Namibia
2023-09-25 - international - T20 - female - 1399062 - India vs Sri Lanka
2023-09-25 - international - T20 - female - 1399061 - Pakistan vs Bangladesh
2023-09-24 - international - T20 - female - 1399060 - Pakistan vs Sri Lanka
2023-09-24 - international - T20 - female - 1399059 - Bangladesh vs India
2023-09-24 - international - ODI - female - 1392348 - New Zealand vs South Africa
2023-09-24 - club - RHF - female - 1347460 - The Blaze vs Southern Vipers
2023-09-22 - international - T20 - female - 1399057 - Thailand vs Sri Lanka
2023-09-21 - international - T20 - female - 1399055 - India vs Malaysia
2023-09-21 - club - RHF - female - 1347459 - South East Stars vs The Blaze
2023-09-16 - club - RHF - female - 1347458 - Northern Diamonds vs Sunrisers
2023-09-16 - club - RHF - female - 1347457 - Southern Vipers vs The Blaze
2023-09-16 - club - RHF - female - 1347456 - Western Storm vs Thunder
2023-09-16 - club - RHF - female - 1347455 - South East Stars vs Central Sparks
2023-09-14 - international - ODI - female - 1382171 - South Africa vs Pakistan
2023-09-14 - international - ODI - female - 1336085 - England vs Sri Lanka
2023-09-13 - club - RHF - female - 1347454 - Western Storm vs Central Sparks
2023-09-13 - club - RHF - female - 1347453 - Sunrisers vs The Blaze
2023-09-13 - club - RHF - female - 1347452 - Northern Diamonds vs Thunder
2023-09-13 - club - RHF - female - 1347451 - Southern Vipers vs South East Stars
2023-09-12 - international - T20 - female - 1395037 - Italy vs Netherlands
2023-09-12 - international - T20 - female - 1395036 - Scotland vs France
2023-09-12 - international - ODI - female - 1336084 - Sri Lanka vs England
2023-09-11 - international - T20 - female - 1395035 - Scotland vs Netherlands
2023-09-11 - international - T20 - female - 1395018 - United States of America vs Canada
2023-09-11 - international - T20 - female - 1395017 - Argentina vs Brazil
2023-09-11 - international - ODI - female - 1382170 - Pakistan vs South Africa
2023-09-10 - international - T20 - female - 1395033 - France vs Netherlands
2023-09-10 - international - T20 - female - 1395032 - Scotland vs Italy
2023-09-10 - international - T20 - female - 1395016 - Brazil vs United States of America
2023-09-10 - international - T20 - female - 1395015 - Canada vs Argentina
2023-09-10 - club - WCL - female - 1380595 - Barbados Royals vs Guyana Amazon Warriors
2023-09-10 - club - RHF - female - 1347450 - Northern Diamonds vs Western Storm
2023-09-10 - club - RHF - female - 1347449 - Central Sparks vs Sunrisers
2023-09-10 - club - RHF - female - 1347447 - South East Stars vs The Blaze
2023-09-09 - international - T20 - female - 1394778 - United Arab Emirates vs Thailand
2023-09-09 - international - ODI - female - 1336083 - Sri Lanka vs England
2023-09-09 - club - WCL - female - 1380594 - Trinbago Knight Riders vs Guyana Amazon Warriors
2023-09-09 - club - RHF - female - 1347448 - Southern Vipers vs Thunder
2023-09-08 - international - T20 - female - 1395031 - France vs Scotland
2023-09-08 - international - T20 - female - 1395030 - Italy vs Netherlands
2023-09-08 - international - T20 - female - 1395014 - United States of America vs Argentina
2023-09-08 - international - T20 - female - 1395013 - Canada vs Brazil
2023-09-08 - international - T20 - female - 1394932 - Botswana vs Kenya
2023-09-08 - international - T20 - female - 1394931 - Cameroon vs Sierra Leone
2023-09-08 - international - T20 - female - 1394811 - Papua New Guinea vs Indonesia
2023-09-08 - international - T20 - female - 1394810 - Fiji vs Cook Islands
2023-09-08 - international - T20 - female - 1394809 - Samoa vs Vanuatu
2023-09-08 - international - T20 - female - 1394777 - Thailand vs Nepal
2023-09-08 - international - T20 - female - 1394776 - United Arab Emirates vs Hong Kong
2023-09-08 - international - ODI - female - 1382169 - South Africa vs Pakistan
2023-09-07 - international - T20 - female - 1395029 - Italy vs France
2023-09-07 - international - T20 - female - 1395028 - Netherlands vs Scotland
2023-09-07 - international - T20 - female - 1395012 - Brazil vs Argentina
2023-09-07 - international - T20 - female - 1395011 - United States of America vs Canada
2023-09-07 - international - T20 - female - 1394807 - Fiji vs Papua New Guinea
2023-09-07 - international - T20 - female - 1394806 - Japan vs Indonesia
2023-09-07 - international - T20 - female - 1394797 - Vanuatu vs Indonesia
2023-09-06 - international - T20 - female - 1395026 - France vs Netherlands
2023-09-06 - international - T20 - female - 1394930 - Kenya vs Cameroon
2023-09-06 - international - T20 - female - 1394929 - Botswana vs Sierra Leone
2023-09-06 - international - T20 - female - 1394775 - Thailand vs Hong Kong
2023-09-06 - international - T20 - female - 1394774 - Kuwait vs Myanmar
2023-09-06 - international - T20 - female - 1336082 - England vs Sri Lanka
2023-09-06 - club - WCL - female - 1380593 - Trinbago Knight Riders vs Barbados Royals
2023-09-05 - international - T20 - female - 1395010 - Canada vs Argentina
2023-09-05 - international - T20 - female - 1395009 - United States of America vs Brazil
2023-09-05 - international - T20 - female - 1394928 - Kenya vs Lesotho
2023-09-05 - international - T20 - female - 1394927 - Botswana vs Malawi
2023-09-05 - international - T20 - female - 1394926 - Sierra Leone vs Eswatini
2023-09-05 - international - T20 - female - 1394925 - Cameroon vs Mozambique
2023-09-05 - international - T20 - female - 1394805 - Samoa vs Indonesia
2023-09-05 - club - WCL - female - 1380592 - Guyana Amazon Warriors vs Trinbago Knight Riders
2023-09-05 - club - RHF - female - 1347446 - Southern Vipers vs Northern Diamonds
2023-09-05 - club - RHF - female - 1347445 - Western Storm vs Sunrisers
2023-09-05 - club - RHF - female - 1347444 - Central Sparks vs The Blaze
2023-09-05 - club - RHF - female - 1347443 - South East Stars vs Thunder
2023-09-04 - international - T20 - female - 1395008 - Canada vs Brazil
2023-09-04 - international - T20 - female - 1395007 - United States of America vs Argentina
2023-09-04 - international - T20 - female - 1394802 - Fiji vs Japan
2023-09-04 - international - T20 - female - 1394801 - Indonesia vs Cook Islands
2023-09-04 - international - T20 - female - 1394800 - Cook Islands vs Vanuatu
2023-09-04 - international - T20 - female - 1394799 - Samoa vs Papua New Guinea
2023-09-04 - international - T20 - female - 1394770 - Kuwait vs Thailand
2023-09-04 - international - T20 - female - 1394769 - Myanmar vs China
2023-09-04 - international - T20 - female - 1394768 - Bhutan vs Malaysia
2023-09-04 - international - T20 - female - 1394767 - Qatar vs Nepal
2023-09-04 - international - T20 - female - 1394766 - United Arab Emirates vs Bahrain
2023-09-04 - international - T20 - female - 1382162 - Pakistan vs South Africa
2023-09-03 - international - T20 - female - 1394924 - Cameroon vs Eswatini
2023-09-03 - international - T20 - female - 1394923 - Mozambique vs Sierra Leone
2023-09-03 - international - T20 - female - 1394922 - Botswana vs Lesotho
2023-09-03 - international - T20 - female - 1394921 - Malawi vs Kenya
2023-09-03 - international - T20 - female - 1394765 - China vs Thailand
2023-09-03 - international - T20 - female - 1394764 - Kuwait vs Hong Kong
2023-09-03 - international - T20 - female - 1394763 - United Arab Emirates vs Qatar
2023-09-03 - international - T20 - female - 1394762 - Bhutan vs Nepal
2023-09-03 - international - T20 - female - 1394761 - Malaysia vs Bahrain
2023-09-03 - international - T20 - female - 1382161 - South Africa vs Pakistan
2023-09-03 - club - WCL - female - 1380591 - Guyana Amazon Warriors vs Barbados Royals
2023-09-02 - international - T20 - female - 1394920 - Cameroon vs Sierra Leone
2023-09-02 - international - T20 - female - 1394919 - Mozambique vs Eswatini
2023-09-02 - international - T20 - female - 1394918 - Malawi vs Lesotho
2023-09-02 - international - T20 - female - 1394917 - Kenya vs Botswana
2023-09-02 - international - T20 - female - 1394798 - Japan vs Samoa
2023-09-02 - international - T20 - female - 1394796 - Papua New Guinea vs Cook Islands
2023-09-02 - international - T20 - female - 1336081 - England vs Sri Lanka
2023-09-02 - club - WCL - female - 1380590 - Trinbago Knight Riders vs Barbados Royals
2023-09-01 - international - T20 - female - 1394795 - Fiji vs Samoa
2023-09-01 - international - T20 - female - 1394794 - Papua New Guinea vs Vanuatu
2023-09-01 - international - T20 - female - 1394792 - Japan vs Cook Islands
2023-09-01 - international - T20 - female - 1394760 - Bahrain vs Nepal
2023-09-01 - international - T20 - female - 1394759 - Malaysia vs United Arab Emirates
2023-09-01 - international - T20 - female - 1394758 - Qatar vs Bhutan
2023-09-01 - international - T20 - female - 1394757 - China vs Hong Kong
2023-09-01 - international - T20 - female - 1382160 - South Africa vs Pakistan
2023-08-31 - international - T20 - female - 1394755 - Myanmar vs Hong Kong
2023-08-31 - international - T20 - female - 1394754 - Kuwait vs China
2023-08-31 - international - T20 - female - 1394753 - Bhutan vs United Arab Emirates
2023-08-31 - international - T20 - female - 1394752 - Qatar vs Bahrain
2023-08-31 - international - T20 - female - 1394751 - Nepal vs Malaysia
2023-08-31 - international - T20 - female - 1336080 - England vs Sri Lanka
2023-08-31 - club - WCL - female - 1380589 - Guyana Amazon Warriors vs Barbados Royals
2023-08-30 - international - T20 - female - 1393877 - Vanuatu vs Japan
2023-08-28 - international - T20 - female - 1393876 - Japan vs Vanuatu
2023-08-27 - international - T20 - female - 1391652 - Singapore vs Myanmar
2023-08-27 - club - HND - female - 1355605 - Southern Brave vs Northern Superchargers
2023-08-26 - international - T20 - female - 1393597 - Hong Kong vs Nepal
2023-08-26 - international - T20 - female - 1391658 - Denmark vs Sweden
2023-08-26 - international - T20 - female - 1391651 - Singapore vs Myanmar
2023-08-26 - club - HND - female - 1355604 - Welsh Fire vs Northern Superchargers
2023-08-25 - international - T20 - female - 1393595 - Nepal vs Malaysia
2023-08-25 - international - T20 - female - 1393594 - Hong Kong vs Kuwait
2023-08-25 - international - T20 - female - 1391709 - Netherlands vs Jersey
2023-08-25 - international - T20 - female - 1391655 - Denmark vs Sweden
2023-08-24 - international - T20 - female - 1391708 - Netherlands vs Jersey
2023-08-24 - international - T20 - female - 1391707 - Netherlands vs Jersey
2023-08-24 - international - T20 - female - 1391650 - Singapore vs Myanmar
2023-08-24 - club - HND - female - 1355603 - London Spirit vs Birmingham Phoenix
2023-08-23 - international - T20 - female - 1393593 - Nepal vs Kuwait
2023-08-23 - international - T20 - female - 1393592 - Malaysia vs Hong Kong
2023-08-23 - club - HND - female - 1355602 - Manchester Originals vs Southern Brave
2023-08-22 - international - T20 - female - 1393591 - Hong Kong vs Nepal
2023-08-22 - international - T20 - female - 1393590 - Kuwait vs Malaysia
2023-08-22 - club - HND - female - 1355601 - Northern Superchargers vs Welsh Fire
2023-08-21 - club - HND - female - 1355600 - Oval Invincibles vs Trent Rockets
2023-08-20 - club - HND - female - 1355599 - Welsh Fire vs London Spirit
2023-08-20 - club - HND - female - 1355598 - Northern Superchargers vs Manchester Originals
2023-08-19 - club - HND - female - 1355597 - Oval Invincibles vs Southern Brave
2023-08-19 - club - HND - female - 1355596 - Trent Rockets vs Birmingham Phoenix
2023-08-18 - club - HND - female - 1355595 - London Spirit vs Northern Superchargers
2023-08-17 - international - T20 - female - 1378202 - Netherlands vs Ireland
2023-08-17 - club - HND - female - 1355594 - Manchester Originals vs Trent Rockets
2023-08-16 - international - T20 - female - 1378201 - Ireland vs Netherlands
2023-08-16 - club - HND - female - 1355593 - Southern Brave vs Birmingham Phoenix
2023-08-15 - club - HND - female - 1355592 - London Spirit vs Oval Invincibles
2023-08-14 - international - T20 - female - 1378200 - Netherlands vs Ireland
2023-08-14 - club - HND - female - 1355591 - Welsh Fire vs Trent Rockets
2023-08-13 - club - HND - female - 1355590 - Oval Invincibles vs Birmingham Phoenix
2023-08-13 - club - HND - female - 1355589 - Northern Superchargers vs Manchester Originals
2023-08-12 - club - HND - female - 1355588 - Welsh Fire vs Southern Brave
2023-08-12 - club - HND - female - 1355587 - London Spirit vs Trent Rockets
2023-08-11 - club - HND - female - 1355586 - Northern Superchargers vs Oval Invincibles
2023-08-10 - club - HND - female - 1355585 - Welsh Fire vs Birmingham Phoenix
2023-08-09 - club - HND - female - 1355584 - Oval Invincibles vs Manchester Originals
2023-08-09 - club - HND - female - 1355583 - Northern Superchargers vs Trent Rockets
2023-08-08 - club - HND - female - 1355582 - London Spirit vs Southern Brave
2023-08-07 - club - HND - female - 1355581 - Birmingham Phoenix vs Manchester Originals
2023-08-06 - international - T20 - female - 1387951 - Greece vs Isle of Man
2023-08-06 - club - HND - female - 1355580 - Oval Invincibles vs Welsh Fire
2023-08-06 - club - HND - female - 1355579 - Northern Superchargers vs Southern Brave
2023-08-05 - international - T20 - female - 1387949 - Romania vs Malta
2023-08-05 - international - T20 - female - 1387948 - Malta vs Isle of Man
2023-08-05 - international - T20 - female - 1387947 - Greece vs Romania
2023-08-04 - international - T20 - female - 1387946 - Romania vs Isle of Man
2023-08-04 - international - T20 - female - 1387945 - Malta vs Greece
2023-08-04 - international - T20 - female - 1387944 - Greece vs Isle of Man
2023-08-04 - club - HND - female - 1355576 - Welsh Fire vs Southern Brave
2023-08-03 - club - HND - female - 1355575 - Birmingham Phoenix vs Northern Superchargers
2023-08-01 - club - HND - female - 1355572 - Southern Brave vs Trent Rockets
2023-07-29 - international - ODI - female - 1378199 - Ireland vs Australia
2023-07-25 - international - ODI - female - 1378198 - Australia vs Ireland
2023-07-24 - club - RHF - female - 1347442 - Western Storm vs Sunrisers
2023-07-22 - international - ODI - female - 1382168 - Bangladesh vs India
2023-07-22 - club - RHF - female - 1347441 - Western Storm vs South East Stars
2023-07-22 - club - RHF - female - 1347438 - Northern Diamonds vs Southern Vipers
2023-07-19 - international - ODI - female - 1382167 - India vs Bangladesh
2023-07-18 - international - ODI - female - 1336079 - England vs Australia
2023-07-17 - club - RHF - female - 1347437 - The Blaze vs South East Stars
2023-07-16 - international - ODI - female - 1382166 - Bangladesh vs India
2023-07-16 - international - ODI - female - 1336078 - Australia vs England
2023-07-15 - international - T20 - female - 1384550 - Scotland vs Netherlands
2023-07-15 - club - RHF - female - 1347435 - Western Storm vs Southern Vipers
2023-07-15 - club - RHF - female - 1347434 - Northern Diamonds vs Central Sparks
2023-07-14 - international - T20 - female - 1384549 - Netherlands vs Thailand
2023-07-13 - international - T20 - female - 1384548 - Thailand vs Scotland
2023-07-13 - international - T20 - female - 1382165 - India vs Bangladesh
2023-07-12 - international - T20 - female - 1384547 - Scotland vs Netherlands
2023-07-12 - international - T20 - female - 1379762 - New Zealand vs Sri Lanka
2023-07-12 - international - ODI - female - 1336077 - Australia vs England
2023-07-11 - international - T20 - female - 1384546 - Thailand vs Netherlands
2023-07-11 - international - T20 - female - 1382164 - India vs Bangladesh
2023-07-11 - club - RHF - female - 1347433 - Northern Diamonds vs Thunder
2023-07-11 - club - RHF - female - 1347432 - Southern Vipers vs The Blaze
2023-07-11 - club - RHF - female - 1347431 - South East Stars vs Sunrisers
2023-07-10 - international - T20 - female - 1384545 - Scotland vs Thailand
2023-07-10 - international - T20 - female - 1379761 - Sri Lanka vs New Zealand
2023-07-09 - international - T20 - female - 1382163 - Bangladesh vs India
2023-07-08 - international - T20 - female - 1379760 - Sri Lanka vs New Zealand
2023-07-08 - international - T20 - female - 1378196 - Ireland vs West Indies
2023-07-08 - international - T20 - female - 1336076 - Australia vs England
2023-07-07 - international - ODI - female - 1384544 - Thailand vs Netherlands
2023-07-07 - club - RHF - female - 1347429 - Southern Vipers vs Thunder
2023-07-07 - club - RHF - female - 1347428 - Central Sparks vs South East Stars
2023-07-07 - club - RHF - female - 1347427 - Northern Diamonds vs The Blaze
2023-07-06 - international - T20 - female - 1378195 - Ireland vs West Indies
2023-07-05 - international - T20 - female - 1336075 - England vs Australia
2023-07-04 - international - T20 - female - 1378194 - Ireland vs West Indies
2023-07-03 - international - ODI - female - 1384542 - Netherlands vs Thailand
2023-07-03 - international - ODI - female - 1379759 - New Zealand vs Sri Lanka
2023-07-02 - club - RHF - female - 1347426 - South East Stars vs Northern Diamonds
2023-07-02 - club - RHF - female - 1347425 - Sunrisers vs Southern Vipers
2023-07-02 - club - RHF - female - 1347424 - Central Sparks vs Thunder
2023-07-02 - club - RHF - female - 1347423 - The Blaze vs Western Storm
2023-07-01 - international - T20 - female - 1336074 - England vs Australia
2023-07-01 - international - ODI - female - 1378193 - Ireland vs West Indies
2023-06-30 - international - ODI - female - 1379758 - New Zealand vs Sri Lanka
2023-06-28 - international - ODI - female - 1378192 - Ireland vs West Indies
2023-06-27 - international - ODI - female - 1379757 - New Zealand vs Sri Lanka
2023-06-26 - international - ODI - female - 1378191 - West Indies vs Ireland
2023-06-22 - international - Test - female - 1336073 - Australia vs England
2023-06-14 - international - T20 - female - 1379695 - Malaysia vs United Arab Emirates
2023-06-10 - club - CEC - female - 1347490 - The Blaze vs Southern Vipers
2023-06-10 - club - CEC - female - 1347489 - Southern Vipers vs Thunder
2023-06-07 - club - CEC - female - 1347488 - Northern Diamonds vs Thunder
2023-06-07 - club - CEC - female - 1347487 - Sunrisers vs Southern Vipers
2023-06-07 - club - CEC - female - 1347486 - South East Stars vs Central Sparks
2023-06-07 - club - CEC - female - 1347485 - Western Storm vs The Blaze
2023-06-04 - international - T20 - female - 1376125 - Malaysia vs Nepal
2023-06-04 - club - CEC - female - 1347484 - Thunder vs South East Stars
2023-06-04 - club - CEC - female - 1347483 - The Blaze vs Sunrisers
2023-06-04 - club - CEC - female - 1347482 - Central Sparks vs Western Storm
2023-06-04 - club - CEC - female - 1347481 - Southern Vipers vs Northern Diamonds
2023-06-03 - international - T20 - female - 1376124 - Nepal vs Malaysia
2023-06-03 - club - CEC - female - 1347480 - Central Sparks vs Southern Vipers
2023-06-02 - international - T20 - female - 1378020 - France vs Germany
2023-06-02 - international - T20 - female - 1378019 - Jersey vs Sweden
2023-06-02 - international - T20 - female - 1378018 - Italy vs Turkey
2023-06-02 - club - CEC - female - 1347479 - Northern Diamonds vs The Blaze
2023-06-01 - international - T20 - female - 1378017 - France vs Jersey
2023-06-01 - international - T20 - female - 1378016 - Sweden vs Germany
2023-06-01 - international - T20 - female - 1378015 - France vs Turkey
2023-06-01 - international - T20 - female - 1378014 - Germany vs Italy
2023-06-01 - international - T20 - female - 1376123 - Nepal vs Malaysia
2023-05-31 - club - CEC - female - 1347478 - Sunrisers vs Western Storm
2023-05-31 - club - CEC - female - 1347477 - Thunder vs Southern Vipers
2023-05-30 - international - T20 - female - 1378012 - Turkey vs Jersey
2023-05-30 - international - T20 - female - 1378011 - France vs Sweden
2023-05-30 - international - T20 - female - 1378010 - Jersey vs Germany
2023-05-30 - international - T20 - female - 1376122 - Malaysia vs Nepal
2023-05-29 - international - T20 - female - 1378008 - France vs Italy
2023-05-29 - international - T20 - female - 1378007 - Turkey vs Sweden
2023-05-29 - international - T20 - female - 1378006 - Italy vs Jersey
2023-05-29 - international - T20 - female - 1376121 - Nepal vs Malaysia
2023-05-29 - club - CEC - female - 1347476 - Southern Vipers vs The Blaze
2023-05-29 - club - CEC - female - 1347475 - Thunder vs Central Sparks
2023-05-28 - club - CEC - female - 1347474 - Northern Diamonds vs Sunrisers
2023-05-28 - club - CEC - female - 1347473 - South East Stars vs Western Storm
2023-05-27 - club - CEC - female - 1347472 - Sunrisers vs Thunder
2023-05-26 - club - CEC - female - 1347471 - The Blaze vs Central Sparks
2023-05-26 - club - CEC - female - 1347470 - Western Storm vs Southern Vipers
2023-05-26 - club - CEC - female - 1347469 - South East Stars vs Northern Diamonds
2023-05-25 - club - CEC - female - 1347468 - Sunrisers vs South East Stars
2023-05-25 - club - CEC - female - 1347467 - Thunder vs The Blaze
2023-05-23 - club - CEC - female - 1347466 - Northern Diamonds vs Central Sparks
2023-05-23 - club - CEC - female - 1347465 - South East Stars vs Southern Vipers
2023-05-21 - club - CEC - female - 1347464 - Thunder vs Western Storm
2023-05-20 - club - CEC - female - 1347463 - South East Stars vs The Blaze
2023-05-19 - club - CEC - female - 1347462 - Northern Diamonds vs Western Storm
2023-05-18 - club - CEC - female - 1347461 - Central Sparks vs Sunrisers
2023-05-12 - international - T20 - female - 1371606 - Sri Lanka vs Bangladesh
2023-05-11 - international - T20 - female - 1371605 - Bangladesh vs Sri Lanka
2023-05-10 - club - RHF - female - 1347422 - The Blaze vs Western Storm
2023-05-10 - club - RHF - female - 1347421 - Southern Vipers vs Central Sparks
2023-05-10 - club - RHF - female - 1347420 - South East Stars vs Northern Diamonds
2023-05-10 - club - RHF - female - 1347419 - Thunder vs Sunrisers
2023-05-09 - international - T20 - female - 1371604 - Sri Lanka vs Bangladesh
2023-05-06 - club - RHF - female - 1347417 - Northern Diamonds vs The Blaze
2023-05-06 - club - RHF - female - 1347416 - Thunder vs Central Sparks
2023-05-05 - club - RHF - female - 1347415 - South East Stars vs Sunrisers
2023-05-04 - international - ODI - female - 1368851 - Sri Lanka vs Bangladesh
2023-05-02 - international - T20 - female - 1370914 - Uganda vs Namibia
2023-05-01 - international - T20 - female - 1370912 - Namibia vs Uganda
2023-05-01 - international - T20 - female - 1370911 - United Arab Emirates vs Hong Kong
2023-05-01 - club - RHF - female - 1347414 - South East Stars vs Western Storm
2023-05-01 - club - RHF - female - 1347413 - Sunrisers vs Northern Diamonds
2023-05-01 - club - RHF - female - 1347412 - Central Sparks vs Southern Vipers
2023-04-30 - international - T20 - female - 1370910 - Namibia vs United Arab Emirates
2023-04-29 - international - T20 - female - 1370908 - Namibia vs Uganda
2023-04-29 - international - ODI - female - 1368849 - Sri Lanka vs Bangladesh
2023-04-29 - club - RHF - female - 1347410 - Southern Vipers vs South East Stars
2023-04-29 - club - RHF - female - 1347409 - Sunrisers vs The Blaze
2023-04-29 - club - RHF - female - 1347408 - Thunder vs Western Storm
2023-04-29 - club - RHF - female - 1347407 - Northern Diamonds vs Central Sparks
2023-04-28 - international - T20 - female - 1365323 - Zimbabwe vs Thailand
2023-04-27 - international - T20 - female - 1370906 - United Arab Emirates vs Namibia
2023-04-27 - international - T20 - female - 1370905 - Hong Kong vs Uganda
2023-04-27 - international - T20 - female - 1365322 - Zimbabwe vs Thailand
2023-04-26 - international - T20 - female - 1370904 - United Arab Emirates vs Hong Kong
2023-04-25 - international - T20 - female - 1370903 - Namibia vs Hong Kong
2023-04-25 - international - T20 - female - 1370902 - United Arab Emirates vs Uganda
2023-04-25 - international - T20 - female - 1365321 - Zimbabwe vs Thailand
2023-04-23 - international - ODI - female - 1368832 - Zimbabwe vs Thailand
2023-04-22 - club - RHF - female - 1347406 - The Blaze vs Central Sparks
2023-04-22 - club - RHF - female - 1347405 - Northern Diamonds vs Western Storm
2023-04-22 - club - RHF - female - 1347404 - South East Stars vs Thunder
2023-04-22 - club - RHF - female - 1347403 - Sunrisers vs Southern Vipers
2023-04-21 - international - ODI - female - 1368831 - Thailand vs Zimbabwe
2023-04-19 - international - ODI - female - 1368830 - Thailand vs Zimbabwe
2023-04-16 - club - FRB - female - 1366033 - Warriors vs Falcons
2023-04-16 - club - FRB - female - 1366032 - Barmy Army vs Spirit
2023-04-15 - club - FRB - female - 1366031 - Barmy Army vs Falcons
2023-04-15 - club - FRB - female - 1366030 - Spirit vs Warriors
2023-04-14 - club - FRB - female - 1366029 - Tornadoes vs Sapphires
2023-04-12 - club - FRB - female - 1366028 - Spirit vs Falcons
2023-04-12 - club - FRB - female - 1366027 - Barmy Army vs Sapphires
2023-04-11 - club - FRB - female - 1366026 - Tornadoes vs Spirit
2023-04-11 - club - FRB - female - 1366025 - Sapphires vs Falcons
2023-04-09 - club - FRB - female - 1366024 - Barmy Army vs Warriors
2023-04-09 - club - FRB - female - 1366023 - Sapphires vs Tornadoes
2023-04-08 - club - FRB - female - 1366022 - Warriors vs Spirit
2023-04-08 - club - FRB - female - 1366021 - Tornadoes vs Barmy Army
2023-04-07 - club - FRB - female - 1366020 - Falcons vs Warriors
2023-04-07 - club - FRB - female - 1366019 - Spirit vs Sapphires
2023-04-05 - club - FRB - female - 1366018 - Barmy Army vs Falcons
2023-04-05 - club - FRB - female - 1366017 - Warriors vs Tornadoes
2023-04-04 - club - FRB - female - 1366016 - Barmy Army vs Spirit
2023-04-04 - club - FRB - female - 1366015 - Sapphires vs Warriors
2023-04-03 - club - FRB - female - 1366014 - Falcons vs Tornadoes
2023-03-27 - international - T20 - female - 1365310 - Rwanda vs Ghana
2023-03-26 - club - WPL - female - 1358950 - Delhi Capitals vs Mumbai Indians
2023-03-24 - club - WPL - female - 1358949 - Mumbai Indians vs UP Warriorz
2023-03-21 - club - WPL - female - 1358948 - UP Warriorz vs Delhi Capitals
2023-03-21 - club - WPL - female - 1358947 - Royal Challengers Bangalore vs Mumbai Indians
2023-03-20 - club - WPL - female - 1358946 - Mumbai Indians vs Delhi Capitals
2023-03-20 - club - WPL - female - 1358945 - Gujarat Giants vs UP Warriorz
2023-03-18 - club - WPL - female - 1358944 - Gujarat Giants vs Royal Challengers Bangalore
2023-03-18 - club - WPL - female - 1358943 - Mumbai Indians vs UP Warriorz
2023-03-16 - club - WPL - female - 1358942 - Gujarat Giants vs Delhi Capitals
2023-03-15 - club - WPL - female - 1358941 - UP Warriorz vs Royal Challengers Bangalore
2023-03-14 - club - WPL - female - 1358940 - Mumbai Indians vs Gujarat Giants
2023-03-13 - club - WPL - female - 1358939 - Royal Challengers Bangalore vs Delhi Capitals
2023-03-12 - club - WPL - female - 1358938 - UP Warriorz vs Mumbai Indians
2023-03-11 - club - WPL - female - 1358937 - Gujarat Giants vs Delhi Capitals
2023-03-10 - club - WPL - female - 1358936 - Royal Challengers Bangalore vs UP Warriorz
2023-03-09 - club - WPL - female - 1358935 - Delhi Capitals vs Mumbai Indians
2023-03-08 - club - WPL - female - 1358934 - Gujarat Giants vs Royal Challengers Bangalore
2023-03-07 - club - WPL - female - 1358933 - Delhi Capitals vs UP Warriorz
2023-03-06 - club - WPL - female - 1358932 - Royal Challengers Bangalore vs Mumbai Indians
2023-03-05 - club - WPL - female - 1358931 - Gujarat Giants vs UP Warriorz
2023-03-05 - club - WPL - female - 1358930 - Delhi Capitals vs Royal Challengers Bangalore
2023-03-04 - club - WPL - female - 1358929 - Mumbai Indians vs Gujarat Giants
2023-02-26 - international - T20 - female - 1338062 - Australia vs South Africa
2023-02-24 - international - T20 - female - 1338061 - South Africa vs England
2023-02-23 - international - T20 - female - 1338060 - Australia vs India
2023-02-21 - international - T20 - female - 1338059 - Bangladesh vs South Africa
2023-02-21 - international - T20 - female - 1338058 - England vs Pakistan
2023-02-20 - international - T20 - female - 1338057 - India vs Ireland
2023-02-19 - international - T20 - female - 1338056 - New Zealand vs Sri Lanka
2023-02-19 - international - T20 - female - 1338055 - West Indies vs Pakistan
2023-02-18 - international - T20 - female - 1338054 - South Africa vs Australia
2023-02-18 - international - T20 - female - 1338053 - England vs India
2023-02-17 - international - T20 - female - 1338052 - Ireland vs West Indies
2023-02-17 - international - T20 - female - 1338051 - New Zealand vs Bangladesh
2023-02-16 - international - T20 - female - 1338050 - Sri Lanka vs Australia
2023-02-15 - international - T20 - female - 1338049 - Pakistan vs Ireland
2023-02-15 - international - T20 - female - 1338048 - West Indies vs India
2023-02-14 - international - T20 - female - 1338047 - Bangladesh vs Australia
2023-02-13 - international - T20 - female - 1338046 - South Africa vs New Zealand
2023-02-13 - international - T20 - female - 1338045 - Ireland vs England
2023-02-12 - international - T20 - female - 1355841 - Cambodia vs Singapore
2023-02-12 - international - T20 - female - 1338044 - Bangladesh vs Sri Lanka
2023-02-12 - international - T20 - female - 1338043 - Pakistan vs India
2023-02-11 - international - T20 - female - 1355840 - Cambodia vs Singapore
2023-02-11 - international - T20 - female - 1338042 - Australia vs New Zealand
2023-02-11 - international - T20 - female - 1338041 - West Indies vs England
2023-02-11 - club - SSM - female - 1341257 - Canterbury vs Wellington
2023-02-10 - international - T20 - female - 1355839 - Cambodia vs Singapore
2023-02-10 - international - T20 - female - 1338040 - Sri Lanka vs South Africa
2023-02-09 - international - T20 - female - 1355838 - Singapore vs Cambodia
2023-02-09 - club - SSM - female - 1341256 - Otago vs Canterbury
2023-02-06 - club - SSM - female - 1341255 - Canterbury vs Otago
2023-02-05 - club - SSM - female - 1341254 - Auckland vs Wellington
2023-02-04 - club - SSM - female - 1341253 - Canterbury vs Otago
2023-02-03 - club - SSM - female - 1341252 - Northern Districts vs Central Districts
2023-02-02 - international - T20 - female - 1344517 - India vs South Africa
2023-01-30 - international - T20 - female - 1344516 - West Indies vs India
2023-01-29 - club - SSM - female - 1341250 - Central Districts vs Otago
2023-01-28 - international - T20 - female - 1344515 - India vs South Africa
2023-01-27 - club - SSM - female - 1341248 - Canterbury vs Central Districts
2023-01-26 - international - T20 - female - 1345096 - Pakistan vs Australia
2023-01-25 - international - T20 - female - 1344514 - West Indies vs South Africa
2023-01-24 - international - T20 - female - 1345095 - Pakistan vs Australia
2023-01-23 - international - T20 - female - 1344513 - India vs West Indies
2023-01-23 - club - SSM - female - 1341247 - Wellington vs Canterbury
2023-01-22 - club - SSM - female - 1341246 - Auckland vs Northern Districts
2023-01-21 - international - T20 - female - 1344512 - South Africa vs West Indies
2023-01-21 - international - ODI - female - 1345094 - Australia vs Pakistan
2023-01-21 - club - SSM - female - 1341245 - Central Districts vs Otago
2023-01-20 - club - SSM - female - 1341244 - Wellington vs Auckland
2023-01-19 - international - T20 - female - 1344511 - India vs South Africa
2023-01-18 - international - ODI - female - 1345093 - Pakistan vs Australia
2023-01-16 - international - ODI - female - 1345092 - Pakistan vs Australia
2023-01-15 - club - SSM - female - 1341243 - Otago vs Wellington
2023-01-14 - club - SSM - female - 1341242 - Central Districts vs Auckland
2023-01-13 - club - SSM - female - 1341241 - Northern Districts vs Canterbury
2023-01-08 - club - SSM - female - 1341240 - Canterbury vs Auckland
2023-01-07 - club - SSM - female - 1341239 - Central Districts vs Wellington
2023-01-06 - club - SSM - female - 1341238 - Northern Districts vs Otago
2023-01-05 - club - SSM - female - 1341237 - Auckland vs Central Districts
2023-01-04 - club - SSM - female - 1341236 - Wellington vs Northern Districts
2023-01-02 - club - SSM - female - 1341235 - Otago vs Auckland
2023-01-01 - club - SSM - female - 1341234 - Wellington vs Canterbury
2022-12-31 - club - SSM - female - 1341233 - Northern Districts vs Central Districts
2022-12-30 - club - SSM - female - 1341232 - Central Districts vs Canterbury
2022-12-29 - club - SSM - female - 1341231 - Otago vs Auckland
2022-12-28 - club - SSM - female - 1341230 - Otago vs Northern Districts
2022-12-27 - club - SSM - female - 1341229 - Wellington vs Central Districts
2022-12-26 - club - SSM - female - 1341228 - Auckland vs Canterbury
2022-12-24 - club - SSM - female - 1341227 - Wellington vs Otago
2022-12-23 - club - SSM - female - 1341226 - Canterbury vs Northern Districts
2022-12-22 - international - T20 - female - 1343938 - West Indies vs England
2022-12-21 - international - T20 - female - 1349152 - Kenya vs Uganda
2022-12-21 - international - T20 - female - 1349151 - Tanzania vs Qatar
2022-12-20 - international - T20 - female - 1345428 - Australia vs India
2022-12-19 - international - T20 - female - 1346545 - Tanzania vs Kenya
2022-12-18 - international - T20 - female - 1349150 - Tanzania vs Qatar
2022-12-18 - international - T20 - female - 1346543 - Kenya vs Uganda
2022-12-18 - international - T20 - female - 1343937 - England vs West Indies
2022-12-17 - international - T20 - female - 1345427 - Australia vs India
2022-12-17 - international - T20 - female - 1343936 - England vs West Indies
2022-12-17 - international - ODI - female - 1322343 - New Zealand vs Bangladesh
2022-12-15 - international - T20 - female - 1346539 - Qatar vs Kenya
2022-12-14 - international - T20 - female - 1345426 - Australia vs India
2022-12-14 - international - T20 - female - 1343935 - England vs West Indies
2022-12-14 - international - ODI - female - 1322342 - Bangladesh vs New Zealand
2022-12-11 - international - T20 - female - 1345425 - Australia vs India
2022-12-11 - international - T20 - female - 1343934 - West Indies vs England
2022-12-11 - international - ODI - female - 1322341 - Bangladesh vs New Zealand
2022-12-09 - international - T20 - female - 1345424 - India vs Australia
2022-12-09 - international - ODI - female - 1343933 - England vs West Indies
2022-12-07 - international - T20 - female - 1344621 - New Zealand vs Bangladesh
2022-12-06 - international - ODI - female - 1343932 - England vs West Indies
2022-12-04 - international - T20 - female - 1344620 - New Zealand vs Bangladesh
2022-12-04 - international - ODI - female - 1343931 - England vs West Indies
2022-12-03 - international - T20 - female - 1344510 - Thailand vs Netherlands
2022-12-02 - international - T20 - female - 1344619 - New Zealand vs Bangladesh
2022-12-02 - international - T20 - female - 1344509 - Netherlands vs Thailand
2022-11-30 - international - T20 - female - 1344508 - Thailand vs Netherlands
2022-11-29 - international - T20 - female - 1344507 - Netherlands vs Thailand
2022-11-26 - international - ODI - female - 1344506 - Netherlands vs Thailand
2022-11-26 - club - WBB - female - 1341268 - Adelaide Strikers vs Sydney Sixers
2022-11-24 - international - ODI - female - 1344505 - Thailand vs Netherlands
2022-11-24 - club - WBB - female - 1341267 - Brisbane Heat vs Adelaide Strikers
2022-11-23 - club - WBB - female - 1341266 - Brisbane Heat vs Hobart Hurricanes
2022-11-22 - international - ODI - female - 1344504 - Thailand vs Netherlands
2022-11-20 - international - ODI - female - 1344503 - Thailand vs Netherlands
2022-11-20 - club - WBB - female - 1323609 - Adelaide Strikers vs Sydney Thunder
2022-11-20 - club - WBB - female - 1323608 - Brisbane Heat vs Melbourne Stars
2022-11-20 - club - WBB - female - 1323607 - Hobart Hurricanes vs Sydney Sixers
2022-11-20 - club - WBB - female - 1323606 - Perth Scorchers vs Melbourne Renegades
2022-11-19 - club - WBB - female - 1323605 - Melbourne Stars vs Perth Scorchers
2022-11-18 - club - WBB - female - 1323604 - Sydney Sixers vs Sydney Thunder
2022-11-18 - club - WBB - female - 1323603 - Hobart Hurricanes vs Adelaide Strikers
2022-11-16 - international - T20 - female - 1308238 - Ireland vs Pakistan
2022-11-16 - club - WBB - female - 1323602 - Brisbane Heat vs Sydney Sixers
2022-11-16 - club - WBB - female - 1323601 - Hobart Hurricanes vs Melbourne Stars
2022-11-15 - club - WBB - female - 1323600 - Sydney Thunder vs Melbourne Renegades
2022-11-15 - club - WBB - female - 1323599 - Hobart Hurricanes vs Melbourne Stars
2022-11-14 - international - T20 - female - 1339558 - Spain vs Sweden
2022-11-14 - international - T20 - female - 1308237 - Ireland vs Pakistan
2022-11-14 - club - WBB - female - 1323598 - Brisbane Heat vs Adelaide Strikers
2022-11-13 - international - T20 - female - 1339555 - Spain vs Norway
2022-11-13 - club - WBB - female - 1323597 - Adelaide Strikers vs Sydney Thunder
2022-11-13 - club - WBB - female - 1323596 - Melbourne Renegades vs Melbourne Stars
2022-11-13 - club - WBB - female - 1323595 - Perth Scorchers vs Sydney Sixers
2022-11-12 - international - T20 - female - 1308236 - Pakistan vs Ireland
2022-11-12 - club - WBB - female - 1323594 - Brisbane Heat vs Hobart Hurricanes
2022-11-12 - club - WBB - female - 1323593 - Sydney Sixers vs Melbourne Stars
2022-11-12 - club - WBB - female - 1323592 - Perth Scorchers vs Melbourne Renegades
2022-11-11 - club - WBB - female - 1323591 - Hobart Hurricanes vs Adelaide Strikers
2022-11-10 - club - WBB - female - 1323590 - Melbourne Renegades vs Sydney Sixers
2022-11-09 - international - ODI - female - 1308235 - Ireland vs Pakistan
2022-11-09 - club - WBB - female - 1323589 - Brisbane Heat vs Perth Scorchers
2022-11-07 - club - WBB - female - 1323588 - Melbourne Renegades vs Hobart Hurricanes
2022-11-06 - international - ODI - female - 1308234 - Ireland vs Pakistan
2022-11-06 - club - WBB - female - 1323587 - Perth Scorchers vs Adelaide Strikers
2022-11-06 - club - WBB - female - 1323586 - Sydney Thunder vs Melbourne Renegades
2022-11-06 - club - WBB - female - 1323585 - Hobart Hurricanes vs Brisbane Heat
2022-11-05 - club - WBB - female - 1323584 - Sydney Sixers vs Perth Scorchers
2022-11-05 - club - WBB - female - 1323583 - Melbourne Stars vs Adelaide Strikers
2022-11-04 - international - ODI - female - 1308233 - Pakistan vs Ireland
2022-11-04 - club - WBB - female - 1323582 - Brisbane Heat vs Sydney Thunder
2022-11-03 - club - WBB - female - 1323581 - Melbourne Renegades vs Hobart Hurricanes
2022-11-02 - club - WBB - female - 1323580 - Sydney Sixers vs Sydney Thunder
2022-11-02 - club - WBB - female - 1323579 - Melbourne Stars vs Adelaide Strikers
2022-10-31 - club - WBB - female - 1323578 - Sydney Thunder vs Melbourne Stars
2022-10-30 - international - T20 - female - 1336982 - Hong Kong vs Japan
2022-10-30 - club - WBB - female - 1323577 - Sydney Sixers vs Melbourne Renegades
2022-10-29 - international - T20 - female - 1336981 - Hong Kong vs Japan
2022-10-29 - club - WBB - female - 1323576 - Perth Scorchers vs Brisbane Heat
2022-10-29 - club - WBB - female - 1323575 - Melbourne Renegades vs Melbourne Stars
2022-10-29 - club - WBB - female - 1323574 - Hobart Hurricanes vs Sydney Sixers
2022-10-28 - international - T20 - female - 1336980 - Japan vs Hong Kong
2022-10-28 - club - WBB - female - 1323573 - Perth Scorchers vs Adelaide Strikers
2022-10-27 - international - T20 - female - 1336979 - Japan vs Hong Kong
2022-10-27 - club - WBB - female - 1323572 - Adelaide Strikers vs Brisbane Heat
2022-10-25 - club - WBB - female - 1323571 - Sydney Thunder vs Brisbane Heat
2022-10-24 - club - WBB - female - 1323570 - Melbourne Renegades vs Adelaide Strikers
2022-10-23 - club - WBB - female - 1323568 - Sydney Thunder vs Melbourne Stars
2022-10-22 - club - WBB - female - 1323567 - Sydney Thunder vs Perth Scorchers
2022-10-21 - club - WBB - female - 1323566 - Adelaide Strikers vs Sydney Sixers
2022-10-21 - club - WBB - female - 1323565 - Brisbane Heat vs Melbourne Renegades
2022-10-20 - club - WBB - female - 1323564 - Melbourne Stars vs Perth Scorchers
2022-10-18 - club - WBB - female - 1323563 - Hobart Hurricanes vs Sydney Thunder
2022-10-18 - club - WBB - female - 1323562 - Brisbane Heat vs Melbourne Renegades
2022-10-17 - club - WBB - female - 1323561 - Hobart Hurricanes vs Perth Scorchers
2022-10-16 - club - WBB - female - 1323560 - Sydney Thunder vs Perth Scorchers
2022-10-16 - club - WBB - female - 1323559 - Sydney Sixers vs Melbourne Stars
2022-10-16 - club - WBB - female - 1323558 - Adelaide Strikers vs Melbourne Renegades
2022-10-15 - international - T20 - female - 1335808 - Sri Lanka vs India
2022-10-15 - club - WBB - female - 1323557 - Brisbane Heat vs Melbourne Stars
2022-10-15 - club - WBB - female - 1323556 - Sydney Sixers vs Adelaide Strikers
2022-10-14 - club - WBB - female - 1323555 - Hobart Hurricanes vs Sydney Thunder
2022-10-13 - international - T20 - female - 1335807 - Sri Lanka vs Pakistan
2022-10-13 - international - T20 - female - 1335806 - India vs Thailand
2022-10-13 - club - WBB - female - 1323554 - Brisbane Heat vs Sydney Sixers
2022-10-11 - international - T20 - female - 1335805 - Sri Lanka vs Pakistan
2022-10-10 - international - T20 - female - 1335803 - Thailand vs India
2022-10-10 - international - T20 - female - 1335802 - Sri Lanka vs Bangladesh
2022-10-09 - international - T20 - female - 1335801 - Pakistan vs United Arab Emirates
2022-10-09 - international - T20 - female - 1335800 - Thailand vs Malaysia
2022-10-08 - international - T20 - female - 1335799 - India vs Bangladesh
2022-10-08 - international - T20 - female - 1335798 - Sri Lanka vs Malaysia
2022-10-07 - international - T20 - female - 1335797 - Pakistan vs India
2022-10-07 - international - T20 - female - 1335796 - Thailand vs United Arab Emirates
2022-10-06 - international - T20 - female - 1335795 - Bangladesh vs Malaysia
2022-10-06 - international - T20 - female - 1335794 - Pakistan vs Thailand
2022-10-06 - international - T20 - female - 1334419 - West Indies vs New Zealand
2022-10-05 - international - T20 - female - 1335793 - Malaysia vs United Arab Emirates
2022-10-05 - international - T20 - female - 1334418 - New Zealand vs West Indies
2022-10-04 - international - T20 - female - 1335792 - India vs United Arab Emirates
2022-10-04 - international - T20 - female - 1335791 - Sri Lanka vs Thailand
2022-10-03 - international - T20 - female - 1335790 - India vs Malaysia
2022-10-03 - international - T20 - female - 1335789 - Bangladesh vs Pakistan
2022-10-02 - international - T20 - female - 1335788 - Sri Lanka vs United Arab Emirates
2022-10-02 - international - T20 - female - 1335787 - Malaysia vs Pakistan
2022-10-02 - international - T20 - female - 1334417 - West Indies vs New Zealand
2022-10-01 - international - T20 - female - 1335786 - India vs Sri Lanka
2022-10-01 - international - T20 - female - 1335785 - Thailand vs Bangladesh
2022-10-01 - international - T20 - female - 1334416 - West Indies vs New Zealand
2022-09-28 - international - T20 - female - 1334415 - West Indies vs New Zealand
2022-09-25 - international - T20 - female - 1331403 - Scotland vs Papua New Guinea
2022-09-25 - international - T20 - female - 1331402 - United States of America vs United Arab Emirates
2022-09-25 - international - T20 - female - 1331401 - Bangladesh vs Ireland
2022-09-25 - international - T20 - female - 1331400 - Zimbabwe vs Thailand
2022-09-25 - international - ODI - female - 1334414 - New Zealand vs West Indies
2022-09-25 - club - RHF - female - 1297956 - Northern Diamonds vs Southern Vipers
2022-09-24 - international - ODI - female - 1301339 - India vs England
2022-09-23 - international - T20 - female - 1331399 - United States of America vs Papua New Guinea
2022-09-23 - international - T20 - female - 1331398 - Bangladesh vs Thailand
2022-09-23 - international - T20 - female - 1331397 - Scotland vs United Arab Emirates
2022-09-23 - international - T20 - female - 1331396 - Ireland vs Zimbabwe
2022-09-22 - international - ODI - female - 1334413 - West Indies vs New Zealand
2022-09-21 - international - T20 - female - 1331395 - Zimbabwe vs United Arab Emirates
2022-09-21 - international - T20 - female - 1331394 - Ireland vs Scotland
2022-09-21 - international - T20 - female - 1331392 - Bangladesh vs United States of America
2022-09-21 - international - ODI - female - 1301338 - India vs England
2022-09-21 - club - RHF - female - 1297955 - South East Stars vs Southern Vipers
2022-09-19 - international - T20 - female - 1331391 - United States of America vs Ireland
2022-09-19 - international - T20 - female - 1331390 - Papua New Guinea vs United Arab Emirates
2022-09-19 - international - T20 - female - 1331389 - Scotland vs Bangladesh
2022-09-19 - international - T20 - female - 1331388 - Thailand vs Zimbabwe
2022-09-19 - international - ODI - female - 1334412 - West Indies vs New Zealand
2022-09-18 - international - T20 - female - 1331387 - Scotland vs United States of America
2022-09-18 - international - T20 - female - 1331386 - Papua New Guinea vs Zimbabwe
2022-09-18 - international - T20 - female - 1331385 - Bangladesh vs Ireland
2022-09-18 - international - T20 - female - 1331384 - United Arab Emirates vs Thailand
2022-09-18 - international - ODI - female - 1301337 - England vs India
2022-09-18 - club - RHF - female - 1297951 - Thunder vs Western Storm
2022-09-17 - club - RHF - female - 1297954 - South East Stars vs Lightning
2022-09-17 - club - RHF - female - 1297953 - Central Sparks vs Sunrisers
2022-09-17 - club - RHF - female - 1297952 - Southern Vipers vs Northern Diamonds
2022-09-15 - international - T20 - female - 1301336 - India vs England
2022-09-13 - international - T20 - female - 1329250 - United States of America vs United Arab Emirates
2022-09-13 - international - T20 - female - 1301335 - England vs India
2022-09-12 - international - T20 - female - 1329247 - Zimbabwe vs United Arab Emirates
2022-09-11 - club - RHF - female - 1297950 - Northern Diamonds vs Western Storm
2022-09-11 - club - RHF - female - 1297949 - Lightning vs Sunrisers
2022-09-11 - club - RHF - female - 1297948 - South East Stars vs Central Sparks
2022-09-11 - club - RHF - female - 1297947 - Thunder vs Southern Vipers
2022-09-10 - international - T20 - female - 1301334 - India vs England
2022-09-06 - international - T20 - female - 1330808 - Scotland vs Ireland
2022-09-05 - international - T20 - female - 1330807 - Scotland vs Ireland
2022-09-04 - club - WCL - female - 1323181 - Trinbago Knight Riders vs Barbados Royals
2022-09-03 - club - WCL - female - 1323180 - Guyana Amazon Warriors vs Barbados Royals
2022-09-03 - club - HND - female - 1299170 - Southern Brave vs Oval Invincibles
2022-09-02 - club - HND - female - 1299169 - Southern Brave vs Trent Rockets
2022-09-01 - club - WCL - female - 1323179 - Trinbago Knight Riders vs Guyana Amazon Warriors
2022-08-31 - club - WCL - female - 1323178 - Trinbago Knight Riders vs Barbados Royals
2022-08-31 - club - HND - female - 1299168 - Oval Invincibles vs Manchester Originals
2022-08-31 - club - HND - female - 1299167 - Northern Superchargers vs Southern Brave
2022-08-30 - club - HND - female - 1299166 - Birmingham Phoenix vs London Spirit
2022-08-29 - club - HND - female - 1299165 - Welsh Fire vs Trent Rockets
2022-08-28 - club - HND - female - 1299164 - Manchester Originals vs Birmingham Phoenix
2022-08-27 - club - HND - female - 1299163 - London Spirit vs Oval Invincibles
2022-08-26 - international - ODI - female - 1328487 - Netherlands vs Ireland
2022-08-26 - club - HND - female - 1299162 - Welsh Fire vs Northern Superchargers
2022-08-25 - club - HND - female - 1299161 - Trent Rockets vs Southern Brave
2022-08-24 - international - ODI - female - 1328486 - Ireland vs Netherlands
2022-08-24 - club - HND - female - 1299160 - Welsh Fire vs London Spirit
2022-08-23 - club - HND - female - 1299159 - Birmingham Phoenix vs Oval Invincibles
2022-08-22 - international - ODI - female - 1328485 - Netherlands vs Ireland
2022-08-22 - club - HND - female - 1299158 - Southern Brave vs Welsh Fire
2022-08-21 - club - HND - female - 1299157 - Manchester Originals vs Northern Superchargers
2022-08-20 - club - HND - female - 1299156 - Trent Rockets vs London Spirit
2022-08-19 - club - HND - female - 1299155 - Birmingham Phoenix vs Northern Superchargers
2022-08-18 - club - HND - female - 1299154 - Southern Brave vs Manchester Originals
2022-08-17 - club - HND - female - 1299153 - Trent Rockets vs Oval Invincibles
2022-08-16 - club - HND - female - 1299152 - Manchester Originals vs Welsh Fire
2022-08-15 - club - HND - female - 1299151 - Trent Rockets vs Birmingham Phoenix
2022-08-14 - club - HND - female - 1299150 - Southern Brave vs Oval Invincibles
2022-08-14 - club - HND - female - 1299149 - Northern Superchargers vs London Spirit
2022-08-13 - club - HND - female - 1299148 - Birmingham Phoenix vs Welsh Fire
2022-08-13 - club - HND - female - 1299147 - Trent Rockets vs Manchester Originals
2022-08-12 - club - HND - female - 1299146 - London Spirit vs Southern Brave
2022-08-11 - club - HND - female - 1299145 - Northern Superchargers vs Oval Invincibles
2022-08-07 - international - T20 - female - 1289274 - Australia vs India
2022-08-07 - international - T20 - female - 1289273 - England vs New Zealand
2022-08-06 - international - T20 - female - 1289272 - New Zealand vs Australia
2022-08-06 - international - T20 - female - 1289271 - India vs England
2022-08-04 - international - T20 - female - 1289270 - New Zealand vs England
2022-08-04 - international - T20 - female - 1289269 - Sri Lanka vs South Africa
2022-08-03 - international - T20 - female - 1289268 - India vs Barbados
2022-08-03 - international - T20 - female - 1289267 - Australia vs Pakistan
2022-08-02 - international - T20 - female - 1289266 - New Zealand vs Sri Lanka
2022-08-02 - international - T20 - female - 1289265 - England vs South Africa
2022-07-31 - international - T20 - female - 1289264 - Barbados vs Australia
2022-07-31 - international - T20 - female - 1289263 - Pakistan vs India
2022-07-30 - international - T20 - female - 1289262 - Sri Lanka vs England
2022-07-30 - international - T20 - female - 1289261 - New Zealand vs South Africa
2022-07-29 - international - T20 - female - 1289260 - Barbados vs Pakistan
2022-07-29 - international - T20 - female - 1289259 - India vs Australia
2022-07-25 - international - T20 - female - 1301333 - England vs South Africa
2022-07-23 - international - T20 - female - 1317639 - Pakistan vs Australia
2022-07-23 - international - T20 - female - 1301332 - South Africa vs England
2022-07-23 - club - RHF - female - 1297942 - Lightning vs Northern Diamonds
2022-07-23 - club - RHF - female - 1297941 - Thunder vs Central Sparks
2022-07-23 - club - RHF - female - 1297940 - South East Stars vs Western Storm
2022-07-23 - club - RHF - female - 1297939 - Southern Vipers vs Sunrisers
2022-07-21 - international - T20 - female - 1317638 - Australia vs Ireland
2022-07-21 - international - T20 - female - 1301331 - South Africa vs England
2022-07-19 - international - T20 - female - 1317637 - Pakistan vs Ireland
2022-07-18 - international - ODI - female - 1301330 - England vs South Africa
2022-07-17 - international - T20 - female - 1317636 - Ireland vs Australia
2022-07-16 - international - T20 - female - 1317635 - Pakistan vs Australia
2022-07-16 - club - RHF - female - 1297938 - Southern Vipers vs Lightning
2022-07-16 - club - RHF - female - 1297937 - Sunrisers vs Western Storm
2022-07-16 - club - RHF - female - 1297936 - South East Stars vs Thunder
2022-07-16 - club - RHF - female - 1297935 - Central Sparks vs Northern Diamonds
2022-07-15 - international - ODI - female - 1301329 - England vs South Africa
2022-07-11 - international - ODI - female - 1301328 - South Africa vs England
2022-07-10 - international - T20 - female - 1322020 - Malaysia vs Singapore
2022-07-09 - international - T20 - female - 1322019 - Malaysia vs Singapore
2022-07-09 - club - RHF - female - 1297934 - Southern Vipers vs South East Stars
2022-07-09 - club - RHF - female - 1297933 - Thunder vs Lightning
2022-07-09 - club - RHF - female - 1297932 - Northern Diamonds vs Sunrisers
2022-07-09 - club - RHF - female - 1297931 - Central Sparks vs Western Storm
2022-07-08 - international - T20 - female - 1322018 - Singapore vs Malaysia
2022-07-07 - international - ODI - female - 1319714 - India vs Sri Lanka
2022-07-04 - international - ODI - female - 1319713 - Sri Lanka vs India
2022-07-03 - club - RHF - female - 1297930 - Thunder vs Northern Diamonds
2022-07-02 - club - RHF - female - 1297929 - Central Sparks vs Southern Vipers
2022-07-02 - club - RHF - female - 1297928 - Western Storm vs Lightning
2022-07-02 - club - RHF - female - 1297927 - South East Stars vs Sunrisers
2022-07-01 - international - T20 - female - 1321337 - Netherlands vs Namibia
2022-07-01 - international - ODI - female - 1319712 - Sri Lanka vs India
2022-06-30 - international - T20 - female - 1322176 - Netherlands vs Namibia
2022-06-30 - international - T20 - female - 1321336 - Namibia vs Netherlands
2022-06-28 - international - T20 - female - 1321335 - Netherlands vs Namibia
2022-06-27 - international - Test - female - 1301327 - South Africa vs England
2022-06-27 - international - T20 - female - 1319711 - India vs Sri Lanka
2022-06-25 - international - T20 - female - 1320997 - Jersey vs Guernsey
2022-06-25 - international - T20 - female - 1320212 - Malaysia vs United Arab Emirates
2022-06-25 - international - T20 - female - 1319710 - Sri Lanka vs India
2022-06-25 - club - SFT - female - wi_212064 - Barbados vs Jamaica
2022-06-24 - international - T20 - female - 1320211 - Malaysia vs Hong Kong
2022-06-24 - international - T20 - female - 1320210 - United Arab Emirates vs Nepal
2022-06-24 - club - SFT - female - wi_212063 - Windward Islands vs Leeward Islands
2022-06-23 - international - T20 - female - 1319709 - India vs Sri Lanka
2022-06-23 - club - SFT - female - wi_212062 - Guyana vs Jamaica
2022-06-22 - international - T20 - female - 1320209 - Bhutan vs Bahrain
2022-06-22 - international - T20 - female - 1320208 - United Arab Emirates vs Qatar
2022-06-22 - international - T20 - female - 1320207 - Hong Kong vs Kuwait
2022-06-22 - international - T20 - female - 1320206 - Malaysia vs Oman
2022-06-22 - club - SFT - female - wi_212061 - Barbados vs Trinidad and Tobago
2022-06-21 - international - T20 - female - 1320205 - Nepal vs Hong Kong
2022-06-21 - international - T20 - female - 1320204 - Bhutan vs Kuwait
2022-06-21 - international - T20 - female - 1320203 - Singapore vs Qatar
2022-06-21 - club - SFT - female - wi_211979 - Guyana vs Leeward Islands
2022-06-20 - international - T20 - female - 1320202 - Oman vs Singapore
2022-06-20 - international - T20 - female - 1320201 - Bahrain vs Nepal
2022-06-20 - international - T20 - female - 1320200 - United Arab Emirates vs Malaysia
2022-06-20 - club - SFT - female - wi_211973 - Jamaica vs Windward Islands
2022-06-19 - international - T20 - female - 1320199 - Oman vs Qatar
2022-06-19 - international - T20 - female - 1320198 - Bahrain vs Hong Kong
2022-06-18 - international - T20 - female - 1320197 - Nepal vs Kuwait
2022-06-18 - international - T20 - female - 1320196 - Qatar vs Malaysia
2022-06-18 - international - T20 - female - 1320195 - Hong Kong vs Bhutan
2022-06-18 - international - T20 - female - 1320194 - Singapore vs United Arab Emirates
2022-06-18 - international - T20 - female - 1318404 - Tanzania vs Kenya
2022-06-18 - club - SFT - female - wi_211977 - Jamaica vs Barbados
2022-06-17 - international - T20 - female - 1320193 - Bahrain vs Kuwait
2022-06-17 - international - T20 - female - 1320192 - Oman vs United Arab Emirates
2022-06-17 - international - T20 - female - 1320191 - Nepal vs Bhutan
2022-06-17 - international - T20 - female - 1320190 - Malaysia vs Singapore
2022-06-17 - international - ODI - female - 1316647 - South Africa vs Ireland
2022-06-17 - club - SFT - female - wi_211976 - Trinidad and Tobago vs Leeward Islands
2022-06-15 - international - T20 - female - 1318396 - Kenya vs Brazil
2022-06-15 - international - T20 - female - 1318395 - Nigeria vs Tanzania
2022-06-15 - international - T20 - female - 1318394 - Uganda vs Germany
2022-06-15 - international - T20 - female - 1318393 - Botswana vs Rwanda
2022-06-14 - international - ODI - female - 1316646 - Ireland vs South Africa
2022-06-14 - club - BLZ - female - wi_211838 - Windward Islands vs Guyana
2022-06-14 - club - BLZ - female - wi_211836 - Jamaica vs Leeward Islands
2022-06-13 - club - BLZ - female - wi_211835 - Leeward Islands vs Guyana
2022-06-13 - club - BLZ - female - wi_211834 - Windward Islands vs Trinidad and Tobago
2022-06-13 - club - BLZ - female - wi_211833 - Jamaica vs Barbados
2022-06-11 - international - T20 - female - 1318383 - Botswana vs Nigeria
2022-06-11 - international - T20 - female - 1318382 - Rwanda vs Kenya
2022-06-11 - international - T20 - female - 1318381 - Uganda vs Tanzania
2022-06-11 - international - T20 - female - 1318380 - Brazil vs Germany
2022-06-11 - international - ODI - female - 1316645 - Ireland vs South Africa
2022-06-11 - club - CEC - female - 1298076 - Central Sparks vs Southern Vipers
2022-06-11 - club - CEC - female - 1298075 - South East Stars vs Central Sparks
2022-06-11 - club - BLZ - female - wi_211832 - Leeward Islands vs Trinidad and Tobago
2022-06-11 - club - BLZ - female - wi_211831 - Jamaica vs Guyana
2022-06-11 - club - BLZ - female - wi_211830 - Barbados vs Windward Islands
2022-06-10 - international - T20 - female - 1318379 - Germany vs Nigeria
2022-06-10 - international - T20 - female - 1318378 - Rwanda vs Brazil
2022-06-10 - international - T20 - female - 1318377 - Tanzania vs Botswana
2022-06-10 - international - T20 - female - 1318376 - Uganda vs Kenya
2022-06-09 - international - T20 - female - 1318375 - Brazil vs Nigeria
2022-06-09 - international - T20 - female - 1318373 - Rwanda vs Uganda
2022-06-09 - club - BLZ - female - wi_211829 - Jamaica vs Windward Islands
2022-06-09 - club - BLZ - female - wi_211828 - Leeward Islands vs Barbados
2022-06-08 - international - T20 - female - 1316644 - Ireland vs South Africa
2022-06-07 - club - BLZ - female - wi_211826 - Jamaica vs Trinidad and Tobago
2022-06-07 - club - BLZ - female - wi_211825 - Barbados vs Guyana
2022-06-07 - club - BLZ - female - wi_211824 - Leeward Islands vs Windward Islands
2022-06-06 - international - T20 - female - 1316643 - Ireland vs South Africa
2022-06-05 - international - ODI - female - 1310986 - Sri Lanka vs Pakistan
2022-06-05 - club - CEC - female - 1298074 - South East Stars vs Sunrisers
2022-06-04 - club - CEC - female - 1298073 - Central Sparks vs Western Storm
2022-06-04 - club - CEC - female - 1298072 - Northern Diamonds vs Southern Vipers
2022-06-03 - international - T20 - female - 1316642 - Ireland vs South Africa
2022-06-03 - international - ODI - female - 1310985 - Pakistan vs Sri Lanka
2022-06-03 - club - CEC - female - 1298071 - Lightning vs Thunder
2022-06-01 - international - ODI - female - 1310984 - Sri Lanka vs Pakistan
2022-06-01 - club - CEC - female - 1298070 - Thunder vs Southern Vipers
2022-06-01 - club - CEC - female - 1298069 - Northern Diamonds vs Lightning
2022-06-01 - club - CEC - female - 1298068 - Central Sparks vs Sunrisers
2022-06-01 - club - CEC - female - 1298067 - Western Storm vs South East Stars
2022-05-29 - club - CEC - female - 1298066 - Lightning vs Southern Vipers
2022-05-29 - club - CEC - female - 1298065 - Northern Diamonds vs Thunder
2022-05-29 - club - CEC - female - 1298064 - South East Stars vs Central Sparks
2022-05-29 - club - CEC - female - 1298063 - Western Storm vs Sunrisers
2022-05-28 - international - T20 - female - 1310983 - Sri Lanka vs Pakistan
2022-05-28 - club - WTC - female - 1314906 - Supernovas vs Velocity
2022-05-26 - international - T20 - female - 1310982 - Sri Lanka vs Pakistan
2022-05-26 - club - WTC - female - 1314905 - Trailblazers vs Velocity
2022-05-24 - international - T20 - female - 1310981 - Sri Lanka vs Pakistan
2022-05-24 - club - WTC - female - 1314904 - Supernovas vs Velocity
2022-05-23 - club - WTC - female - 1314903 - Supernovas vs Trailblazers
2022-05-21 - international - T20 - female - 1314901 - Nepal vs Uganda
2022-05-21 - club - CEC - female - 1298062 - Central Sparks vs Sunrisers
2022-05-21 - club - CEC - female - 1298061 - Thunder vs Lightning
2022-05-21 - club - CEC - female - 1298060 - Southern Vipers vs Northern Diamonds
2022-05-21 - club - CEC - female - 1298059 - Western Storm vs South East Stars
2022-05-20 - international - T20 - female - 1314900 - Nepal vs Uganda
2022-05-19 - international - T20 - female - 1314899 - Nepal vs Uganda
2022-05-18 - club - CEC - female - 1298058 - Sunrisers vs Western Storm
2022-05-18 - club - CEC - female - 1298057 - Central Sparks vs South East Stars
2022-05-18 - club - CEC - female - 1298056 - Southern Vipers vs Lightning
2022-05-18 - club - CEC - female - 1298055 - Thunder vs Northern Diamonds
2022-05-17 - international - T20 - female - 1314898 - Nepal vs Uganda
2022-05-16 - international - T20 - female - 1314897 - Uganda vs Nepal
2022-05-15 - club - FRB - female - 1313212 - Falcons vs Tornadoes
2022-05-15 - club - FRB - female - 1313211 - Barmy Army vs Spirit
2022-05-14 - club - FRB - female - 1313210 - Barmy Army vs Tornadoes
2022-05-14 - club - FRB - female - 1313209 - Falcons vs Spirit
2022-05-14 - club - CEC - female - 1298054 - Northern Diamonds vs Lightning
2022-05-14 - club - CEC - female - 1298053 - Sunrisers vs South East Stars
2022-05-14 - club - CEC - female - 1298052 - Central Sparks vs Western Storm
2022-05-14 - club - CEC - female - 1298051 - Thunder vs Southern Vipers
2022-05-12 - club - FRB - female - 1313208 - Warriors (FairBreak) vs Barmy Army
2022-05-12 - club - FRB - female - 1313207 - Falcons vs Tornadoes
2022-05-11 - club - FRB - female - 1313206 - Spirit vs Tornadoes
2022-05-11 - club - FRB - female - 1313205 - Sapphires vs Falcons
2022-05-10 - club - FRB - female - 1313204 - Barmy Army vs Sapphires
2022-05-10 - club - FRB - female - 1313203 - Spirit vs Warriors (FairBreak)
2022-05-08 - club - FRB - female - 1313202 - Tornadoes vs Barmy Army
2022-05-08 - club - FRB - female - 1313201 - Spirit vs Sapphires
2022-05-07 - club - FRB - female - 1313200 - Warriors (FairBreak) vs Sapphires
2022-05-07 - club - FRB - female - 1313199 - Spirit vs Falcons
2022-05-06 - club - FRB - female - 1313198 - Tornadoes vs Warriors (FairBreak)
2022-05-06 - club - FRB - female - 1313197 - Barmy Army vs Falcons
2022-05-05 - club - FRB - female - 1313196 - Barmy Army vs Spirit
2022-05-05 - club - FRB - female - 1313195 - Tornadoes vs Sapphires
2022-05-04 - club - FRB - female - 1313194 - Warriors (FairBreak) vs Falcons
2022-04-30 - international - T20 - female - 1311747 - Hong Kong vs United Arab Emirates
2022-04-29 - international - T20 - female - 1311746 - United Arab Emirates vs Hong Kong
2022-04-28 - international - T20 - female - 1311745 - United Arab Emirates vs Hong Kong
2022-04-27 - international - T20 - female - 1311744 - Hong Kong vs United Arab Emirates
2022-04-26 - international - T20 - female - 1310896 - Namibia vs Zimbabwe
2022-04-25 - international - T20 - female - 1310895 - Uganda vs Namibia
2022-04-24 - international - T20 - female - 1310894 - Zimbabwe vs Namibia
2022-04-24 - international - T20 - female - 1310893 - Zimbabwe vs Uganda
2022-04-23 - international - T20 - female - 1310892 - Namibia vs Uganda
2022-04-23 - international - T20 - female - 1310891 - Namibia vs Zimbabwe
2022-04-22 - international - T20 - female - 1310890 - Zimbabwe vs Uganda
2022-04-21 - international - T20 - female - 1310889 - Namibia vs Uganda
2022-04-21 - international - T20 - female - 1310887 - Zimbabwe vs Uganda
2022-04-20 - international - T20 - female - 1310888 - Zimbabwe vs Namibia
2022-04-03 - international - ODI - female - 1243938 - Australia vs England
2022-03-31 - international - ODI - female - 1243937 - England vs South Africa
2022-03-30 - international - ODI - female - 1243936 - Australia vs West Indies
2022-03-27 - international - ODI - female - 1243935 - India vs South Africa
2022-03-27 - international - ODI - female - 1243934 - England vs Bangladesh
2022-03-26 - international - T20 - female - 1306397 - United Arab Emirates vs Bahrain
2022-03-26 - international - T20 - female - 1306396 - Oman vs Qatar
2022-03-26 - international - ODI - female - 1243933 - New Zealand vs Pakistan
2022-03-25 - international - T20 - female - 1306395 - Kuwait vs Bahrain
2022-03-25 - international - T20 - female - 1306394 - Qatar vs Saudi Arabia
2022-03-25 - international - ODI - female - 1243932 - Bangladesh vs Australia
2022-03-24 - international - T20 - female - 1306393 - Saudi Arabia vs United Arab Emirates
2022-03-24 - international - T20 - female - 1306392 - Oman vs Kuwait
2022-03-24 - international - ODI - female - 1243931 - Pakistan vs England
2022-03-24 - international - ODI - female - 1243930 - South Africa vs West Indies
2022-03-22 - international - T20 - female - 1306391 - United Arab Emirates vs Oman
2022-03-22 - international - T20 - female - 1306390 - Qatar vs Kuwait
2022-03-22 - international - T20 - female - 1306389 - Bahrain vs Saudi Arabia
2022-03-22 - international - ODI - female - 1243929 - India vs Bangladesh
2022-03-22 - international - ODI - female - 1243928 - South Africa vs Australia
2022-03-21 - international - T20 - female - 1306388 - United Arab Emirates vs Kuwait
2022-03-21 - international - T20 - female - 1306387 - Oman vs Saudi Arabia
2022-03-21 - international - T20 - female - 1306386 - Qatar vs Bahrain
2022-03-21 - international - ODI - female - 1243927 - West Indies vs Pakistan
2022-03-20 - international - T20 - female - 1306385 - Saudi Arabia vs Kuwait
2022-03-20 - international - T20 - female - 1306384 - Qatar vs United Arab Emirates
2022-03-20 - international - ODI - female - 1243926 - New Zealand vs England
2022-03-19 - international - ODI - female - 1243925 - India vs Australia
2022-03-18 - international - ODI - female - 1243924 - West Indies vs Bangladesh
2022-03-17 - international - ODI - female - 1243923 - New Zealand vs South Africa
2022-03-16 - international - ODI - female - 1243922 - India vs England
2022-03-15 - international - ODI - female - 1243921 - West Indies vs Australia
2022-03-14 - international - ODI - female - 1243920 - Bangladesh vs Pakistan
2022-03-14 - international - ODI - female - 1243919 - England vs South Africa
2022-03-13 - international - ODI - female - 1243918 - Australia vs New Zealand
2022-03-12 - international - ODI - female - 1243917 - India vs West Indies
2022-03-11 - international - ODI - female - 1243916 - South Africa vs Pakistan
2022-03-10 - international - ODI - female - 1243915 - New Zealand vs India
2022-03-09 - international - ODI - female - 1243914 - West Indies vs England
2022-03-08 - international - ODI - female - 1243913 - Pakistan vs Australia
2022-03-07 - international - ODI - female - 1243912 - Bangladesh vs New Zealand
2022-03-06 - international - ODI - female - 1243911 - India vs Pakistan
2022-03-05 - international - ODI - female - 1243910 - Australia vs England
2022-03-05 - international - ODI - female - 1243909 - South Africa vs Bangladesh
2022-03-04 - international - ODI - female - 1243908 - West Indies vs New Zealand
2022-02-24 - international - ODI - female - 1289036 - New Zealand vs India
2022-02-22 - international - ODI - female - 1289035 - New Zealand vs India
2022-02-18 - international - ODI - female - 1289034 - India vs New Zealand
2022-02-15 - international - ODI - female - 1289033 - India vs New Zealand
2022-02-12 - international - ODI - female - 1289032 - New Zealand vs India
2022-02-09 - international - T20 - female - 1289031 - New Zealand vs India
2022-02-08 - international - ODI - female - 1263577 - England vs Australia
2022-02-06 - international - ODI - female - 1277095 - West Indies vs South Africa
2022-02-06 - international - ODI - female - 1263576 - England vs Australia
2022-02-03 - international - ODI - female - 1277094 - South Africa vs West Indies
2022-02-03 - international - ODI - female - 1263575 - Australia vs England
2022-01-31 - international - ODI - female - 1277093 - South Africa vs West Indies
2022-01-29 - club - SSM - female - 1290661 - Wellington vs Otago
2022-01-28 - international - ODI - female - 1277092 - West Indies vs South Africa
2022-01-27 - international - Test - female - 1263571 - Australia vs England
2022-01-27 - club - SSM - female - 1290660 - Otago vs Auckland
2022-01-24 - international - T20 - female - 1296036 - Sri Lanka vs Bangladesh
2022-01-24 - club - SSM - female - 1290659 - Wellington vs Northern Districts
2022-01-23 - international - T20 - female - 1296035 - Kenya vs Malaysia
2022-01-23 - international - T20 - female - 1296034 - Scotland vs Bangladesh
2022-01-23 - club - SSM - female - 1290658 - Canterbury vs Otago
2022-01-22 - international - T20 - female - 1296033 - Sri Lanka vs Malaysia
2022-01-22 - international - T20 - female - 1296032 - Scotland vs Kenya
2022-01-22 - international - T20 - female - 1263573 - England vs Australia
2022-01-22 - club - SSM - female - 1290657 - Central Districts vs Auckland
2022-01-21 - club - SSM - female - 1290656 - Canterbury vs Northern Districts
2022-01-20 - international - T20 - female - 1296031 - Kenya vs Sri Lanka
2022-01-20 - international - T20 - female - 1263572 - England vs Australia
2022-01-20 - club - SSM - female - 1290637 - Auckland vs Wellington
2022-01-19 - international - T20 - female - 1296030 - Scotland vs Malaysia
2022-01-19 - international - T20 - female - 1296029 - Bangladesh vs Kenya
2022-01-18 - international - T20 - female - 1296028 - Sri Lanka vs Scotland
2022-01-18 - international - T20 - female - 1296027 - Malaysia vs Bangladesh
2022-01-18 - club - SSM - female - 1290634 - Auckland vs Canterbury
2022-01-16 - club - SSM - female - 1290655 - Northern Districts vs Wellington
2022-01-15 - club - SSM - female - 1290654 - Auckland vs Otago
2022-01-14 - club - SSM - female - 1290653 - Northern Districts vs Central Districts
2022-01-08 - club - SSM - female - 1290652 - Central Districts vs Wellington
2022-01-07 - club - SSM - female - 1290651 - Auckland vs Canterbury
2022-01-06 - club - SSM - female - 1290650 - Wellington vs Otago
2021-12-31 - club - SSM - female - 1290649 - Central Districts vs Canterbury
2021-12-30 - club - SSM - female - 1290648 - Northern Districts vs Central Districts
2021-12-29 - club - SSM - female - 1290647 - Otago vs Auckland
2021-12-28 - club - SSM - female - 1290646 - Wellington vs Otago
2021-12-27 - club - SSM - female - 1290645 - Central Districts vs Auckland
2021-12-26 - club - SSM - female - 1290644 - Otago vs Canterbury
2021-12-24 - club - SSM - female - 1290643 - Wellington vs Auckland
2021-12-23 - club - SSM - female - 1290642 - Canterbury vs Northern Districts
2021-12-20 - club - SSM - female - 1290631 - Northern Districts vs Auckland
2021-12-19 - club - SSM - female - 1290641 - Wellington vs Canterbury
2021-12-18 - club - SSM - female - 1290640 - Central Districts vs Otago
2021-12-17 - club - SSM - female - 1290639 - Auckland vs Northern Districts
2021-12-12 - club - SSM - female - 1290638 - Northern Districts vs Otago
2021-12-10 - club - SSM - female - 1290636 - Central Districts vs Canterbury
2021-12-05 - club - SSM - female - 1290635 - Wellington vs Central Districts
2021-12-03 - club - SSM - female - 1290633 - Otago vs Northern Districts
2021-11-28 - international - T20 - female - 1286982 - Hong Kong vs Kuwait
2021-11-28 - international - T20 - female - 1286981 - Malaysia vs Bhutan
2021-11-28 - international - T20 - female - 1286980 - United Arab Emirates vs Nepal
2021-11-28 - club - SSM - female - 1290632 - Otago vs Central Districts
2021-11-27 - international - ODM - female - 1286916 - United States of America vs Thailand
2021-11-27 - international - ODI - female - 1286915 - Pakistan vs Zimbabwe
2021-11-27 - club - WBB - female - 1269113 - Perth Scorchers vs Adelaide Strikers
2021-11-26 - international - T20 - female - 1286979 - Kuwait vs United Arab Emirates
2021-11-26 - international - T20 - female - 1286978 - Hong Kong vs Bhutan
2021-11-26 - club - SSM - female - 1290630 - Wellington vs Canterbury
2021-11-25 - international - T20 - female - 1286976 - United Arab Emirates vs Bhutan
2021-11-25 - international - T20 - female - 1286975 - Kuwait vs Nepal
2021-11-25 - international - T20 - female - 1286974 - Malaysia vs Hong Kong
2021-11-25 - international - ODM - female - 1286912 - United States of America vs Zimbabwe
2021-11-25 - international - ODM - female - 1286910 - Bangladesh vs Thailand
2021-11-25 - international - ODM - female - 1286904 - Ireland vs Netherlands
2021-11-25 - club - WBB - female - 1269112 - Melbourne Renegades vs Adelaide Strikers
2021-11-24 - club - WBB - female - 1269111 - Brisbane Heat vs Adelaide Strikers
2021-11-23 - international - T20 - female - 1286973 - Bhutan vs Nepal
2021-11-23 - international - T20 - female - 1286972 - Malaysia vs Kuwait
2021-11-23 - international - T20 - female - 1286971 - United Arab Emirates vs Hong Kong
2021-11-23 - international - ODM - female - 1286908 - Bangladesh vs United States of America
2021-11-23 - international - ODM - female - 1286907 - Pakistan vs Thailand
2021-11-23 - international - ODM - female - 1286906 - Sri Lanka vs Netherlands
2021-11-22 - international - T20 - female - 1286970 - Bhutan vs Kuwait
2021-11-22 - international - T20 - female - 1286968 - United Arab Emirates vs Malaysia
2021-11-21 - international - ODM - female - 1286902 - Thailand vs Zimbabwe
2021-11-21 - international - ODI - female - 1286901 - Pakistan vs Bangladesh
2021-11-21 - club - WBB - female - 1269110 - Adelaide Strikers vs Melbourne Stars
2021-11-21 - club - WBB - female - 1269109 - Sydney Sixers vs Perth Scorchers
2021-11-20 - club - WBB - female - 1269108 - Brisbane Heat vs Melbourne Renegades
2021-11-20 - club - WBB - female - 1269107 - Hobart Hurricanes vs Sydney Thunder
2021-11-20 - club - WBB - female - 1269106 - Sydney Sixers vs Adelaide Strikers
2021-11-20 - club - WBB - female - 1269105 - Melbourne Stars vs Perth Scorchers
2021-11-19 - club - WBB - female - 1269104 - Sydney Thunder vs Brisbane Heat
2021-11-19 - club - WBB - female - 1269103 - Hobart Hurricanes vs Melbourne Renegades
2021-11-18 - international - T20 - female - 1289286 - Nepal vs Qatar
2021-11-17 - international - T20 - female - 1289285 - Nepal vs Qatar
2021-11-17 - club - WBB - female - 1269102 - Melbourne Renegades vs Sydney Thunder
2021-11-17 - club - WBB - female - 1269101 - Perth Scorchers vs Adelaide Strikers
2021-11-16 - international - T20 - female - 1289284 - Nepal vs Qatar
2021-11-15 - international - ODI - female - 1288322 - Zimbabwe vs Bangladesh
2021-11-14 - international - ODI - female - 1288211 - Pakistan vs West Indies
2021-11-14 - club - WBB - female - 1269100 - Sydney Sixers vs Sydney Thunder
2021-11-14 - club - WBB - female - 1269099 - Brisbane Heat vs Adelaide Strikers
2021-11-13 - club - WBB - female - 1269098 - Sydney Sixers vs Brisbane Heat
2021-11-13 - club - WBB - female - 1269096 - Adelaide Strikers vs Hobart Hurricanes
2021-11-11 - international - ODI - female - 1288210 - West Indies vs Pakistan
2021-11-11 - club - WBB - female - 1269095 - Perth Scorchers vs Sydney Thunder
2021-11-10 - club - WBB - female - 1269094 - Sydney Sixers vs Adelaide Strikers
2021-11-10 - club - WBB - female - 1269093 - Melbourne Stars vs Perth Scorchers
2021-11-09 - club - WBB - female - 1269092 - Adelaide Strikers vs Sydney Thunder
2021-11-09 - club - WBB - female - 1269091 - Sydney Sixers vs Brisbane Heat
2021-11-08 - international - ODI - female - 1288209 - West Indies vs Pakistan
2021-11-07 - club - WBB - female - 1269090 - Hobart Hurricanes vs Perth Scorchers
2021-11-07 - club - WBB - female - 1269089 - Melbourne Stars vs Melbourne Renegades
2021-11-07 - club - WBB - female - 1269088 - Sydney Thunder vs Brisbane Heat
2021-11-06 - club - WBB - female - 1269087 - Hobart Hurricanes vs Perth Scorchers
2021-11-06 - club - WBB - female - 1269086 - Melbourne Stars vs Adelaide Strikers
2021-11-06 - club - WBB - female - 1269085 - Melbourne Renegades vs Brisbane Heat
2021-11-03 - club - WBB - female - 1269084 - Perth Scorchers vs Melbourne Renegades
2021-11-03 - club - WBB - female - 1269083 - Sydney Sixers vs Hobart Hurricanes
2021-10-31 - club - WBB - female - 1269082 - Sydney Sixers vs Perth Scorchers
2021-10-31 - club - WBB - female - 1269081 - Brisbane Heat vs Melbourne Stars
2021-10-31 - club - WBB - female - 1269080 - Adelaide Strikers vs Melbourne Renegades
2021-10-31 - club - WBB - female - 1269079 - Sydney Thunder vs Hobart Hurricanes
2021-10-30 - club - WBB - female - 1269078 - Brisbane Heat vs Hobart Hurricanes
2021-10-30 - club - WBB - female - 1269077 - Perth Scorchers vs Adelaide Strikers
2021-10-30 - club - WBB - female - 1269076 - Sydney Thunder vs Melbourne Stars
2021-10-30 - club - WBB - female - 1269075 - Melbourne Renegades vs Sydney Sixers
2021-10-27 - club - WBB - female - 1269074 - Melbourne Stars vs Hobart Hurricanes
2021-10-27 - club - WBB - female - 1269073 - Melbourne Renegades vs Sydney Thunder
2021-10-26 - club - WBB - female - 1269072 - Hobart Hurricanes vs Brisbane Heat
2021-10-26 - club - WBB - female - 1269071 - Melbourne Stars vs Sydney Thunder
2021-10-24 - international - T20 - female - 1282935 - Canada vs United States of America
2021-10-24 - club - WBB - female - 1269070 - Perth Scorchers vs Sydney Thunder
2021-10-24 - club - WBB - female - 1269069 - Sydney Sixers vs Melbourne Renegades
2021-10-24 - club - WBB - female - 1269068 - Brisbane Heat vs Adelaide Strikers
2021-10-23 - club - WBB - female - 1269064 - Hobart Hurricanes vs Adelaide Strikers
2021-10-20 - club - WBB - female - 1269063 - Melbourne Stars vs Sydney Sixers
2021-10-20 - club - WBB - female - 1269062 - Melbourne Renegades vs Adelaide Strikers
2021-10-19 - international - T20 - female - 1282930 - Canada vs United States of America
2021-10-19 - international - T20 - female - 1282929 - Argentina vs Brazil
2021-10-19 - club - WBB - female - 1269061 - Brisbane Heat vs Perth Scorchers
2021-10-19 - club - WBB - female - 1269060 - Hobart Hurricanes vs Melbourne Stars
2021-10-17 - club - WBB - female - 1269059 - Hobart Hurricanes vs Sydney Sixers
2021-10-17 - club - WBB - female - 1269058 - Perth Scorchers vs Brisbane Heat
2021-10-16 - club - WBB - female - 1269057 - Adelaide Strikers vs Sydney Thunder
2021-10-16 - club - WBB - female - 1269056 - Hobart Hurricanes vs Melbourne Renegades
2021-10-14 - club - WBB - female - 1269055 - Melbourne Stars vs Sydney Sixers
2021-10-11 - international - ODI - female - 1281420 - Ireland vs Zimbabwe
2021-10-10 - international - T20 - female - 1263623 - Australia vs India
2021-10-09 - international - T20 - female - 1263622 - India vs Australia
2021-10-09 - international - ODI - female - 1281419 - Zimbabwe vs Ireland
2021-10-07 - international - T20 - female - 1263621 - India vs Australia
2021-10-07 - international - ODI - female - 1281418 - Ireland vs Zimbabwe
2021-10-05 - international - ODI - female - 1281417 - Ireland vs Zimbabwe
2021-09-30 - international - Test - female - 1263620 - India vs Australia
2021-09-26 - international - ODI - female - 1263619 - Australia vs India
2021-09-26 - international - ODI - female - 1260107 - England vs New Zealand
2021-09-25 - club - RHF - female - 1252293 - Northern Diamonds vs Southern Vipers
2021-09-24 - international - ODI - female - 1263618 - India vs Australia
2021-09-23 - international - ODI - female - 1260106 - New Zealand vs England
2021-09-22 - club - RHF - female - 1252292 - Central Sparks vs Northern Diamonds
2021-09-21 - international - ODI - female - 1263617 - India vs Australia
2021-09-21 - international - ODI - female - 1260105 - England vs New Zealand
2021-09-19 - international - T20 - female - 1275132 - Zimbabwe vs Namibia
2021-09-19 - international - T20 - female - 1275131 - Uganda vs Tanzania
2021-09-19 - international - ODI - female - 1273422 - West Indies vs South Africa
2021-09-19 - international - ODI - female - 1260104 - England vs New Zealand
2021-09-18 - club - RHF - female - 1252291 - Northern Diamonds vs Southern Vipers
2021-09-18 - club - RHF - female - 1252290 - Western Storm vs Sunrisers
2021-09-18 - club - RHF - female - 1252289 - Thunder vs South East Stars
2021-09-18 - club - RHF - female - 1252288 - Lightning vs Central Sparks
2021-09-17 - international - T20 - female - 1275129 - Zimbabwe vs Uganda
2021-09-16 - international - T20 - female - 1275128 - Botswana vs Tanzania
2021-09-16 - international - T20 - female - 1275127 - Zimbabwe vs Rwanda
2021-09-16 - international - T20 - female - 1275126 - Mozambique vs Eswatini
2021-09-16 - international - ODI - female - 1273421 - South Africa vs West Indies
2021-09-16 - international - ODI - female - 1260103 - England vs New Zealand
2021-09-15 - international - T20 - female - 1275113 - Cameroon vs Sierra Leone
2021-09-14 - international - T20 - female - 1275125 - Sierra Leone vs Uganda
2021-09-14 - international - T20 - female - 1275122 - Tanzania vs Eswatini
2021-09-13 - international - T20 - female - 1275118 - Tanzania vs Rwanda
2021-09-13 - international - ODI - female - 1273420 - West Indies vs South Africa
2021-09-12 - international - T20 - female - 1275116 - Rwanda vs Eswatini
2021-09-12 - club - RHF - female - 1252287 - Southern Vipers vs Sunrisers
2021-09-12 - club - RHF - female - 1252286 - Western Storm vs Lightning
2021-09-12 - club - RHF - female - 1252285 - Central Sparks vs South East Stars
2021-09-12 - club - RHF - female - 1252284 - Northern Diamonds vs Thunder
2021-09-11 - international - T20 - female - 1275115 - Uganda vs Nigeria
2021-09-11 - international - T20 - female - 1275114 - Tanzania vs Mozambique
2021-09-11 - international - T20 - female - 1275112 - Eswatini vs Zimbabwe
2021-09-10 - international - T20 - female - 1275111 - Namibia vs Nigeria
2021-09-10 - international - T20 - female - 1275110 - Botswana vs Mozambique
2021-09-10 - international - T20 - female - 1275108 - Tanzania vs Zimbabwe
2021-09-10 - international - ODI - female - 1273419 - West Indies vs South Africa
2021-09-10 - club - RHF - female - 1252283 - Thunder vs Southern Vipers
2021-09-10 - club - RHF - female - 1252282 - Sunrisers vs Central Sparks
2021-09-10 - club - RHF - female - 1252281 - South East Stars vs Lightning
2021-09-10 - club - RHF - female - 1252280 - Western Storm vs Northern Diamonds
2021-09-09 - international - T20 - female - 1275107 - Sierra Leone vs Nigeria
2021-09-09 - international - T20 - female - 1275106 - Botswana vs Eswatini
2021-09-09 - international - T20 - female - 1275104 - Mozambique vs Rwanda
2021-09-09 - international - T20 - female - 1260102 - New Zealand vs England
2021-09-07 - international - ODI - female - 1273418 - West Indies vs South Africa
2021-09-05 - club - CEC - female - 1252436 - Northern Diamonds vs South East Stars
2021-09-05 - club - CEC - female - 1252435 - Northern Diamonds vs Southern Vipers
2021-09-04 - international - T20 - female - 1273417 - South Africa vs West Indies
2021-09-04 - international - T20 - female - 1260101 - England vs New Zealand
2021-09-02 - international - T20 - female - 1273416 - South Africa vs West Indies
2021-09-01 - international - T20 - female - 1260100 - England vs New Zealand
2021-08-31 - international - T20 - female - 1273415 - South Africa vs West Indies
2021-08-30 - international - T20 - female - 1274609 - Ireland vs Netherlands
2021-08-30 - international - T20 - female - 1274606 - France vs Scotland
2021-08-30 - international - T20 - female - 1272902 - Thailand vs Zimbabwe
2021-08-30 - club - CEC - female - 1252434 - Thunder vs Northern Diamonds
2021-08-30 - club - CEC - female - 1252433 - Western Storm vs Sunrisers
2021-08-30 - club - CEC - female - 1252432 - South East Stars vs Central Sparks
2021-08-30 - club - CEC - female - 1252431 - Lightning vs Southern Vipers
2021-08-29 - international - T20 - female - 1275074 - Norway vs Sweden
2021-08-29 - international - T20 - female - 1274608 - Germany vs Scotland
2021-08-29 - international - T20 - female - 1274604 - France vs Ireland
2021-08-28 - international - T20 - female - 1272901 - Thailand vs Zimbabwe
2021-08-28 - club - CEC - female - 1252430 - Thunder vs Sunrisers
2021-08-28 - club - CEC - female - 1252429 - Northern Diamonds vs Western Storm
2021-08-28 - club - CEC - female - 1252428 - South East Stars vs Southern Vipers
2021-08-28 - club - CEC - female - 1252427 - Lightning vs Central Sparks
2021-08-27 - international - T20 - female - 1274602 - Germany vs Netherlands
2021-08-27 - international - T20 - female - 1274601 - Ireland vs Scotland
2021-08-27 - international - T20 - female - 1274600 - France vs Germany
2021-08-27 - international - T20 - female - 1272900 - Thailand vs Zimbabwe
2021-08-26 - international - T20 - female - 1274597 - France vs Netherlands
2021-08-26 - international - T20 - female - 1274596 - Ireland vs Germany
2021-08-26 - international - T20 - female - 1274595 - Netherlands vs Scotland
2021-08-25 - club - CEC - female - 1252426 - Thunder vs Western Storm
2021-08-25 - club - CEC - female - 1252425 - Northern Diamonds vs Sunrisers
2021-08-25 - club - CEC - female - 1252424 - Southern Vipers vs Central Sparks
2021-08-25 - club - CEC - female - 1252423 - South East Stars vs Lightning
2021-08-21 - club - HND - female - 1252733 - Oval Invincibles vs Southern Brave
2021-08-20 - club - HND - female - 1252732 - Oval Invincibles vs Birmingham Phoenix
2021-08-18 - club - HND - female - 1252731 - Welsh Fire vs London Spirit
2021-08-17 - club - HND - female - 1252730 - Birmingham Phoenix vs Northern Superchargers
2021-08-16 - club - HND - female - 1252729 - Southern Brave vs Oval Invincibles
2021-08-15 - club - HND - female - 1252728 - Trent Rockets vs Manchester Originals
2021-08-14 - club - HND - female - 1252727 - London Spirit vs Oval Invincibles
2021-08-13 - club - HND - female - 1252726 - Trent Rockets vs Birmingham Phoenix
2021-08-12 - club - HND - female - 1252725 - Northern Superchargers vs Manchester Originals
2021-08-11 - club - HND - female - 1252724 - Southern Brave vs Welsh Fire
2021-08-10 - club - HND - female - 1252723 - Manchester Originals vs London Spirit
2021-08-09 - club - HND - female - 1252722 - Welsh Fire vs Birmingham Phoenix
2021-08-07 - club - HND - female - 1252720 - Northern Superchargers vs Southern Brave
2021-08-06 - club - HND - female - 1252719 - Welsh Fire vs Trent Rockets
2021-08-05 - club - HND - female - 1252718 - Southern Brave vs Manchester Originals
2021-08-04 - club - HND - female - 1252717 - Birmingham Phoenix vs Oval Invincibles
2021-08-03 - club - HND - female - 1252716 - Northern Superchargers vs London Spirit
2021-08-02 - club - HND - female - 1252715 - Welsh Fire vs Oval Invincibles
2021-08-01 - club - HND - female - 1252714 - London Spirit vs Southern Brave
2021-08-01 - club - HND - female - 1252713 - Trent Rockets vs Birmingham Phoenix
2021-07-31 - club - HND - female - 1252712 - Northern Superchargers vs Oval Invincibles
2021-07-31 - club - HND - female - 1252711 - Manchester Originals vs Welsh Fire
2021-07-30 - international - T20 - female - 1268760 - Ireland vs Netherlands
2021-07-30 - club - HND - female - 1252710 - Birmingham Phoenix vs Southern Brave
2021-07-29 - international - T20 - female - 1268759 - Netherlands vs Ireland
2021-07-29 - club - HND - female - 1252709 - Trent Rockets vs London Spirit
2021-07-27 - club - HND - female - 1252707 - Welsh Fire vs Southern Brave
2021-07-26 - international - T20 - female - 1268757 - Ireland vs Netherlands
2021-07-26 - club - HND - female - 1252706 - Northern Superchargers vs Trent Rockets
2021-07-25 - club - HND - female - 1252705 - Birmingham Phoenix vs Manchester Originals
2021-07-25 - club - HND - female - 1252704 - Oval Invincibles vs London Spirit
2021-07-24 - club - HND - female - 1252703 - Welsh Fire vs Northern Superchargers
2021-07-24 - club - HND - female - 1252702 - Southern Brave vs Trent Rockets
2021-07-23 - club - HND - female - 1252701 - Birmingham Phoenix vs London Spirit
2021-07-21 - club - HND - female - 1252700 - Manchester Originals vs Oval Invincibles
2021-07-18 - international - ODI - female - 1267329 - Pakistan vs West Indies
2021-07-15 - international - ODI - female - 1267328 - West Indies vs Pakistan
2021-07-14 - international - T20 - female - 1260099 - India vs England
2021-07-12 - international - ODI - female - 1267327 - Pakistan vs West Indies
2021-07-11 - international - T20 - female - 1260098 - India vs England
2021-07-10 - club - CEC - female - 1252422 - Western Storm vs Northern Diamonds
2021-07-10 - club - CEC - female - 1252421 - South East Stars vs Southern Vipers
2021-07-10 - club - CEC - female - 1252420 - Lightning vs Central Sparks
2021-07-09 - international - T20 - female - 1268749 - Germany vs France
2021-07-09 - international - T20 - female - 1260097 - England vs India
2021-07-09 - international - ODI - female - 1267326 - Pakistan vs West Indies
2021-07-09 - club - CEC - female - 1252419 - Thunder vs Sunrisers
2021-07-08 - international - T20 - female - 1268748 - France vs Germany
2021-07-08 - international - T20 - female - 1268747 - France vs Germany
2021-07-07 - international - ODI - female - 1267325 - Pakistan vs West Indies
2021-07-04 - international - T20 - female - 1267324 - Pakistan vs West Indies
2021-07-04 - club - CEC - female - 1252418 - Thunder vs Western Storm
2021-07-03 - international - ODI - female - 1260096 - England vs India
2021-07-03 - club - CEC - female - 1252417 - Southern Vipers vs Lightning
2021-07-03 - club - CEC - female - 1252416 - Central Sparks vs South East Stars
2021-07-02 - international - T20 - female - 1267323 - West Indies vs Pakistan
2021-07-02 - club - CEC - female - 1252415 - Sunrisers vs Northern Diamonds
2021-06-30 - international - T20 - female - 1267322 - West Indies vs Pakistan
2021-06-30 - international - ODI - female - 1260095 - India vs England
2021-06-27 - international - ODI - female - 1260094 - India vs England
2021-06-26 - club - CEC - female - 1252414 - Western Storm vs Sunrisers
2021-06-26 - club - CEC - female - 1252413 - Thunder vs Northern Diamonds
2021-06-26 - club - CEC - female - 1252412 - Central Sparks vs Southern Vipers
2021-06-26 - club - CEC - female - 1252411 - Lightning vs South East Stars
2021-06-16 - international - Test - female - 1260093 - England vs India
2021-06-12 - international - T20 - female - 1265226 - Namibia vs Kenya
2021-06-12 - international - T20 - female - 1265225 - Rwanda vs Nigeria
2021-06-12 - club - RHF - female - 1252279 - Western Storm vs Southern Vipers
2021-06-12 - club - RHF - female - 1252278 - Central Sparks vs Thunder
2021-06-12 - club - RHF - female - 1252277 - Sunrisers vs Lightning
2021-06-12 - club - RHF - female - 1252276 - South East Stars vs Northern Diamonds
2021-06-11 - international - T20 - female - 1265224 - Kenya vs Rwanda
2021-06-11 - international - T20 - female - 1265223 - Namibia vs Nigeria
2021-06-10 - international - T20 - female - 1265222 - Botswana vs Nigeria
2021-06-10 - international - T20 - female - 1265221 - Kenya vs Rwanda
2021-06-09 - international - T20 - female - 1265220 - Rwanda vs Nigeria
2021-06-08 - international - T20 - female - 1265218 - Namibia vs Botswana
2021-06-07 - international - T20 - female - 1265216 - Namibia vs Rwanda
2021-06-07 - international - T20 - female - 1265215 - Botswana vs Kenya
2021-06-06 - international - T20 - female - 1265214 - Nigeria vs Namibia
2021-06-06 - club - RHF - female - 1252274 - Lightning vs Thunder
2021-06-05 - club - RHF - female - 1252275 - Central Sparks vs Southern Vipers
2021-06-05 - club - RHF - female - 1252273 - Sunrisers vs Northern Diamonds
2021-06-05 - club - RHF - female - 1252272 - Western Storm vs South East Stars
2021-05-31 - club - RHF - female - 1252271 - Thunder vs Sunrisers
2021-05-31 - club - RHF - female - 1252270 - South East Stars vs Southern Vipers
2021-05-31 - club - RHF - female - 1252269 - Central Sparks vs Western Storm
2021-05-31 - club - RHF - female - 1252268 - Northern Diamonds vs Lightning
2021-05-29 - club - RHF - female - 1252267 - Lightning vs Southern Vipers
2021-05-29 - club - RHF - female - 1252266 - South East Stars vs Sunrisers
2021-05-29 - club - RHF - female - 1252265 - Thunder vs Western Storm
2021-05-29 - club - RHF - female - 1252264 - Northern Diamonds vs Central Sparks
2021-05-27 - international - T20 - female - 1262920 - Scotland vs Ireland
2021-05-26 - international - T20 - female - 1262919 - Ireland vs Scotland
2021-05-25 - international - T20 - female - 1262917 - Ireland vs Scotland
2021-05-24 - international - T20 - female - 1262918 - Scotland vs Ireland
2021-04-10 - international - ODI - female - 1249243 - Australia vs New Zealand
2021-04-07 - international - ODI - female - 1249242 - Australia vs New Zealand
2021-04-04 - international - ODI - female - 1249241 - New Zealand vs Australia
2021-04-01 - international - T20 - female - 1249240 - Australia vs New Zealand
2021-03-30 - international - T20 - female - 1249239 - Australia vs New Zealand
2021-03-28 - international - T20 - female - 1249238 - New Zealand vs Australia
2021-03-23 - international - T20 - female - 1253274 - South Africa vs India
2021-03-21 - international - T20 - female - 1253273 - India vs South Africa
2021-03-20 - international - T20 - female - 1253272 - India vs South Africa
2021-03-17 - international - ODI - female - 1253271 - India vs South Africa
2021-03-14 - international - ODI - female - 1253270 - India vs South Africa
2021-03-12 - international - ODI - female - 1253269 - India vs South Africa
2021-03-09 - international - ODI - female - 1253268 - South Africa vs India
2021-03-07 - international - T20 - female - 1249237 - England vs New Zealand
2021-03-07 - international - ODI - female - 1253267 - India vs South Africa
2021-03-05 - international - T20 - female - 1249236 - New Zealand vs England
2021-03-03 - international - T20 - female - 1249235 - New Zealand vs England
2021-02-28 - international - ODI - female - 1249234 - England vs New Zealand
2021-02-26 - international - ODI - female - 1249233 - New Zealand vs England
2021-02-23 - international - ODI - female - 1249232 - New Zealand vs England
2021-02-13 - club - SSM - female - 1234060 - Wellington vs Canterbury
2021-02-11 - club - SSM - female - 1234059 - Wellington vs Auckland
2021-02-09 - international - ODM - female - 1249285 - Pakistan vs Zimbabwe
2021-02-07 - club - SSM - female - 1234058 - Auckland vs Wellington
2021-02-06 - club - SSM - female - 1234057 - Otago vs Northern Districts
2021-02-05 - club - SSM - female - 1234056 - Canterbury vs Central Districts
2021-02-03 - international - T20 - female - 1244848 - Pakistan vs South Africa
2021-02-01 - club - SSM - female - 1234055 - Auckland vs Otago
2021-01-31 - international - T20 - female - 1244847 - South Africa vs Pakistan
2021-01-31 - club - SSM - female - 1234054 - Wellington vs Central Districts
2021-01-30 - club - SSM - female - 1234053 - Canterbury vs Otago
2021-01-29 - international - T20 - female - 1244846 - Pakistan vs South Africa
2021-01-29 - club - SSM - female - 1234052 - Northern Districts vs Auckland
2021-01-26 - international - ODI - female - 1244845 - South Africa vs Pakistan
2021-01-25 - club - SSM - female - 1234051 - Wellington vs Canterbury
2021-01-24 - club - SSM - female - 1234050 - Wellington vs Otago
2021-01-23 - international - ODI - female - 1244844 - South Africa vs Pakistan
2021-01-23 - club - SSM - female - 1234049 - Auckland vs Central Districts
2021-01-21 - club - SSM - female - 1234048 - Northern Districts vs Canterbury
2021-01-20 - international - ODI - female - 1244843 - South Africa vs Pakistan
2021-01-18 - club - SSM - female - 1234047 - Central Districts vs Otago
2021-01-17 - club - SSM - female - 1234046 - Northern Districts vs Auckland
2021-01-16 - club - SSM - female - 1234045 - Canterbury vs Wellington
2021-01-15 - club - SSM - female - 1234044 - Canterbury vs Northern Districts
2021-01-14 - club - SSM - female - 1234043 - Otago vs Wellington
2021-01-11 - club - SSM - female - 1234042 - Auckland vs Canterbury
2021-01-10 - club - SSM - female - 1234041 - Central Districts vs Canterbury
2021-01-09 - club - SSM - female - 1234040 - Northern Districts vs Wellington
2021-01-08 - club - SSM - female - 1234039 - Central Districts vs Otago
2021-01-04 - club - SSM - female - 1234038 - Central Districts vs Northern Districts
2021-01-03 - club - SSM - female - 1234037 - Canterbury vs Auckland
2021-01-02 - club - SSM - female - 1234036 - Northern Districts vs Otago
2021-01-01 - club - SSM - female - 1234035 - Wellington vs Northern Districts
2020-12-31 - club - SSM - female - 1234034 - Auckland vs Central Districts
2020-12-30 - club - SSM - female - 1234033 - Northern Districts vs Central Districts
2020-12-29 - club - SSM - female - 1234032 - Otago vs Canterbury
2020-12-28 - club - SSM - female - 1234031 - Auckland vs Otago
2020-12-27 - club - SSM - female - 1234030 - Central Districts vs Wellington
2020-12-24 - club - SSM - female - 1234029 - Auckland vs Wellington
2020-11-29 - club - WBB - female - 1226963 - Melbourne Stars vs Sydney Thunder
2020-11-26 - club - WBB - female - 1226962 - Sydney Thunder vs Brisbane Heat
2020-11-25 - club - WBB - female - 1226961 - Perth Scorchers vs Melbourne Stars
2020-11-22 - club - WBB - female - 1226960 - Brisbane Heat vs Melbourne Renegades
2020-11-22 - club - WBB - female - 1226959 - Melbourne Stars vs Sydney Sixers
2020-11-22 - club - WBB - female - 1226958 - Adelaide Strikers vs Perth Scorchers
2020-11-22 - club - WBB - female - 1226957 - Hobart Hurricanes vs Sydney Thunder
2020-11-21 - club - WBB - female - 1226956 - Sydney Sixers vs Melbourne Renegades
2020-11-21 - club - WBB - female - 1226955 - Hobart Hurricanes vs Perth Scorchers
2020-11-21 - club - WBB - female - 1226954 - Adelaide Strikers vs Sydney Thunder
2020-11-21 - club - WBB - female - 1226953 - Melbourne Stars vs Brisbane Heat
2020-11-18 - club - WBB - female - 1226952 - Sydney Sixers vs Sydney Thunder
2020-11-18 - club - WBB - female - 1226951 - Melbourne Stars vs Hobart Hurricanes
2020-11-18 - club - WBB - female - 1226950 - Adelaide Strikers vs Melbourne Renegades
2020-11-18 - club - WBB - female - 1226949 - Perth Scorchers vs Brisbane Heat
2020-11-17 - club - WBB - female - 1226948 - Melbourne Renegades vs Sydney Thunder
2020-11-17 - club - WBB - female - 1226947 - Melbourne Stars vs Perth Scorchers
2020-11-17 - club - WBB - female - 1226946 - Sydney Sixers vs Brisbane Heat
2020-11-17 - club - WBB - female - 1226945 - Adelaide Strikers vs Hobart Hurricanes
2020-11-15 - club - WBB - female - 1226944 - Melbourne Stars vs Melbourne Renegades
2020-11-15 - club - WBB - female - 1226943 - Perth Scorchers vs Sydney Thunder
2020-11-15 - club - WBB - female - 1226942 - Hobart Hurricanes vs Brisbane Heat
2020-11-15 - club - WBB - female - 1226941 - Adelaide Strikers vs Sydney Sixers
2020-11-14 - club - WBB - female - 1226940 - Sydney Thunder vs Melbourne Stars
2020-11-14 - club - WBB - female - 1226939 - Sydney Sixers vs Hobart Hurricanes
2020-11-14 - club - WBB - female - 1226938 - Brisbane Heat vs Adelaide Strikers
2020-11-14 - club - WBB - female - 1226937 - Melbourne Renegades vs Perth Scorchers
2020-11-11 - club - WBB - female - 1226936 - Sydney Thunder vs Brisbane Heat
2020-11-11 - club - WBB - female - 1226935 - Sydney Sixers vs Perth Scorchers
2020-11-10 - club - WBB - female - 1226934 - Hobart Hurricanes vs Melbourne Renegades
2020-11-10 - club - WBB - female - 1226933 - Adelaide Strikers vs Melbourne Stars
2020-11-09 - club - WTC - female - 1235589 - Trailblazers vs Supernovas
2020-11-08 - club - WBB - female - 1226932 - Perth Scorchers vs Sydney Sixers
2020-11-08 - club - WBB - female - 1226931 - Melbourne Stars vs Brisbane Heat
2020-11-08 - club - WBB - female - 1226930 - Adelaide Strikers vs Melbourne Renegades
2020-11-08 - club - WBB - female - 1226929 - Sydney Thunder vs Hobart Hurricanes
2020-11-07 - club - WTC - female - 1235588 - Supernovas vs Trailblazers
2020-11-07 - club - WBB - female - 1226928 - Perth Scorchers vs Melbourne Stars
2020-11-07 - club - WBB - female - 1226927 - Sydney Sixers vs Hobart Hurricanes
2020-11-07 - club - WBB - female - 1226926 - Melbourne Renegades vs Sydney Thunder
2020-11-05 - club - WTC - female - 1235587 - Velocity vs Trailblazers
2020-11-04 - club - WTC - female - 1235586 - Supernovas vs Velocity
2020-11-04 - club - WBB - female - 1226924 - Sydney Sixers vs Brisbane Heat
2020-11-04 - club - WBB - female - 1226923 - Sydney Thunder vs Perth Scorchers
2020-11-03 - club - WBB - female - 1226922 - Adelaide Strikers vs Melbourne Stars
2020-11-03 - club - WBB - female - 1226921 - Melbourne Renegades vs Hobart Hurricanes
2020-11-01 - club - WBB - female - 1226920 - Hobart Hurricanes vs Melbourne Stars
2020-11-01 - club - WBB - female - 1226919 - Melbourne Renegades vs Sydney Sixers
2020-11-01 - club - WBB - female - 1226918 - Sydney Thunder vs Brisbane Heat
2020-11-01 - club - WBB - female - 1226917 - Adelaide Strikers vs Perth Scorchers
2020-10-31 - club - WBB - female - 1226915 - Brisbane Heat vs Hobart Hurricanes
2020-10-31 - club - WBB - female - 1226914 - Melbourne Renegades vs Perth Scorchers
2020-10-31 - club - WBB - female - 1226913 - Sydney Thunder vs Adelaide Strikers
2020-10-26 - club - WBB - female - 1226912 - Adelaide Strikers vs Sydney Sixers
2020-10-26 - club - WBB - female - 1226909 - Sydney Thunder vs Melbourne Stars
2020-10-25 - club - WBB - female - 1226908 - Perth Scorchers vs Brisbane Heat
2020-10-25 - club - WBB - female - 1226906 - Hobart Hurricanes vs Adelaide Strikers
2020-10-25 - club - WBB - female - 1226905 - Melbourne Stars vs Melbourne Renegades
2020-10-07 - international - ODI - female - 1223946 - Australia vs New Zealand
2020-10-05 - international - ODI - female - 1223945 - New Zealand vs Australia
2020-10-03 - international - ODI - female - 1223944 - New Zealand vs Australia
2020-09-30 - international - T20 - female - 1230859 - West Indies vs England
2020-09-30 - international - T20 - female - 1223943 - Australia vs New Zealand
2020-09-28 - international - T20 - female - 1230858 - England vs West Indies
2020-09-27 - international - T20 - female - 1223942 - New Zealand vs Australia
2020-09-27 - club - RHF - female - 1229350 - Southern Vipers vs Northern Diamonds
2020-09-26 - international - T20 - female - 1230857 - England vs West Indies
2020-09-26 - international - T20 - female - 1223941 - Australia vs New Zealand
2020-09-23 - international - T20 - female - 1230856 - England vs West Indies
2020-09-21 - international - T20 - female - 1230855 - England vs West Indies
2020-09-19 - club - RHF - female - 1229349 - Western Storm vs Sunrisers
2020-09-19 - club - RHF - female - 1229348 - Lightning vs Central Sparks
2020-09-19 - club - RHF - female - 1229347 - Thunder vs Northern Diamonds
2020-09-19 - club - RHF - female - 1229346 - South East Stars vs Southern Vipers
2020-09-13 - club - RHF - female - 1229345 - Northern Diamonds vs Central Sparks
2020-09-13 - club - RHF - female - 1229344 - Thunder vs Lightning
2020-09-13 - club - RHF - female - 1229343 - Sunrisers vs South East Stars
2020-09-13 - club - RHF - female - 1229342 - Southern Vipers vs Western Storm
2020-09-11 - club - RHF - female - 1229341 - Lightning vs Central Sparks
2020-09-11 - club - RHF - female - 1229340 - Southern Vipers vs Sunrisers
2020-09-11 - club - RHF - female - 1229339 - South East Stars vs Western Storm
2020-09-10 - club - RHF - female - 1229338 - Northern Diamonds vs Thunder
2020-09-05 - club - RHF - female - 1229337 - Southern Vipers vs South East Stars
2020-09-05 - club - RHF - female - 1229336 - Lightning vs Northern Diamonds
2020-09-05 - club - RHF - female - 1229335 - Western Storm vs Sunrisers
2020-09-05 - club - RHF - female - 1229334 - Thunder vs Central Sparks
2020-08-31 - club - RHF - female - 1229333 - Northern Diamonds vs Lightning
2020-08-31 - club - RHF - female - 1229332 - Thunder vs Central Sparks
2020-08-31 - club - RHF - female - 1229331 - South East Stars vs Sunrisers
2020-08-31 - club - RHF - female - 1229330 - Southern Vipers vs Western Storm
2020-08-29 - club - RHF - female - 1229329 - South East Stars vs Western Storm
2020-08-29 - club - RHF - female - 1229326 - Sunrisers vs Southern Vipers
2020-08-15 - international - T20 - female - 1229208 - Germany vs Austria
2020-08-14 - international - T20 - female - 1229207 - Germany vs Austria
2020-08-13 - international - T20 - female - 1229206 - Austria vs Germany
2020-08-13 - international - T20 - female - 1229205 - Germany vs Austria
2020-08-12 - international - T20 - female - 1229204 - Germany vs Austria
2020-03-08 - international - T20 - female - 1173070 - Australia vs India
2020-03-05 - international - T20 - female - 1173069 - Australia vs South Africa
2020-03-03 - international - T20 - female - 1173066 - Pakistan vs Thailand
2020-03-02 - international - T20 - female - 1173065 - Australia vs New Zealand
2020-03-02 - international - T20 - female - 1173064 - Bangladesh vs Sri Lanka
2020-03-01 - international - T20 - female - 1173063 - England vs West Indies
2020-03-01 - international - T20 - female - 1173062 - Pakistan vs South Africa
2020-02-29 - international - T20 - female - 1173061 - India vs Sri Lanka
2020-02-29 - international - T20 - female - 1173060 - Bangladesh vs New Zealand
2020-02-28 - international - T20 - female - 1173059 - England vs Pakistan
2020-02-28 - international - T20 - female - 1173058 - South Africa vs Thailand
2020-02-27 - international - T20 - female - 1173057 - Australia vs Bangladesh
2020-02-27 - international - T20 - female - 1173056 - India vs New Zealand
2020-02-26 - international - T20 - female - 1173055 - Pakistan vs West Indies
2020-02-26 - international - T20 - female - 1173054 - England vs Thailand
2020-02-24 - international - T20 - female - 1173053 - Bangladesh vs India
2020-02-24 - international - T20 - female - 1173052 - Australia vs Sri Lanka
2020-02-23 - international - T20 - female - 1173051 - England vs South Africa
2020-02-22 - international - T20 - female - 1173050 - New Zealand vs Sri Lanka
2020-02-22 - international - T20 - female - 1173049 - Thailand vs West Indies
2020-02-21 - international - T20 - female - 1173048 - Australia vs India
2020-02-12 - international - T20 - female - 1183549 - Australia vs India
2020-02-10 - international - T20 - female - 1187720 - New Zealand vs South Africa
2020-02-09 - international - T20 - female - 1187719 - New Zealand vs South Africa
2020-02-09 - international - T20 - female - 1183548 - Australia vs England
2020-02-08 - international - T20 - female - 1214766 - Oman vs Germany
2020-02-08 - international - T20 - female - 1183547 - Australia vs India
2020-02-07 - international - T20 - female - 1214765 - Oman vs Germany
2020-02-07 - international - T20 - female - 1183546 - England vs India
2020-02-06 - international - T20 - female - 1187718 - New Zealand vs South Africa
2020-02-05 - international - T20 - female - 1214764 - Oman vs Germany
2020-02-04 - international - T20 - female - 1214763 - Oman vs Germany
2020-02-02 - international - T20 - female - 1187717 - New Zealand vs South Africa
2020-02-02 - international - T20 - female - 1183545 - Australia vs India
2020-02-01 - international - T20 - female - 1183544 - Australia vs England
2020-01-31 - international - T20 - female - 1183543 - England vs India
2020-01-30 - international - ODI - female - 1187716 - New Zealand vs South Africa
2020-01-27 - international - ODI - female - 1187715 - New Zealand vs South Africa
2020-01-25 - international - ODI - female - 1187714 - New Zealand vs South Africa
2020-01-19 - club - SSM - female - 1197804 - Wellington vs Auckland
2020-01-16 - club - SSM - female - 1197803 - Otago vs Auckland
2020-01-14 - club - SSM - female - 1197802 - Otago vs Canterbury
2020-01-12 - club - SSM - female - 1197801 - Northern Districts vs Canterbury
2020-01-12 - club - SSM - female - 1197800 - Auckland vs Wellington
2020-01-11 - club - SSM - female - 1197799 - Central Districts vs Otago
2020-01-10 - club - SSM - female - 1197798 - Auckland vs Northern Districts
2020-01-09 - club - SSM - female - 1197797 - Canterbury vs Wellington
2020-01-05 - club - SSM - female - 1197796 - Northern Districts vs Canterbury
2020-01-04 - club - SSM - female - 1197795 - Central Districts vs Auckland
2020-01-03 - club - SSM - female - 1197794 - Wellington vs Northern Districts
2020-01-02 - club - SSM - female - 1197793 - Otago vs Central Districts
2019-12-20 - international - T20 - female - 1208349 - England vs Pakistan
2019-12-19 - international - T20 - female - 1208348 - England vs Pakistan
2019-12-17 - international - T20 - female - 1208347 - England vs Pakistan
2019-12-14 - international - ODI - female - 1208346 - England vs Pakistan
2019-12-12 - international - ODI - female - 1208345 - England vs Pakistan
2019-12-09 - international - ODI - female - 1208344 - England vs Pakistan
2019-12-08 - club - WBB - female - 1188440 - Adelaide Strikers vs Brisbane Heat
2019-12-07 - international - T20 - female - 1208810 - Nepal vs Maldives
2019-12-07 - club - WBB - female - 1188439 - Brisbane Heat vs Melbourne Renegades
2019-12-07 - club - WBB - female - 1188438 - Adelaide Strikers vs Perth Scorchers
2019-12-05 - international - T20 - female - 1208808 - Bangladesh vs Maldives
2019-12-04 - international - T20 - female - 1208806 - Nepal vs Bangladesh
2019-12-02 - international - T20 - female - 1208804 - Nepal vs Maldives
2019-12-01 - club - WBB - female - 1188437 - Melbourne Stars vs Brisbane Heat
2019-12-01 - club - WBB - female - 1188436 - Perth Scorchers vs Hobart Hurricanes
2019-12-01 - club - WBB - female - 1188435 - Sydney Sixers vs Adelaide Strikers
2019-12-01 - club - WBB - female - 1188434 - Melbourne Renegades vs Sydney Thunder
2019-11-30 - club - WBB - female - 1188433 - Perth Scorchers vs Hobart Hurricanes
2019-11-30 - club - WBB - female - 1188432 - Sydney Sixers vs Adelaide Strikers
2019-11-30 - club - WBB - female - 1188431 - Melbourne Stars vs Melbourne Renegades
2019-11-27 - club - WBB - female - 1188430 - Sydney Thunder vs Melbourne Stars
2019-11-27 - club - WBB - female - 1188429 - Brisbane Heat vs Melbourne Renegades
2019-11-24 - club - WBB - female - 1188428 - Perth Scorchers vs Sydney Sixers
2019-11-24 - club - WBB - female - 1188427 - Adelaide Strikers vs Sydney Thunder
2019-11-23 - club - WBB - female - 1188425 - Melbourne Renegades vs Melbourne Stars
2019-11-23 - club - WBB - female - 1188424 - Hobart Hurricanes vs Adelaide Strikers
2019-11-22 - club - WBB - female - 1188423 - Hobart Hurricanes vs Brisbane Heat
2019-11-20 - international - T20 - female - 1202256 - West Indies vs India
2019-11-20 - club - WBB - female - 1188419 - Melbourne Stars vs Perth Scorchers
2019-11-17 - international - T20 - female - 1202255 - West Indies vs India
2019-11-17 - club - WBB - female - 1188418 - Sydney Sixers vs Melbourne Renegades
2019-11-17 - club - WBB - female - 1188417 - Brisbane Heat vs Perth Scorchers
2019-11-16 - club - WBB - female - 1188416 - Melbourne Stars vs Adelaide Strikers
2019-11-16 - club - WBB - female - 1188415 - Sydney Thunder vs Brisbane Heat
2019-11-15 - club - WBB - female - 1188414 - Sydney Thunder vs Sydney Sixers
2019-11-14 - international - T20 - female - 1202254 - West Indies vs India
2019-11-13 - club - WBB - female - 1188413 - Melbourne Stars vs Brisbane Heat
2019-11-13 - club - WBB - female - 1188412 - Hobart Hurricanes vs Sydney Sixers
2019-11-12 - club - WBB - female - 1188411 - Perth Scorchers vs Sydney Thunder
2019-11-10 - international - T20 - female - 1202253 - West Indies vs India
2019-11-10 - club - WBB - female - 1188410 - Melbourne Renegades vs Hobart Hurricanes
2019-11-10 - club - WBB - female - 1188409 - Perth Scorchers vs Sydney Thunder
2019-11-10 - club - WBB - female - 1188408 - Adelaide Strikers vs Melbourne Stars
2019-11-09 - international - T20 - female - 1202252 - West Indies vs India
2019-11-09 - club - WBB - female - 1188407 - Sydney Sixers vs Brisbane Heat
2019-11-09 - club - WBB - female - 1188406 - Adelaide Strikers vs Perth Scorchers
2019-11-09 - club - WBB - female - 1188405 - Melbourne Renegades vs Hobart Hurricanes
2019-11-06 - international - ODI - female - 1202251 - West Indies vs India
2019-11-03 - international - ODI - female - 1202250 - West Indies vs India
2019-11-03 - club - WBB - female - 1188404 - Brisbane Heat vs Adelaide Strikers
2019-11-03 - club - WBB - female - 1188403 - Hobart Hurricanes vs Sydney Thunder
2019-11-02 - club - WBB - female - 1188401 - Brisbane Heat vs Adelaide Strikers
2019-11-02 - club - WBB - female - 1188399 - Perth Scorchers vs Melbourne Stars
2019-11-02 - club - WBB - female - 1188398 - Melbourne Renegades vs Sydney Sixers
2019-11-01 - international - ODI - female - 1202249 - West Indies vs India
2019-11-01 - club - WBB - female - 1188397 - Perth Scorchers vs Melbourne Renegades
2019-10-27 - club - WBB - female - 1188396 - Brisbane Heat vs Hobart Hurricanes
2019-10-27 - club - WBB - female - 1188395 - Sydney Thunder vs Melbourne Stars
2019-10-27 - club - WBB - female - 1188394 - Adelaide Strikers vs Perth Scorchers
2019-10-26 - international - T20 - female - 1204726 - Pakistan vs Bangladesh
2019-10-26 - club - WBB - female - 1188393 - Sydney Thunder vs Melbourne Renegades
2019-10-26 - club - WBB - female - 1188392 - Brisbane Heat vs Perth Scorchers
2019-10-26 - club - WBB - female - 1188391 - Sydney Sixers vs Melbourne Stars
2019-10-26 - club - WBB - female - 1188390 - Adelaide Strikers vs Hobart Hurricanes
2019-10-23 - club - WBB - female - 1188389 - Melbourne Renegades vs Perth Scorchers
2019-10-20 - club - WBB - female - 1188388 - Sydney Thunder vs Brisbane Heat
2019-10-20 - club - WBB - female - 1188387 - Melbourne Stars vs Hobart Hurricanes
2019-10-20 - club - WBB - female - 1188386 - Adelaide Strikers vs Melbourne Renegades
2019-10-19 - club - WBB - female - 1188385 - Sydney Sixers vs Brisbane Heat
2019-10-19 - club - WBB - female - 1188384 - Melbourne Stars vs Hobart Hurricanes
2019-10-19 - club - WBB - female - 1188383 - Adelaide Strikers vs Melbourne Renegades
2019-10-18 - club - WBB - female - 1188382 - Sydney Sixers vs Sydney Thunder
2019-10-14 - international - ODI - female - 1200182 - India vs South Africa
2019-10-11 - international - ODI - female - 1200181 - India vs South Africa
2019-10-09 - international - ODI - female - 1200180 - India vs South Africa
2019-10-09 - international - ODI - female - 1183515 - Australia vs Sri Lanka
2019-10-07 - international - ODI - female - 1183514 - Australia vs Sri Lanka
2019-10-05 - international - ODI - female - 1183513 - Australia vs Sri Lanka
2019-10-04 - international - T20 - female - 1198482 - India vs South Africa
2019-10-03 - international - T20 - female - 1202366 - India vs South Africa
2019-10-02 - international - T20 - female - 1183512 - Australia vs Sri Lanka
2019-10-01 - international - T20 - female - 1198481 - India vs South Africa
2019-09-30 - international - T20 - female - 1183511 - Australia vs Sri Lanka
2019-09-29 - international - T20 - female - 1183510 - Australia vs Sri Lanka
2019-09-24 - international - T20 - female - 1198478 - India vs South Africa
2019-09-22 - international - T20 - female - 1197253 - China vs Hong Kong
2019-09-20 - international - T20 - female - 1197249 - South Korea vs China
2019-09-20 - international - T20 - female - 1197248 - Hong Kong vs Japan
2019-09-19 - international - T20 - female - 1197247 - China vs Hong Kong
2019-09-19 - international - T20 - female - 1197246 - South Korea vs Japan
2019-09-18 - international - T20 - female - 1198477 - West Indies vs Australia
2019-09-16 - international - T20 - female - 1198476 - West Indies vs Australia
2019-09-14 - international - T20 - female - 1198475 - West Indies vs Australia
2019-09-11 - international - ODI - female - 1198474 - West Indies vs Australia
2019-09-07 - international - T20 - female - 1197066 - Scotland vs Netherlands
2019-09-07 - international - T20 - female - 1197065 - Bangladesh vs Thailand
2019-09-07 - international - T20 - female - 1197064 - Namibia vs United States of America
2019-09-07 - international - T20 - female - 1197063 - Ireland vs Papua New Guinea
2019-09-07 - international - T20 - female - 1196033 - Rwanda vs Nigeria
2019-09-05 - international - T20 - female - 1197062 - Scotland vs Namibia
2019-09-05 - international - T20 - female - 1197061 - Papua New Guinea vs Thailand
2019-09-05 - international - T20 - female - 1197059 - Bangladesh vs Ireland
2019-09-05 - international - ODI - female - 1198472 - Australia vs West Indies
2019-09-03 - international - T20 - female - 1197058 - Papua New Guinea vs United States of America
2019-09-03 - international - T20 - female - 1197057 - Scotland vs Bangladesh
2019-09-03 - international - T20 - female - 1197056 - Namibia vs Netherlands
2019-09-03 - international - T20 - female - 1197055 - Ireland vs Thailand
2019-09-02 - international - T20 - female - 1197047 - Bangladesh vs Papua New Guinea
2019-09-01 - international - T20 - female - 1197054 - Bangladesh vs United States of America
2019-09-01 - international - T20 - female - 1197053 - Ireland vs Netherlands
2019-09-01 - international - T20 - female - 1197052 - Scotland vs Papua New Guinea
2019-09-01 - international - T20 - female - 1197051 - Namibia vs Thailand
2019-09-01 - club - WSL - female - 1167300 - Southern Vipers vs Western Storm
2019-09-01 - club - WSL - female - 1167298 - Loughborough Lightning vs Southern Vipers
2019-08-31 - international - T20 - female - 1197049 - Scotland vs United States of America
2019-08-30 - international - T20 - female - 1198219 - Singapore vs Malaysia
2019-08-29 - international - T20 - female - 1198218 - Singapore vs Malaysia
2019-08-28 - international - T20 - female - 1198217 - Singapore vs Malaysia
2019-08-28 - club - WSL - female - 1167297 - Loughborough Lightning vs Southern Vipers
2019-08-28 - club - WSL - female - 1167296 - Yorkshire Diamonds vs Western Storm
2019-08-28 - club - WSL - female - 1167295 - Surrey Stars vs Lancashire Thunder
2019-08-25 - club - WSL - female - 1167294 - Western Storm vs Surrey Stars
2019-08-25 - club - WSL - female - 1167293 - Southern Vipers vs Yorkshire Diamonds
2019-08-25 - club - WSL - female - 1167292 - Lancashire Thunder vs Loughborough Lightning
2019-08-23 - club - WSL - female - 1167291 - Surrey Stars vs Loughborough Lightning
2019-08-23 - club - WSL - female - 1167290 - Lancashire Thunder vs Yorkshire Diamonds
2019-08-21 - club - WSL - female - 1167289 - Western Storm vs Surrey Stars
2019-08-21 - club - WSL - female - 1167288 - Southern Vipers vs Yorkshire Diamonds
2019-08-20 - club - WSL - female - 1167287 - Loughborough Lightning vs Lancashire Thunder
2019-08-20 - club - WSL - female - 1167286 - Western Storm vs Southern Vipers
2019-08-20 - club - WSL - female - 1167285 - Surrey Stars vs Yorkshire Diamonds
2019-08-18 - club - WSL - female - 1167284 - Yorkshire Diamonds vs Loughborough Lightning
2019-08-18 - club - WSL - female - 1167283 - Southern Vipers vs Surrey Stars
2019-08-18 - club - WSL - female - 1167282 - Lancashire Thunder vs Western Storm
2019-08-15 - club - WSL - female - 1167281 - Yorkshire Diamonds vs Western Storm
2019-08-15 - club - WSL - female - 1167280 - Lancashire Thunder vs Southern Vipers
2019-08-15 - club - WSL - female - 1167279 - Surrey Stars vs Loughborough Lightning
2019-08-14 - international - T20 - female - 1190755 - Netherlands vs Thailand
2019-08-14 - international - T20 - female - 1190754 - Ireland vs Scotland
2019-08-13 - international - T20 - female - 1190753 - Netherlands vs Scotland
2019-08-13 - international - T20 - female - 1190752 - Ireland vs Thailand
2019-08-13 - club - WSL - female - 1167278 - Western Storm vs Loughborough Lightning
2019-08-13 - club - WSL - female - 1167277 - Yorkshire Diamonds vs Lancashire Thunder
2019-08-12 - international - T20 - female - 1190751 - Netherlands vs Ireland
2019-08-12 - international - T20 - female - 1190750 - Scotland vs Thailand
2019-08-11 - club - WSL - female - 1167275 - Southern Vipers vs Western Storm
2019-08-11 - club - WSL - female - 1167274 - Yorkshire Diamonds vs Loughborough Lightning
2019-08-10 - international - T20 - female - 1190749 - Ireland vs Scotland
2019-08-10 - club - WSL - female - 1167273 - Lancashire Thunder vs Western Storm
2019-08-09 - international - T20 - female - 1190747 - Ireland vs Thailand
2019-08-09 - international - T20 - female - 1190746 - Netherlands vs Scotland
2019-08-08 - international - T20 - female - 1190744 - Netherlands vs Ireland
2019-08-08 - club - WSL - female - 1167272 - Lancashire Thunder vs Surrey Stars
2019-08-08 - club - WSL - female - 1167271 - Loughborough Lightning vs Southern Vipers
2019-08-06 - club - WSL - female - 1167270 - Surrey Stars vs Yorkshire Diamonds
2019-08-06 - club - WSL - female - 1167269 - Loughborough Lightning vs Western Storm
2019-08-06 - club - WSL - female - 1167268 - Southern Vipers vs Lancashire Thunder
2019-07-31 - international - T20 - female - 1168028 - England vs Australia
2019-07-28 - international - T20 - female - 1168027 - England vs Australia
2019-07-26 - international - T20 - female - 1168026 - England vs Australia
2019-07-18 - international - Test - female - 1168025 - England vs Australia
2019-07-07 - international - ODI - female - 1168024 - England vs Australia
2019-07-04 - international - ODI - female - 1168023 - England vs Australia
2019-07-02 - international - ODI - female - 1168022 - England vs Australia
2019-06-29 - international - T20 - female - 1190608 - Germany vs Scotland
2019-06-27 - international - T20 - female - 1190607 - Netherlands vs Scotland
2019-06-27 - international - T20 - female - 1190606 - Germany vs Netherlands
2019-06-26 - international - T20 - female - 1190605 - Netherlands vs Scotland
2019-06-21 - international - T20 - female - 1168020 - England vs West Indies
2019-06-19 - international - T20 - female - 1188784 - Rwanda vs Uganda
2019-06-18 - international - T20 - female - 1188786 - Tanzania vs Uganda
2019-06-18 - international - T20 - female - 1188785 - Rwanda vs Mali
2019-06-13 - international - ODI - female - 1168018 - England vs West Indies
2019-06-09 - international - ODI - female - 1168017 - England vs West Indies
2019-06-06 - international - ODI - female - 1168016 - England vs West Indies
2019-05-29 - international - T20 - female - 1185156 - Ireland vs West Indies
2019-05-28 - international - T20 - female - 1185155 - Ireland vs West Indies
2019-05-26 - international - T20 - female - 1185154 - Ireland vs West Indies
2019-05-23 - international - T20 - female - 1177022 - South Africa vs Pakistan
2019-05-22 - international - T20 - female - 1177021 - South Africa vs Pakistan
2019-05-19 - international - T20 - female - 1183857 - United States of America vs Canada
2019-05-19 - international - T20 - female - 1177020 - South Africa vs Pakistan
2019-05-18 - international - T20 - female - 1183856 - United States of America vs Canada
2019-05-18 - international - T20 - female - 1177019 - South Africa vs Pakistan
2019-05-15 - international - T20 - female - 1177018 - South Africa vs Pakistan
2019-05-12 - international - T20 - female - 1182658 - Zimbabwe vs Namibia
2019-05-12 - international - ODI - female - 1177017 - South Africa vs Pakistan
2019-05-11 - international - T20 - female - 1182657 - Rwanda vs Tanzania
2019-05-11 - international - T20 - female - 1182656 - Zimbabwe vs Nigeria
2019-05-11 - club - WTC - female - 1181896 - Velocity vs Supernovas
2019-05-10 - international - T20 - female - 1182918 - Papua New Guinea vs Samoa
2019-05-10 - international - T20 - female - 1182917 - Vanuatu vs Japan
2019-05-10 - international - T20 - female - 1182916 - Fiji vs Indonesia
2019-05-09 - international - T20 - female - 1182914 - Japan vs Papua New Guinea
2019-05-09 - international - T20 - female - 1182913 - Fiji vs Japan
2019-05-09 - international - T20 - female - 1182912 - Vanuatu vs Samoa
2019-05-09 - international - T20 - female - 1182654 - Zimbabwe vs Rwanda
2019-05-09 - international - ODI - female - 1177016 - South Africa vs Pakistan
2019-05-09 - club - WTC - female - 1181895 - Supernovas vs Velocity
2019-05-08 - international - T20 - female - 1182653 - Namibia vs Sierra Leone
2019-05-08 - international - T20 - female - 1182652 - Kenya vs Uganda
2019-05-08 - international - T20 - female - 1182650 - Mozambique vs Rwanda
2019-05-08 - club - WTC - female - 1181894 - Trailblazers vs Velocity
2019-05-07 - international - T20 - female - 1182909 - Fiji vs Papua New Guinea
2019-05-06 - international - T20 - female - 1182906 - Indonesia vs Papua New Guinea
2019-05-06 - international - T20 - female - 1182905 - Indonesia vs Japan
2019-05-06 - international - T20 - female - 1182904 - Vanuatu vs Papua New Guinea
2019-05-06 - international - T20 - female - 1182649 - Zimbabwe vs Tanzania
2019-05-06 - international - T20 - female - 1182648 - Namibia vs Uganda
2019-05-06 - international - T20 - female - 1182646 - Mozambique vs Nigeria
2019-05-06 - international - ODI - female - 1177015 - South Africa vs Pakistan
2019-05-06 - club - WTC - female - 1181893 - Trailblazers vs Supernovas
2019-05-05 - international - T20 - female - 1182644 - Sierra Leone vs Uganda
2019-05-05 - international - T20 - female - 1182642 - Zimbabwe vs Mozambique
2019-04-03 - international - T20 - female - 1179018 - Namibia vs Botswana
2019-04-03 - international - T20 - female - 1179017 - Namibia vs Botswana
2019-04-03 - club - BLZ - female - wi_201716 - Guyana vs Barbados
2019-04-02 - international - T20 - female - 1179611 - Namibia vs Botswana
2019-04-02 - international - T20 - female - 1179610 - Namibia vs Botswana
2019-04-02 - club - BLZ - female - wi_201713 - Guyana vs Windward Islands
2019-04-01 - international - T20 - female - 1179016 - Namibia vs Botswana
2019-03-29 - club - BLZ - female - wi_201707 - Barbados vs Jamaica
2019-03-29 - club - BLZ - female - wi_201706 - Trinidad and Tobago vs Windward Islands
2019-03-28 - international - T20 - female - 1176437 - Sri Lanka vs England
2019-03-26 - international - T20 - female - 1176436 - Sri Lanka vs England
2019-03-24 - international - T20 - female - 1176435 - Sri Lanka vs England
2019-03-21 - international - ODI - female - 1176434 - Sri Lanka vs England
2019-03-18 - international - ODI - female - 1176433 - Sri Lanka vs England
2019-03-16 - international - ODI - female - 1176432 - Sri Lanka vs England
2019-03-09 - international - T20 - female - 1172165 - India vs England
2019-03-07 - international - T20 - female - 1172164 - India vs England
2019-03-04 - international - T20 - female - 1172163 - India vs England
2019-03-03 - international - ODI - female - 1144984 - Australia vs New Zealand
2019-02-28 - international - ODI - female - 1172162 - India vs England
2019-02-27 - international - T20 - female - 1172930 - Thailand vs United Arab Emirates
2019-02-27 - international - T20 - female - 1172929 - Kuwait vs Nepal
2019-02-25 - international - T20 - female - 1172927 - Hong Kong vs Kuwait
2019-02-25 - international - T20 - female - 1172926 - China vs Nepal
2019-02-25 - international - T20 - female - 1172925 - Thailand vs Malaysia
2019-02-25 - international - ODI - female - 1172161 - India vs England
2019-02-24 - international - T20 - female - 1172924 - Hong Kong vs Nepal
2019-02-24 - international - T20 - female - 1172923 - Thailand vs Kuwait
2019-02-24 - international - T20 - female - 1172922 - China vs United Arab Emirates
2019-02-24 - international - ODI - female - 1144983 - Australia vs New Zealand
2019-02-22 - international - T20 - female - 1172921 - China vs Malaysia
2019-02-22 - international - T20 - female - 1172920 - Thailand vs Hong Kong
2019-02-22 - international - T20 - female - 1172919 - Nepal vs United Arab Emirates
2019-02-22 - international - ODI - female - 1172160 - India vs England
2019-02-22 - international - ODI - female - 1144982 - Australia vs New Zealand
2019-02-21 - international - T20 - female - 1172918 - China vs Kuwait
2019-02-21 - international - T20 - female - 1172917 - Thailand vs Nepal
2019-02-21 - international - T20 - female - 1172916 - Malaysia vs United Arab Emirates
2019-02-19 - international - T20 - female - 1172915 - Kuwait vs United Arab Emirates
2019-02-19 - international - T20 - female - 1172914 - China vs Hong Kong
2019-02-19 - international - T20 - female - 1172913 - Malaysia vs Nepal
2019-02-18 - international - T20 - female - 1172912 - Hong Kong vs United Arab Emirates
2019-02-18 - international - T20 - female - 1172911 - Kuwait vs Malaysia
2019-02-18 - international - T20 - female - 1172910 - Thailand vs China
2019-02-17 - international - ODI - female - 1168166 - South Africa vs Sri Lanka
2019-02-14 - international - ODI - female - 1168165 - South Africa vs Sri Lanka
2019-02-11 - international - ODI - female - 1168164 - South Africa vs Sri Lanka
2019-02-10 - international - T20 - female - 1153860 - New Zealand vs India
2019-02-09 - international - ODI - female - 1172211 - Pakistan vs West Indies
2019-02-08 - international - T20 - female - 1153859 - New Zealand vs India
2019-02-07 - international - ODI - female - 1172210 - Pakistan vs West Indies
2019-02-06 - international - T20 - female - 1168162 - South Africa vs Sri Lanka
2019-02-06 - international - T20 - female - 1153858 - New Zealand vs India
2019-02-03 - international - T20 - female - 1172471 - Pakistan vs West Indies
2019-02-01 - international - T20 - female - 1172470 - Pakistan vs West Indies
2019-02-01 - international - T20 - female - 1168160 - South Africa vs Sri Lanka
2019-02-01 - international - ODI - female - 1153857 - New Zealand vs India
2019-01-31 - international - T20 - female - 1172469 - Pakistan vs West Indies
2019-01-29 - international - ODI - female - 1153856 - New Zealand vs India
2019-01-26 - club - WBB - female - 1152783 - Sydney Sixers vs Brisbane Heat
2019-01-24 - international - ODI - female - 1153855 - New Zealand vs India
2019-01-19 - club - WBB - female - 1152782 - Sydney Sixers vs Melbourne Renegades
2019-01-19 - club - WBB - female - 1152781 - Sydney Thunder vs Brisbane Heat
2019-01-14 - club - WBB - female - 1152780 - Melbourne Stars vs Sydney Sixers
2019-01-13 - club - WBB - female - 1152779 - Melbourne Renegades vs Sydney Sixers
2019-01-13 - club - WBB - female - 1152778 - Perth Scorchers vs Adelaide Strikers
2019-01-12 - club - WBB - female - 1152777 - Brisbane Heat vs Sydney Thunder
2019-01-12 - club - WBB - female - 1152776 - Melbourne Renegades vs Hobart Hurricanes
2019-01-12 - club - WBB - female - 1152775 - Adelaide Strikers vs Perth Scorchers
2019-01-10 - club - WBB - female - 1152774 - Brisbane Heat vs Melbourne Stars
2019-01-09 - club - WBB - female - 1152773 - Adelaide Strikers vs Hobart Hurricanes
2019-01-08 - club - WBB - female - 1152772 - Adelaide Strikers vs Hobart Hurricanes
2019-01-08 - club - WBB - female - 1152771 - Sydney Thunder vs Melbourne Renegades
2019-01-06 - club - WBB - female - 1152770 - Brisbane Heat vs Melbourne Renegades
2019-01-06 - club - WBB - female - 1152769 - Sydney Thunder vs Melbourne Stars
2019-01-05 - club - WBB - female - 1152767 - Brisbane Heat vs Adelaide Strikers
2019-01-05 - club - WBB - female - 1152766 - Sydney Thunder vs Melbourne Stars
2019-01-03 - club - WBB - female - 1152765 - Melbourne Renegades vs Hobart Hurricanes
2019-01-02 - club - WBB - female - 1152764 - Sydney Thunder vs Sydney Sixers
2019-01-01 - club - WBB - female - 1152763 - Melbourne Stars vs Melbourne Renegades
2018-12-31 - club - WBB - female - 1152762 - Adelaide Strikers vs Sydney Sixers
2018-12-31 - club - WBB - female - 1152758 - Hobart Hurricanes vs Brisbane Heat
2018-12-30 - club - WBB - female - 1152761 - Hobart Hurricanes vs Brisbane Heat
2018-12-30 - club - WBB - female - 1152760 - Perth Scorchers vs Sydney Thunder
2018-12-29 - club - WBB - female - 1152759 - Melbourne Renegades vs Melbourne Stars
2018-12-29 - club - WBB - female - 1152757 - Perth Scorchers vs Sydney Thunder
2018-12-28 - club - WBB - female - 1152756 - Sydney Sixers vs Adelaide Strikers
2018-12-27 - club - WBB - female - 1152755 - Sydney Sixers vs Melbourne Renegades
2018-12-26 - club - WBB - female - 1152754 - Perth Scorchers vs Brisbane Heat
2018-12-24 - club - WBB - female - 1152753 - Sydney Thunder vs Hobart Hurricanes
2018-12-23 - club - WBB - female - 1152752 - Perth Scorchers vs Melbourne Renegades
2018-12-23 - club - WBB - female - 1152751 - Sydney Sixers vs Brisbane Heat
2018-12-23 - club - WBB - female - 1152750 - Adelaide Strikers vs Melbourne Stars
2018-12-22 - club - WBB - female - 1152749 - Perth Scorchers vs Melbourne Renegades
2018-12-22 - club - WBB - female - 1152748 - Sydney Sixers vs Brisbane Heat
2018-12-21 - club - WBB - female - 1152747 - Melbourne Stars vs Adelaide Strikers
2018-12-21 - club - WBB - female - 1152746 - Sydney Thunder vs Hobart Hurricanes
2018-12-19 - club - WBB - female - 1152745 - Brisbane Heat vs Melbourne Stars
2018-12-18 - club - WBB - female - 1152744 - Hobart Hurricanes vs Perth Scorchers
2018-12-16 - club - WBB - female - 1152743 - Melbourne Renegades vs Brisbane Heat
2018-12-16 - club - WBB - female - 1152742 - Sydney Sixers vs Hobart Hurricanes
2018-12-16 - club - WBB - female - 1152741 - Sydney Thunder vs Adelaide Strikers
2018-12-16 - club - WBB - female - 1152740 - Melbourne Stars vs Perth Scorchers
2018-12-15 - club - WBB - female - 1152739 - Hobart Hurricanes vs Sydney Sixers
2018-12-15 - club - WBB - female - 1152738 - Adelaide Strikers vs Sydney Thunder
2018-12-15 - club - WBB - female - 1152737 - Melbourne Stars vs Perth Scorchers
2018-12-09 - club - WBB - female - 1152736 - Sydney Thunder vs Brisbane Heat
2018-12-09 - club - WBB - female - 1152735 - Adelaide Strikers vs Melbourne Renegades
2018-12-09 - club - WBB - female - 1152734 - Hobart Hurricanes vs Melbourne Stars
2018-12-08 - club - WBB - female - 1152733 - Sydney Sixers vs Sydney Thunder
2018-12-08 - club - WBB - female - 1152732 - Brisbane Heat vs Perth Scorchers
2018-12-08 - club - WBB - female - 1152731 - Melbourne Renegades vs Adelaide Strikers
2018-12-08 - club - WBB - female - 1152730 - Hobart Hurricanes vs Melbourne Stars
2018-12-07 - club - WBB - female - 1152729 - Sydney Sixers vs Perth Scorchers
2018-12-02 - club - WBB - female - 1152728 - Melbourne Renegades vs Sydney Thunder
2018-12-02 - club - WBB - female - 1152727 - Adelaide Strikers vs Brisbane Heat
2018-12-01 - club - WBB - female - 1152726 - Sydney Sixers vs Melbourne Stars
2018-12-01 - club - WBB - female - 1152725 - Perth Scorchers vs Hobart Hurricanes
2018-11-24 - international - T20 - female - 1150555 - England vs Australia
2018-11-22 - international - T20 - female - 1150554 - India vs England
2018-11-22 - international - T20 - female - 1150553 - Australia vs West Indies
2018-11-18 - international - T20 - female - 1150552 - South Africa vs Bangladesh
2018-11-18 - international - T20 - female - 1150551 - England vs West Indies
2018-11-17 - international - T20 - female - 1150550 - Ireland vs New Zealand
2018-11-17 - international - T20 - female - 1150549 - India vs Australia
2018-11-16 - international - T20 - female - 1150548 - West Indies vs Sri Lanka
2018-11-16 - international - T20 - female - 1150547 - South Africa vs England
2018-11-15 - international - T20 - female - 1150546 - New Zealand vs Pakistan
2018-11-15 - international - T20 - female - 1150545 - India vs Ireland
2018-11-14 - international - T20 - female - 1150544 - West Indies vs South Africa
2018-11-14 - international - T20 - female - 1150543 - Sri Lanka vs Bangladesh
2018-11-13 - international - T20 - female - 1150542 - Australia vs New Zealand
2018-11-13 - international - T20 - female - 1150541 - Pakistan vs Ireland
2018-11-12 - international - T20 - female - 1150540 - Sri Lanka vs South Africa
2018-11-12 - international - T20 - female - 1150539 - Bangladesh vs England
2018-11-11 - international - T20 - female - 1150538 - Ireland vs Australia
2018-11-11 - international - T20 - female - 1150537 - Pakistan vs India
2018-11-09 - international - T20 - female - 1150535 - West Indies vs Bangladesh
2018-11-09 - international - T20 - female - 1150534 - Australia vs Pakistan
2018-11-09 - international - T20 - female - 1150533 - India vs New Zealand
2018-10-29 - international - T20 - female - 1161233 - Pakistan vs Australia
2018-10-27 - international - T20 - female - 1161232 - Pakistan vs Australia
2018-10-25 - international - T20 - female - 1161231 - Australia vs Pakistan
2018-10-22 - international - ODI - female - 1161230 - Australia vs Pakistan
2018-10-20 - international - ODI - female - 1161229 - Australia vs Pakistan
2018-10-18 - international - ODI - female - 1161228 - Pakistan vs Australia
2018-10-06 - international - T20 - female - 1156219 - West Indies vs South Africa
2018-10-05 - international - T20 - female - 1144980 - New Zealand vs Australia
2018-10-04 - international - T20 - female - 1156218 - West Indies vs South Africa
2018-10-01 - international - T20 - female - 1144979 - New Zealand vs Australia
2018-09-29 - international - T20 - female - 1144978 - New Zealand vs Australia
2018-09-28 - international - T20 - female - 1156216 - South Africa vs West Indies
2018-09-25 - international - T20 - female - 1157713 - India vs Sri Lanka
2018-09-24 - international - T20 - female - 1157712 - Sri Lanka vs India
2018-09-22 - international - T20 - female - 1157711 - Sri Lanka vs India
2018-09-22 - international - ODI - female - 1156214 - West Indies vs South Africa
2018-09-21 - international - T20 - female - 1157710 - Sri Lanka vs India
2018-09-16 - international - ODI - female - 1157708 - India vs Sri Lanka
2018-09-16 - international - ODI - female - 1156212 - South Africa vs West Indies
2018-09-13 - international - ODI - female - 1157707 - India vs Sri Lanka
2018-09-11 - international - ODI - female - 1157706 - Sri Lanka vs India
2018-08-27 - club - WSL - female - 1127424 - Surrey Stars vs Loughborough Lightning
2018-08-27 - club - WSL - female - 1127423 - Surrey Stars vs Western Storm
2018-08-25 - international - T20 - female - 1158361 - Sierra Leone vs Namibia
2018-08-25 - international - T20 - female - 1158359 - Lesotho vs Malawi
2018-08-24 - international - T20 - female - 1158358 - Botswana vs Namibia
2018-08-24 - international - T20 - female - 1158356 - Sierra Leone vs Lesotho
2018-08-23 - international - T20 - female - 1158355 - Sierra Leone vs Malawi
2018-08-23 - international - T20 - female - 1158354 - Namibia vs Lesotho
2018-08-23 - international - T20 - female - 1158353 - Mozambique vs Namibia
2018-08-23 - international - T20 - female - 1158352 - Botswana vs Sierra Leone
2018-08-21 - international - T20 - female - 1158350 - Mozambique vs Botswana
2018-08-21 - international - T20 - female - 1158349 - Mozambique vs Lesotho
2018-08-21 - international - T20 - female - 1158348 - Sierra Leone vs Namibia
2018-08-20 - international - T20 - female - 1158345 - Malawi vs Namibia
2018-08-20 - international - T20 - female - 1158344 - Botswana vs Lesotho
2018-08-18 - club - WSL - female - 1127422 - Western Storm vs Surrey Stars
2018-08-18 - club - WSL - female - 1127421 - Yorkshire Diamonds vs Loughborough Lightning
2018-08-18 - club - WSL - female - 1127420 - Lancashire Thunder vs Southern Vipers
2018-08-15 - club - WSL - female - 1127419 - Western Storm vs Loughborough Lightning
2018-08-14 - club - WSL - female - 1127418 - Lancashire Thunder vs Yorkshire Diamonds
2018-08-14 - club - WSL - female - 1127417 - Southern Vipers vs Surrey Stars
2018-08-12 - club - WSL - female - 1127416 - Surrey Stars vs Yorkshire Diamonds
2018-08-11 - club - WSL - female - 1127415 - Southern Vipers vs Western Storm
2018-08-11 - club - WSL - female - 1127414 - Lancashire Thunder vs Loughborough Lightning
2018-08-09 - club - WSL - female - 1127413 - Western Storm vs Lancashire Thunder
2018-08-09 - club - WSL - female - 1127412 - Loughborough Lightning vs Surrey Stars
2018-08-08 - club - WSL - female - 1127411 - Southern Vipers vs Yorkshire Diamonds
2018-08-07 - club - WSL - female - 1127410 - Surrey Stars vs Lancashire Thunder
2018-08-05 - club - WSL - female - 1127409 - Yorkshire Diamonds vs Western Storm
2018-08-04 - club - WSL - female - 1127408 - Southern Vipers vs Loughborough Lightning
2018-08-03 - club - WSL - female - 1127407 - Lancashire Thunder vs Western Storm
2018-08-02 - club - WSL - female - 1127406 - Yorkshire Diamonds vs Southern Vipers
2018-08-02 - club - WSL - female - 1127405 - Surrey Stars vs Loughborough Lightning
2018-07-31 - club - WSL - female - 1127404 - Loughborough Lightning vs Yorkshire Diamonds
2018-07-31 - club - WSL - female - 1127403 - Surrey Stars vs Lancashire Thunder
2018-07-31 - club - WSL - female - 1127402 - Southern Vipers vs Western Storm
2018-07-29 - club - WSL - female - 1127401 - Western Storm vs Loughborough Lightning
2018-07-29 - club - WSL - female - 1127400 - Lancashire Thunder vs Southern Vipers
2018-07-27 - club - WSL - female - 1127398 - Lancashire Thunder vs Yorkshire Diamonds
2018-07-26 - club - WSL - female - 1127397 - Western Storm vs Surrey Stars
2018-07-25 - club - WSL - female - 1127396 - Southern Vipers vs Loughborough Lightning
2018-07-22 - club - WSL - female - 1127395 - Yorkshire Diamonds vs Western Storm
2018-07-22 - club - WSL - female - 1127394 - Lancashire Thunder vs Loughborough Lightning
2018-07-22 - club - WSL - female - 1127393 - Surrey Stars vs Southern Vipers
2018-07-14 - international - T20 - female - 1147736 - Bangladesh vs Ireland
2018-07-14 - international - T20 - female - 1147735 - Thailand vs Uganda
2018-07-14 - international - T20 - female - 1147734 - Papua New Guinea vs Scotland
2018-07-14 - international - T20 - female - 1147733 - Netherlands vs United Arab Emirates
2018-07-13 - international - ODI - female - 1126729 - England vs New Zealand
2018-07-12 - international - T20 - female - 1147732 - United Arab Emirates vs Thailand
2018-07-12 - international - T20 - female - 1147731 - Bangladesh vs Scotland
2018-07-12 - international - T20 - female - 1147730 - Netherlands vs Uganda
2018-07-12 - international - T20 - female - 1147729 - Ireland vs Papua New Guinea
2018-07-10 - international - T20 - female - 1147728 - Papua New Guinea vs Netherlands
2018-07-10 - international - T20 - female - 1147727 - United Arab Emirates vs Bangladesh
2018-07-10 - international - T20 - female - 1147726 - Uganda vs Ireland
2018-07-10 - international - T20 - female - 1147725 - Scotland vs Thailand
2018-07-10 - international - ODI - female - 1126728 - England vs New Zealand
2018-07-08 - international - T20 - female - 1147724 - United Arab Emirates vs Papua New Guinea
2018-07-08 - international - T20 - female - 1147723 - Netherlands vs Bangladesh
2018-07-08 - international - T20 - female - 1147722 - Scotland vs Ireland
2018-07-07 - international - T20 - female - 1147720 - Papua New Guinea vs Bangladesh
2018-07-07 - international - T20 - female - 1147719 - Netherlands vs United Arab Emirates
2018-07-07 - international - T20 - female - 1147718 - Uganda vs Scotland
2018-07-07 - international - T20 - female - 1147717 - Thailand vs Ireland
2018-07-07 - international - ODI - female - 1126727 - England vs New Zealand
2018-07-01 - international - T20 - female - 1145896 - Bangladesh vs Ireland
2018-07-01 - international - T20 - female - 1126726 - New Zealand vs England
2018-06-29 - international - T20 - female - 1145895 - Ireland vs Bangladesh
2018-06-28 - international - T20 - female - 1145894 - Ireland vs Bangladesh
2018-06-28 - international - T20 - female - 1126725 - New Zealand vs England
2018-06-28 - international - T20 - female - 1126724 - South Africa vs New Zealand
2018-06-23 - international - T20 - female - 1126723 - England vs New Zealand
2018-06-23 - international - T20 - female - 1126722 - England vs South Africa
2018-06-20 - international - T20 - female - 1126721 - England vs South Africa
2018-06-20 - international - T20 - female - 1126720 - New Zealand vs South Africa
2018-06-15 - international - ODI - female - 1126719 - South Africa vs England
2018-06-12 - international - ODI - female - 1126718 - England vs South Africa
2018-06-10 - international - T20 - female - 1148063 - India vs Bangladesh
2018-06-10 - international - ODI - female - 1145892 - New Zealand vs Ireland
2018-06-09 - international - T20 - female - 1148062 - Bangladesh vs Malaysia
2018-06-09 - international - T20 - female - 1148061 - Sri Lanka vs Thailand
2018-06-09 - international - T20 - female - 1148060 - Pakistan vs India
2018-06-09 - international - ODI - female - 1126717 - England vs South Africa
2018-06-07 - international - T20 - female - 1148059 - Sri Lanka vs India
2018-06-07 - international - T20 - female - 1148058 - Pakistan vs Malaysia
2018-06-07 - international - T20 - female - 1148057 - Thailand vs Bangladesh
2018-06-06 - international - T20 - female - 1148056 - India vs Bangladesh
2018-06-06 - international - T20 - female - 1148055 - Malaysia vs Thailand
2018-06-06 - international - T20 - female - 1148054 - Pakistan vs Sri Lanka
2018-06-06 - international - T20 - female - 1145890 - Ireland vs New Zealand
2018-06-04 - international - T20 - female - 1148053 - Sri Lanka vs Malaysia
2018-06-04 - international - T20 - female - 1148052 - India vs Thailand
2018-06-04 - international - T20 - female - 1148051 - Pakistan vs Bangladesh
2018-06-03 - international - T20 - female - 1148050 - Thailand vs Pakistan
2018-06-03 - international - T20 - female - 1148048 - India vs Malaysia
2018-05-22 - club - WTC - female - 1146789 - Trailblazers vs Supernovas
2018-05-20 - international - T20 - female - 1144442 - South Africa vs Bangladesh
2018-05-19 - international - T20 - female - 1144441 - South Africa vs Bangladesh
2018-05-14 - international - ODI - female - 1144439 - Bangladesh vs South Africa
2018-05-11 - international - ODI - female - 1144438 - South Africa vs Bangladesh
2018-05-09 - international - ODI - female - 1144437 - Bangladesh vs South Africa
2018-05-06 - international - ODI - female - 1144436 - Bangladesh vs South Africa
2018-05-04 - international - ODI - female - 1144435 - South Africa vs Bangladesh
2018-04-12 - international - ODI - female - 1131778 - England vs India
2018-04-09 - international - ODI - female - 1131777 - India vs England
2018-03-31 - international - T20 - female - 1131241 - Australia vs England
2018-03-30 - international - T20 - female - 1138203 - Pakistan vs Sri Lanka
2018-03-29 - international - T20 - female - 1131240 - England vs India
2018-03-28 - international - T20 - female - 1138202 - Sri Lanka vs Pakistan
2018-03-28 - international - T20 - female - 1131239 - England vs Australia
2018-03-26 - international - T20 - female - 1131238 - Australia vs India
2018-03-25 - international - T20 - female - 1138198 - West Indies vs New Zealand
2018-03-25 - international - T20 - female - 1131237 - India vs England
2018-03-24 - international - ODI - female - 1138201 - Pakistan vs Sri Lanka
2018-03-23 - international - T20 - female - 1131236 - Australia vs England
2018-03-22 - international - T20 - female - 1131235 - India vs Australia
2018-03-22 - international - ODI - female - 1138200 - Pakistan vs Sri Lanka
2018-03-20 - international - T20 - female - 1138196 - New Zealand vs West Indies
2018-03-16 - international - T20 - female - 1138195 - New Zealand vs West Indies
2018-03-15 - international - ODI - female - 1131233 - Australia vs India
2018-03-14 - international - T20 - female - 1138194 - New Zealand vs West Indies
2018-03-12 - international - ODI - female - 1131232 - India vs Australia
2018-03-11 - international - ODI - female - 1138193 - New Zealand vs West Indies
2018-03-08 - international - ODI - female - 1138192 - West Indies vs New Zealand
2018-03-04 - international - ODI - female - 1138191 - New Zealand vs West Indies
2018-02-24 - international - T20 - female - 1123210 - India vs South Africa
2018-02-21 - international - T20 - female - 1123209 - South Africa vs India
2018-02-18 - international - T20 - female - 1123208 - India vs South Africa
2018-02-16 - international - T20 - female - 1123207 - South Africa vs India
2018-02-13 - international - T20 - female - 1123206 - South Africa vs India
2018-02-10 - international - ODI - female - 1123205 - India vs South Africa
2018-02-07 - international - ODI - female - 1123204 - India vs South Africa
2018-02-04 - club - WBB - female - 1118530 - Perth Scorchers vs Sydney Sixers
2018-02-02 - club - WBB - female - 1118529 - Sydney Sixers vs Adelaide Strikers
2018-02-01 - club - WBB - female - 1118528 - Perth Scorchers vs Sydney Thunder
2018-01-28 - club - WBB - female - 1118527 - Sydney Thunder vs Brisbane Heat
2018-01-28 - club - WBB - female - 1118526 - Adelaide Strikers vs Sydney Sixers
2018-01-28 - club - WBB - female - 1118525 - Melbourne Renegades vs Perth Scorchers
2018-01-28 - club - WBB - female - 1118524 - Hobart Hurricanes vs Melbourne Stars
2018-01-27 - club - WBB - female - 1118523 - Sydney Thunder vs Brisbane Heat
2018-01-27 - club - WBB - female - 1118522 - Perth Scorchers vs Melbourne Renegades
2018-01-27 - club - WBB - female - 1118521 - Adelaide Strikers vs Sydney Sixers
2018-01-27 - club - WBB - female - 1118520 - Hobart Hurricanes vs Melbourne Stars
2018-01-24 - club - WBB - female - 1118519 - Melbourne Renegades vs Sydney Thunder
2018-01-21 - club - WBB - female - 1118517 - Melbourne Stars vs Sydney Sixers
2018-01-21 - club - WBB - female - 1118516 - Hobart Hurricanes vs Perth Scorchers
2018-01-19 - club - WBB - female - 1118512 - Sydney Sixers vs Brisbane Heat
2018-01-15 - club - WBB - female - 1118510 - Hobart Hurricanes vs Melbourne Renegades
2018-01-14 - club - WBB - female - 1118509 - Adelaide Strikers vs Perth Scorchers
2018-01-13 - club - WBB - female - 1118507 - Brisbane Heat vs Melbourne Stars
2018-01-13 - club - WBB - female - 1118506 - Sydney Sixers vs Sydney Thunder
2018-01-13 - club - WBB - female - 1118505 - Perth Scorchers vs Adelaide Strikers
2018-01-12 - club - WBB - female - 1118504 - Melbourne Stars vs Brisbane Heat
2018-01-09 - club - WBB - female - 1118503 - Melbourne Stars vs Adelaide Strikers
2018-01-08 - club - WBB - female - 1118502 - Sydney Thunder vs Perth Scorchers
2018-01-08 - club - WBB - female - 1118501 - Brisbane Heat vs Hobart Hurricanes
2018-01-07 - club - WBB - female - 1118499 - Hobart Hurricanes vs Brisbane Heat
2018-01-06 - club - WBB - female - 1118498 - Melbourne Renegades vs Melbourne Stars
2018-01-05 - club - WBB - female - 1118497 - Adelaide Strikers vs Melbourne Stars
2018-01-02 - club - WBB - female - 1118495 - Sydney Sixers vs Melbourne Renegades
2017-12-31 - club - WBB - female - 1118494 - Adelaide Strikers vs Brisbane Heat
2017-12-31 - club - WBB - female - 1118493 - Hobart Hurricanes vs Sydney Thunder
2017-12-30 - club - WBB - female - 1118491 - Sydney Sixers vs Perth Scorchers
2017-12-29 - club - WBB - female - 1118490 - Adelaide Strikers vs Brisbane Heat
2017-12-27 - club - WBB - female - 1118489 - Melbourne Stars vs Perth Scorchers
2017-12-26 - club - WBB - female - 1118488 - Melbourne Stars vs Perth Scorchers
2017-12-23 - club - WBB - female - 1118487 - Brisbane Heat vs Melbourne Renegades
2017-12-22 - club - WBB - female - 1118485 - Melbourne Renegades vs Brisbane Heat
2017-12-17 - club - WBB - female - 1118484 - Melbourne Renegades vs Adelaide Strikers
2017-12-17 - club - WBB - female - 1118483 - Sydney Sixers vs Hobart Hurricanes
2017-12-16 - club - WBB - female - 1118482 - Adelaide Strikers vs Melbourne Renegades
2017-12-15 - club - WBB - female - 1118480 - Perth Scorchers vs Brisbane Heat
2017-12-12 - club - WBB - female - 1118479 - Melbourne Stars vs Sydney Thunder
2017-12-12 - club - WBB - female - 1118478 - Sydney Sixers vs Perth Scorchers
2017-12-10 - club - WBB - female - 1118477 - Sydney Thunder vs Sydney Sixers
2017-12-10 - club - WBB - female - 1118475 - Perth Scorchers vs Brisbane Heat
2017-12-09 - club - WBB - female - 1118474 - Sydney Sixers vs Melbourne Stars
2017-12-09 - club - WBB - female - 1118473 - Adelaide Strikers vs Hobart Hurricanes
2017-12-09 - club - WBB - female - 1118472 - Sydney Thunder vs Melbourne Renegades
2017-11-27 - international - IT20 - female - 1123902 - Thailand vs United Arab Emirates
2017-11-27 - international - IT20 - female - 1123901 - Nepal vs Hong Kong
2017-11-26 - international - IT20 - female - 1123900 - Hong Kong vs Thailand
2017-11-26 - international - IT20 - female - 1123899 - United Arab Emirates vs Malaysia
2017-11-26 - international - IT20 - female - 1123898 - Nepal vs China
2017-11-24 - international - IT20 - female - 1121068 - China vs Thailand
2017-11-24 - international - IT20 - female - 1121067 - Hong Kong vs United Arab Emirates
2017-11-24 - international - IT20 - female - 1121066 - Nepal vs Malaysia
2017-11-23 - international - IT20 - female - 1121064 - United Arab Emirates vs Nepal
2017-11-23 - international - IT20 - female - 1121063 - Hong Kong vs China
2017-11-21 - international - T20 - female - 1086069 - Australia vs England
2017-11-21 - international - IT20 - female - 1121062 - United Arab Emirates vs Thailand
2017-11-21 - international - IT20 - female - 1121060 - China vs Malaysia
2017-11-20 - international - IT20 - female - 1121059 - Thailand vs Nepal
2017-11-20 - international - IT20 - female - 1121058 - United Arab Emirates vs China
2017-11-20 - international - IT20 - female - 1121057 - Hong Kong vs Malaysia
2017-11-19 - international - T20 - female - 1086068 - England vs Australia
2017-11-17 - international - T20 - female - 1086067 - England vs Australia
2017-11-14 - international - T20 - female - 1122910 - Pakistan vs New Zealand
2017-11-12 - international - T20 - female - 1122909 - New Zealand vs Pakistan
2017-11-09 - international - Test - female - 1086066 - England vs Australia
2017-11-09 - international - T20 - female - 1122908 - New Zealand vs Pakistan
2017-11-05 - international - ODI - female - 1122906 - New Zealand vs Pakistan
2017-11-02 - international - ODI - female - 1122905 - Pakistan vs New Zealand
2017-10-31 - international - ODI - female - 1122904 - New Zealand vs Pakistan
2017-10-26 - international - ODI - female - 1086064 - Australia vs England
2017-10-22 - international - ODI - female - 1086063 - England vs Australia
2017-10-21 - international - T20 - female - 1122902 - West Indies vs Sri Lanka
2017-09-16 - international - IT20 - female - 1120539 - Zimbabwe vs Uganda
2017-09-15 - international - IT20 - female - 1120538 - Kenya vs Uganda
2017-09-15 - international - IT20 - female - 1120537 - Tanzania vs Namibia
2017-09-13 - international - IT20 - female - 1118925 - Zimbabwe vs Uganda
2017-09-13 - international - IT20 - female - 1118924 - Kenya vs Namibia
2017-09-12 - international - IT20 - female - 1118923 - Tanzania vs Namibia
2017-09-12 - international - IT20 - female - 1118922 - Zimbabwe vs Kenya
2017-09-10 - international - IT20 - female - 1118920 - Kenya vs Uganda
2017-09-09 - international - IT20 - female - 1118919 - Namibia vs Zimbabwe
2017-09-09 - international - IT20 - female - 1118918 - Tanzania vs Uganda
2017-09-08 - international - IT20 - female - 1118917 - Tanzania vs Kenya
2017-09-08 - international - IT20 - female - 1118916 - Uganda vs Namibia
2017-09-01 - club - WSL - female - 1093492 - Southern Vipers vs Western Storm
2017-09-01 - club - WSL - female - 1093491 - Surrey Stars vs Western Storm
2017-08-26 - club - WSL - female - 1093490 - Lancashire Thunder vs Western Storm
2017-08-26 - club - WSL - female - 1093489 - Loughborough Lightning vs Surrey Stars
2017-08-26 - club - WSL - female - 1093488 - Southern Vipers vs Yorkshire Diamonds
2017-08-23 - club - WSL - female - 1093487 - Surrey Stars vs Western Storm
2017-08-23 - club - WSL - female - 1093486 - Lancashire Thunder vs Southern Vipers
2017-08-20 - club - WSL - female - 1093485 - Yorkshire Diamonds vs Western Storm
2017-08-20 - club - WSL - female - 1093484 - Surrey Stars vs Southern Vipers
2017-08-20 - club - WSL - female - 1093483 - Loughborough Lightning vs Lancashire Thunder
2017-08-19 - international - IT20 - female - 1116060 - Netherlands vs United States of America
2017-08-18 - international - IT20 - female - 1116061 - Netherlands vs Scotland
2017-08-18 - club - WSL - female - 1093482 - Yorkshire Diamonds vs Loughborough Lightning
2017-08-16 - club - WSL - female - 1093481 - Surrey Stars vs Lancashire Thunder
2017-08-15 - club - WSL - female - 1093480 - Southern Vipers vs Loughborough Lightning
2017-08-14 - international - IT20 - female - 1116056 - Netherlands vs Scotland
2017-08-13 - club - WSL - female - 1093479 - Yorkshire Diamonds vs Surrey Stars
2017-08-12 - club - WSL - female - 1093478 - Loughborough Lightning vs Western Storm
2017-08-11 - club - WSL - female - 1093477 - Yorkshire Diamonds vs Lancashire Thunder
2017-08-10 - club - WSL - female - 1093476 - Western Storm vs Southern Vipers
2017-07-23 - international - ODI - female - 1085975 - England vs India
2017-07-20 - international - ODI - female - 1085974 - India vs Australia
2017-07-18 - international - ODI - female - 1085973 - South Africa vs England
2017-07-15 - international - ODI - female - 1085972 - Pakistan vs Sri Lanka
2017-07-15 - international - ODI - female - 1085971 - India vs New Zealand
2017-07-15 - international - ODI - female - 1085970 - England vs West Indies
2017-07-15 - international - ODI - female - 1085969 - Australia vs South Africa
2017-07-12 - international - ODI - female - 1085968 - England vs New Zealand
2017-07-12 - international - ODI - female - 1085967 - Australia vs India
2017-07-12 - international - ODI - female - 1085966 - South Africa vs Sri Lanka
2017-07-11 - international - ODI - female - 1085965 - Pakistan vs West Indies
2017-07-09 - international - ODI - female - 1085964 - Sri Lanka vs West Indies
2017-07-09 - international - ODI - female - 1085963 - England vs Australia
2017-07-08 - international - ODI - female - 1085962 - India vs South Africa
2017-07-08 - international - ODI - female - 1085961 - New Zealand vs Pakistan
2017-07-06 - international - ODI - female - 1085960 - New Zealand vs West Indies
2017-07-05 - international - ODI - female - 1085959 - Australia vs Pakistan
2017-07-05 - international - ODI - female - 1085958 - India vs Sri Lanka
2017-07-05 - international - ODI - female - 1085957 - England vs South Africa
2017-07-02 - international - ODI - female - 1085956 - South Africa vs West Indies
2017-07-02 - international - ODI - female - 1085955 - India vs Pakistan
2017-07-02 - international - ODI - female - 1085954 - Australia vs New Zealand
2017-07-02 - international - ODI - female - 1085953 - England vs Sri Lanka
2017-06-29 - international - ODI - female - 1085952 - Australia vs Sri Lanka
2017-06-29 - international - ODI - female - 1085951 - India vs West Indies
2017-06-27 - international - ODI - female - 1085949 - England vs Pakistan
2017-06-26 - international - ODI - female - 1085948 - Australia vs West Indies
2017-06-25 - international - ODI - female - 1085947 - Pakistan vs South Africa
2017-06-24 - international - ODI - female - 1085946 - England vs India
2017-06-24 - international - ODI - female - 1085945 - New Zealand vs Sri Lanka
2017-05-21 - international - ODI - female - 1089533 - South Africa vs India
2017-05-19 - international - ODM - female - 1089531 - India vs Zimbabwe
2017-05-19 - international - ODI - female - 1089530 - South Africa vs Ireland
2017-05-17 - international - ODM - female - 1089529 - Ireland vs Zimbabwe
2017-05-17 - international - ODI - female - 1089528 - South Africa vs India
2017-05-15 - international - ODM - female - 1089526 - South Africa vs Zimbabwe
2017-05-11 - international - ODM - female - 1089525 - India vs Zimbabwe
2017-05-11 - international - ODI - female - 1089524 - South Africa vs Ireland
2017-05-09 - international - ODM - female - 1089523 - Ireland vs Zimbabwe
2017-05-09 - international - ODI - female - 1089522 - South Africa vs India
2017-05-07 - international - ODM - female - 1089520 - South Africa vs Zimbabwe
2017-05-07 - international - ODI - female - 1089521 - India vs Ireland
2017-05-04 - international - IT20 - female - 1090896 - Vanuatu vs Japan
2017-05-04 - international - IT20 - female - 1090895 - Samoa vs Papua New Guinea
2017-05-03 - international - IT20 - female - 1090894 - Vanuatu vs Samoa
2017-05-02 - international - IT20 - female - 1090892 - Vanuatu vs Papua New Guinea
2017-05-02 - international - IT20 - female - 1090891 - Japan vs Samoa
2017-05-01 - international - IT20 - female - 1090889 - Samoa vs Vanuatu
2017-04-30 - international - IT20 - female - 1090890 - Papua New Guinea vs Japan
2017-04-29 - international - IT20 - female - 1090888 - Japan vs Vanuatu
2017-04-28 - international - IT20 - female - 1090886 - Vanuatu vs Papua New Guinea
2017-04-28 - international - IT20 - female - 1090885 - Japan vs Samoa
2017-03-05 - international - ODI - female - 1050627 - New Zealand vs Australia
2017-03-02 - international - ODI - female - 1050625 - New Zealand vs Australia
2017-02-26 - international - ODI - female - 1050623 - New Zealand vs Australia
2017-02-22 - international - T20 - female - 1043993 - Australia vs New Zealand
2017-02-21 - international - ODI - female - 1073430 - India vs South Africa
2017-02-19 - international - T20 - female - 1043991 - Australia vs New Zealand
2017-02-19 - international - ODI - female - 1073429 - Ireland vs South Africa
2017-02-19 - international - ODI - female - 1073428 - Sri Lanka vs Bangladesh
2017-02-19 - international - ODI - female - 1073427 - India vs Pakistan
2017-02-17 - international - T20 - female - 1043989 - Australia vs New Zealand
2017-02-17 - international - ODI - female - 1073426 - Ireland vs Pakistan
2017-02-17 - international - ODI - female - 1073425 - Bangladesh vs India
2017-02-17 - international - ODI - female - 1073424 - Sri Lanka vs South Africa
2017-02-15 - international - ODI - female - 1073423 - Bangladesh vs Ireland
2017-02-15 - international - ODI - female - 1073422 - Sri Lanka vs Pakistan
2017-02-15 - international - ODI - female - 1073421 - India vs South Africa
2017-02-13 - international - ODM - female - 1073420 - Pakistan vs Scotland
2017-02-13 - international - ODM - female - 1073419 - Papua New Guinea vs South Africa
2017-02-13 - international - ODM - female - 1073418 - Sri Lanka vs Thailand
2017-02-13 - international - ODM - female - 1073417 - India vs Zimbabwe
2017-02-11 - international - ODM - female - 1073416 - Ireland vs Thailand
2017-02-11 - international - ODM - female - 1073415 - Sri Lanka vs Zimbabwe
2017-02-11 - international - ODM - female - 1073414 - Papua New Guinea vs Scotland
2017-02-11 - international - ODI - female - 1073413 - Bangladesh vs South Africa
2017-02-10 - international - ODM - female - 1073412 - Thailand vs Zimbabwe
2017-02-10 - international - ODM - female - 1073410 - Bangladesh vs Scotland
2017-02-10 - international - ODM - female - 1073409 - Papua New Guinea vs Pakistan
2017-02-10 - international - ODI - female - 1073411 - India vs Ireland
2017-02-08 - international - ODM - female - 1073407 - Scotland vs South Africa
2017-02-08 - international - ODM - female - 1073406 - India vs Thailand
2017-02-08 - international - ODI - female - 1073408 - Bangladesh vs Pakistan
2017-02-08 - international - ODI - female - 1073405 - Sri Lanka vs Ireland
2017-02-07 - international - ODM - female - 1073404 - Bangladesh vs Papua New Guinea
2017-02-07 - international - ODM - female - 1073402 - Ireland vs Zimbabwe
2017-02-07 - international - ODI - female - 1073403 - Pakistan vs South Africa
2017-02-07 - international - ODI - female - 1073401 - Sri Lanka vs India
2017-01-28 - club - WBB - female - 1064720 - Sydney Sixers vs Perth Scorchers
2017-01-25 - club - WBB - female - 1064719 - Sydney Sixers vs Hobart Hurricanes
2017-01-24 - club - WBB - female - 1064718 - Brisbane Heat vs Perth Scorchers
2017-01-21 - club - WBB - female - 1064717 - Melbourne Stars vs Hobart Hurricanes
2017-01-21 - club - WBB - female - 1064716 - Sydney Sixers vs Melbourne Renegades
2017-01-20 - international - ODI - female - 1041525 - Bangladesh vs South Africa
2017-01-20 - club - WBB - female - 1064713 - Hobart Hurricanes vs Melbourne Stars
2017-01-20 - club - WBB - female - 1064712 - Sydney Sixers vs Melbourne Renegades
2017-01-20 - club - WBB - female - 1064711 - Perth Scorchers vs Sydney Thunder
2017-01-20 - club - WBB - female - 1064710 - Adelaide Strikers vs Brisbane Heat
2017-01-18 - international - ODI - female - 1041523 - Bangladesh vs South Africa
2017-01-16 - club - WBB - female - 1064709 - Sydney Thunder vs Hobart Hurricanes
2017-01-15 - club - WBB - female - 1064707 - Perth Scorchers vs Melbourne Stars
2017-01-14 - club - WBB - female - 1064706 - Sydney Sixers vs Sydney Thunder
2017-01-14 - club - WBB - female - 1064705 - Melbourne Renegades vs Brisbane Heat
2017-01-14 - club - WBB - female - 1064704 - Adelaide Strikers vs Perth Scorchers
2017-01-13 - club - WBB - female - 1064703 - Sydney Sixers vs Hobart Hurricanes
2017-01-13 - club - WBB - female - 1064702 - Melbourne Stars vs Adelaide Strikers
2017-01-10 - club - WBB - female - 1064697 - Adelaide Strikers vs Melbourne Stars
2017-01-09 - club - WBB - female - 1064701 - Perth Scorchers vs Sydney Sixers
2017-01-09 - club - WBB - female - 1064700 - Brisbane Heat vs Hobart Hurricanes
2017-01-08 - club - WBB - female - 1064698 - Brisbane Heat vs Hobart Hurricanes
2017-01-07 - club - WBB - female - 1064696 - Melbourne Stars vs Melbourne Renegades
2017-01-05 - club - WBB - female - 1064695 - Hobart Hurricanes vs Sydney Thunder
2017-01-04 - club - WBB - female - 1023715 - Perth Scorchers vs Melbourne Renegades
2017-01-03 - club - WBB - female - 1023711 - Adelaide Strikers vs Sydney Sixers
2017-01-02 - club - WBB - female - 1023709 - Sydney Thunder vs Brisbane Heat
2017-01-02 - club - WBB - female - 1023707 - Sydney Sixers vs Adelaide Strikers
2017-01-01 - club - WBB - female - 1023705 - Melbourne Stars vs Melbourne Renegades
2016-12-31 - club - WBB - female - 1023703 - Adelaide Strikers vs Perth Scorchers
2016-12-29 - club - WBB - female - 1023701 - Hobart Hurricanes vs Sydney Sixers
2016-12-28 - club - WBB - female - 1023697 - Sydney Sixers vs Sydney Thunder
2016-12-27 - club - WBB - female - 1023693 - Brisbane Heat vs Melbourne Stars
2016-12-26 - club - WBB - female - 1023687 - Melbourne Stars vs Brisbane Heat
2016-12-18 - club - WBB - female - 1023681 - Sydney Sixers vs Melbourne Stars
2016-12-18 - club - WBB - female - 1023679 - Hobart Hurricanes vs Melbourne Renegades
2016-12-17 - club - WBB - female - 1023677 - Brisbane Heat vs Perth Scorchers
2016-12-17 - club - WBB - female - 1023675 - Sydney Thunder vs Adelaide Strikers
2016-12-17 - club - WBB - female - 1023673 - Sydney Sixers vs Melbourne Stars
2016-12-17 - club - WBB - female - 1023671 - Hobart Hurricanes vs Melbourne Renegades
2016-12-13 - club - WBB - female - 1023667 - Melbourne Stars vs Sydney Thunder
2016-12-11 - club - WBB - female - 1023661 - Perth Scorchers vs Hobart Hurricanes
2016-12-11 - club - WBB - female - 1023659 - Adelaide Strikers vs Melbourne Renegades
2016-12-10 - club - WBB - female - 1023655 - Adelaide Strikers vs Melbourne Renegades
2016-12-04 - international - T20 - female - 1065348 - India vs Pakistan
2016-11-29 - international - ODI - female - 1043961 - Australia vs South Africa
2016-11-21 - international - T20 - female - 1050615 - New Zealand vs Pakistan
2016-11-20 - international - ODI - female - 1043955 - Australia vs South Africa
2016-11-18 - international - ODI - female - 1043953 - Australia vs South Africa
2016-11-17 - international - ODI - female - 1059196 - Sri Lanka vs England
2016-11-17 - international - ODI - female - 1050611 - New Zealand vs Pakistan
2016-11-15 - international - ODI - female - 1059195 - Sri Lanka vs England
2016-11-13 - international - ODI - female - 1050609 - New Zealand vs Pakistan
2016-11-11 - international - ODI - female - 1050607 - New Zealand vs Pakistan
2016-11-09 - international - ODI - female - 1062580 - Sri Lanka vs England
2016-10-24 - international - ODI - female - 935823 - South Africa vs New Zealand
2016-10-22 - international - ODI - female - 935821 - South Africa vs New Zealand
2016-10-19 - international - ODI - female - 935819 - South Africa vs New Zealand
2016-10-17 - international - ODI - female - 935817 - South Africa vs New Zealand
2016-10-11 - international - ODI - female - 935813 - South Africa vs New Zealand
2016-09-27 - international - T20 - female - 1044211 - Sri Lanka vs Australia
2016-09-25 - international - ODI - female - 1044209 - Sri Lanka vs Australia
2016-09-18 - international - ODI - female - 1044203 - Sri Lanka vs Australia
2016-09-05 - international - T20 - female - 962023 - Ireland vs Bangladesh
2016-08-28 - international - IT20 - female - 1049633 - Malaysia vs Singapore
2016-08-27 - international - IT20 - female - 1049631 - Malaysia vs Singapore
2016-08-26 - international - IT20 - female - 1049617 - Malaysia vs Singapore
2016-08-21 - club - WSL - female - 1035537 - Western Storm vs Southern Vipers
2016-08-21 - club - WSL - female - 1035535 - Loughborough Lightning vs Western Storm
2016-08-14 - club - WSL - female - 993671 - Yorkshire Diamonds vs Western Storm
2016-08-14 - club - WSL - female - 993669 - Southern Vipers vs Loughborough Lightning
2016-08-12 - club - WSL - female - 993665 - Southern Vipers vs Western Storm
2016-08-12 - club - WSL - female - 993663 - Loughborough Lightning vs Surrey Stars
2016-08-11 - international - ODI - female - 962017 - Ireland vs South Africa
2016-08-09 - club - WSL - female - 993661 - Lancashire Thunder vs Surrey Stars
2016-08-08 - club - WSL - female - 993659 - Southern Vipers vs Yorkshire Diamonds
2016-08-07 - club - WSL - female - 993657 - Surrey Stars vs Western Storm
2016-08-05 - club - WSL - female - 993655 - Loughborough Lightning vs Western Storm
2016-08-05 - club - WSL - female - 993653 - Southern Vipers vs Lancashire Thunder
2016-08-04 - club - WSL - female - 993651 - Yorkshire Diamonds vs Surrey Stars
2016-08-03 - club - WSL - female - 993649 - Lancashire Thunder vs Loughborough Lightning
2016-07-31 - club - WSL - female - 993647 - Lancashire Thunder vs Western Storm
2016-07-31 - club - WSL - female - 993645 - Surrey Stars vs Southern Vipers
2016-07-30 - club - WSL - female - 993643 - Loughborough Lightning vs Yorkshire Diamonds
2016-07-15 - international - ODM - female - 1033707 - Netherlands vs Scotland
2016-07-07 - international - T20 - female - 946555 - England vs Pakistan
2016-07-05 - international - T20 - female - 946553 - England vs Pakistan
2016-07-03 - international - T20 - female - 946551 - England vs Pakistan
2016-06-27 - international - ODI - female - 946549 - England vs Pakistan
2016-06-22 - international - ODI - female - 946547 - England vs Pakistan
2016-06-20 - international - ODI - female - 946545 - England vs Pakistan
2016-04-03 - international - T20 - female - 951419 - Australia vs West Indies
2016-03-31 - international - T20 - female - 951417 - New Zealand vs West Indies
2016-03-30 - international - T20 - female - 951415 - Australia vs England
2016-03-28 - international - T20 - female - 951413 - South Africa vs Sri Lanka
2016-03-27 - international - T20 - female - 951411 - England vs Pakistan
2016-03-27 - international - T20 - female - 951409 - India vs West Indies
2016-03-26 - international - T20 - female - 951407 - New Zealand vs South Africa
2016-03-26 - international - T20 - female - 951405 - Australia vs Ireland
2016-03-24 - international - T20 - female - 951403 - Bangladesh vs Pakistan
2016-03-24 - international - T20 - female - 951401 - Australia vs Sri Lanka
2016-03-24 - international - T20 - female - 951399 - England vs West Indies
2016-03-23 - international - T20 - female - 951397 - Ireland vs South Africa
2016-03-22 - international - T20 - female - 951395 - India vs England
2016-03-21 - international - T20 - female - 951393 - Australia vs New Zealand
2016-03-20 - international - T20 - female - 951391 - Sri Lanka vs Ireland
2016-03-20 - international - T20 - female - 951389 - Bangladesh vs West Indies
2016-03-19 - international - T20 - female - 951387 - India vs Pakistan
2016-03-18 - international - T20 - female - 951385 - Australia vs South Africa
2016-03-18 - international - T20 - female - 951383 - Ireland vs New Zealand
2016-03-17 - international - T20 - female - 951381 - Bangladesh vs England
2016-03-16 - international - T20 - female - 951379 - Pakistan vs West Indies
2016-03-15 - international - T20 - female - 951377 - New Zealand vs Sri Lanka
2016-03-15 - international - T20 - female - 951375 - India vs Bangladesh
2016-03-09 - international - T20 - female - 907399 - South Africa vs West Indies
2016-03-04 - international - T20 - female - 907395 - South Africa vs West Indies
2016-02-29 - international - ODI - female - 907393 - South Africa vs West Indies
2016-02-27 - international - ODI - female - 907391 - South Africa vs West Indies
2016-02-24 - international - ODI - female - 907389 - South Africa vs West Indies
2016-02-22 - international - ODI - female - 916663 - New Zealand vs Australia
2016-02-21 - international - T20 - female - 907385 - South Africa vs England
2016-02-20 - international - ODI - female - 916661 - New Zealand vs Australia
2016-02-18 - international - T20 - female - 907381 - South Africa vs England
2016-02-07 - international - ODI - female - 907375 - South Africa vs England
2016-02-07 - international - ODI - female - 895797 - Australia vs India
2016-01-31 - international - T20 - female - 895791 - Australia vs India
2016-01-29 - international - T20 - female - 895789 - Australia vs India
2016-01-22 - club - WBB - female - 896549 - Hobart Hurricanes vs Sydney Sixers
2016-01-21 - club - WBB - female - 896547 - Sydney Thunder vs Perth Scorchers
2016-01-17 - club - WBB - female - 896545 - Melbourne Renegades vs Perth Scorchers
2016-01-15 - club - WBB - female - 896527 - Sydney Sixers vs Hobart Hurricanes
2015-12-31 - club - WBB - female - 896493 - Adelaide Strikers vs Perth Scorchers
2015-12-27 - club - WBB - female - 896487 - Melbourne Stars vs Perth Scorchers
2015-12-26 - club - WBB - female - 896485 - Melbourne Stars vs Perth Scorchers
2015-12-19 - club - WBB - female - 896471 - Sydney Sixers vs Melbourne Stars
2015-12-19 - club - WBB - female - 896467 - Adelaide Strikers vs Brisbane Heat
2015-12-18 - club - WBB - female - 896463 - Sydney Sixers vs Melbourne Stars
2015-12-05 - international - T20 - female - 881755 - Bangladesh vs Ireland
2015-12-05 - international - IT20 - female - 881761 - Scotland vs Zimbabwe
2015-12-05 - international - IT20 - female - 881759 - Thailand vs Netherlands
2015-12-05 - international - IT20 - female - 881757 - China vs Papua New Guinea
2015-12-03 - international - IT20 - female - 881751 - Ireland vs Scotland
2015-12-03 - international - IT20 - female - 881749 - Netherlands vs Papua New Guinea
2015-12-03 - international - IT20 - female - 881747 - Bangladesh vs Zimbabwe
2015-12-01 - international - IT20 - female - 881745 - China vs Netherlands
2015-12-01 - international - IT20 - female - 881743 - Ireland vs Zimbabwe
2015-12-01 - international - IT20 - female - 881741 - Bangladesh vs Papua New Guinea
2015-12-01 - international - IT20 - female - 881739 - Thailand vs Scotland
2015-11-29 - international - IT20 - female - 881737 - Thailand vs Papua New Guinea
2015-11-29 - international - IT20 - female - 881735 - Netherlands vs Zimbabwe
2015-11-28 - international - IT20 - female - 881729 - China vs Zimbabwe
2015-11-28 - international - IT20 - female - 881725 - Ireland vs Netherlands
2015-11-28 - international - IT20 - female - 881723 - Thailand vs Bangladesh
2015-11-19 - international - IT20 - female - 940413 - Bangladesh vs Zimbabwe
2015-11-17 - international - IT20 - female - 940409 - Bangladesh vs Zimbabwe
2015-11-05 - international - ODI - female - 916647 - New Zealand vs Sri Lanka
2015-11-03 - international - ODI - female - 916645 - New Zealand vs Sri Lanka
2015-10-29 - international - T20 - female - 892043 - West Indies vs Pakistan
2015-10-06 - international - ODI - female - 923327 - Pakistan vs Bangladesh
2015-10-01 - international - T20 - female - 923323 - Pakistan vs Bangladesh
2015-09-30 - international - T20 - female - 923321 - Pakistan vs Bangladesh
2015-08-31 - international - T20 - female - 798381 - England vs Australia
2015-08-28 - international - T20 - female - 798379 - England vs Australia
2015-08-26 - international - T20 - female - 798377 - England vs Australia
2015-08-22 - international - T20 - female - 798621 - Ireland vs Australia
2015-08-21 - international - T20 - female - 798619 - Ireland vs Australia
2015-08-19 - international - T20 - female - 798615 - Ireland vs Australia
2015-08-11 - international - Test - female - 798375 - England vs Australia
2015-07-26 - international - ODI - female - 798373 - England vs Australia
2015-07-23 - international - ODI - female - 798371 - England vs Australia
2015-07-21 - international - ODI - female - 798369 - England vs Australia
2015-07-08 - international - ODI - female - 872483 - India vs New Zealand
2015-07-06 - international - ODI - female - 872481 - India vs New Zealand
2015-05-26 - international - T20 - female - 856121 - Sri Lanka vs West Indies
2015-05-25 - international - T20 - female - 856119 - Sri Lanka vs West Indies
2015-05-23 - international - T20 - female - 856117 - Sri Lanka vs West Indies
2015-03-22 - international - T20 - female - 828251 - Pakistan vs South Africa
2015-03-20 - international - T20 - female - 828249 - Pakistan vs South Africa
2015-03-19 - international - T20 - female - 828247 - Pakistan vs South Africa
2015-03-17 - international - ODI - female - 828245 - Pakistan vs South Africa
2015-01-17 - international - T20 - female - 808871 - Pakistan vs Sri Lanka
2015-01-16 - international - T20 - female - 808869 - Pakistan vs Sri Lanka
2015-01-13 - international - ODI - female - 808865 - Pakistan vs Sri Lanka
2015-01-11 - international - ODI - female - 808863 - Pakistan vs Sri Lanka
2014-11-18 - international - ODI - female - 754815 - Australia vs West Indies
2014-11-16 - international - ODI - female - 754813 - Australia vs West Indies
2014-11-13 - international - ODI - female - 754811 - Australia vs West Indies
2014-11-11 - international - ODI - female - 754809 - Australia vs West Indies
2014-11-07 - international - T20 - female - 754805 - Australia vs West Indies
2014-11-02 - international - T20 - female - 754801 - Australia vs West Indies
2014-10-26 - international - T20 - female - 757515 - Sri Lanka vs South Africa
2014-10-25 - international - T20 - female - 757513 - Sri Lanka vs South Africa
2014-10-23 - international - T20 - female - 757511 - Sri Lanka vs South Africa
2014-10-21 - international - ODI - female - 757509 - Sri Lanka vs South Africa
2014-10-19 - international - ODI - female - 757507 - Sri Lanka vs South Africa
2014-10-17 - international - ODI - female - 757505 - Sri Lanka vs South Africa
2014-09-26 - international - IT20 - female - 778015 - Bangladesh vs Pakistan
2014-09-26 - international - IT20 - female - 778013 - China vs Sri Lanka
2014-09-25 - international - IT20 - female - 778011 - Bangladesh vs Sri Lanka
2014-09-25 - international - IT20 - female - 778009 - China vs Pakistan
2014-09-24 - international - IT20 - female - 778005 - Pakistan vs Thailand
2014-09-23 - international - IT20 - female - 778003 - Hong Kong vs Sri Lanka
2014-09-23 - international - IT20 - female - 778001 - China vs Japan
2014-09-22 - international - IT20 - female - 777999 - South Korea vs Hong Kong
2014-09-22 - international - IT20 - female - 777997 - Malaysia vs Nepal
2014-09-21 - international - IT20 - female - 777995 - Nepal vs Thailand
2014-09-20 - international - IT20 - female - 777991 - Malaysia vs Thailand
2014-09-07 - international - T20 - female - 693437 - England vs South Africa
2014-09-05 - international - T20 - female - 754799 - Australia vs Pakistan
2014-09-03 - international - T20 - female - 754797 - Australia vs Pakistan
2014-09-03 - international - T20 - female - 693435 - England vs South Africa
2014-09-01 - international - T20 - female - 693433 - England vs South Africa
2014-08-31 - international - T20 - female - 754795 - Australia vs Pakistan
2014-08-30 - international - T20 - female - 754793 - Australia vs Pakistan
2014-08-26 - international - ODI - female - 754789 - Australia vs Pakistan
2014-08-23 - international - ODI - female - 754787 - Australia vs Pakistan
2014-08-23 - international - ODI - female - 722391 - England vs India
2014-08-21 - international - ODI - female - 722389 - England vs India
2014-08-13 - international - Test - female - 722387 - England vs India
2014-04-06 - international - T20 - female - 683015 - Australia vs England
2014-04-04 - international - T20 - female - 683013 - England vs South Africa
2014-04-03 - international - T20 - female - 718467 - Bangladesh vs Ireland
2014-04-03 - international - T20 - female - 718465 - Pakistan vs Sri Lanka
2014-04-03 - international - T20 - female - 683011 - Australia vs West Indies
2014-04-02 - international - T20 - female - 683009 - India vs Pakistan
2014-04-02 - international - T20 - female - 683007 - New Zealand vs Sri Lanka
2014-04-01 - international - T20 - female - 683005 - India vs West Indies
2014-04-01 - international - T20 - female - 683003 - Bangladesh vs Sri Lanka
2014-03-31 - international - T20 - female - 683001 - New Zealand vs South Africa
2014-03-31 - international - T20 - female - 682999 - Ireland vs Pakistan
2014-03-30 - international - T20 - female - 682997 - England vs Sri Lanka
2014-03-30 - international - T20 - female - 682995 - Bangladesh vs India
2014-03-29 - international - T20 - female - 682993 - Australia vs Pakistan
2014-03-29 - international - T20 - female - 682991 - Ireland vs South Africa
2014-03-28 - international - T20 - female - 682989 - Sri Lanka vs West Indies
2014-03-27 - international - T20 - female - 682985 - New Zealand vs Pakistan
2014-03-26 - international - T20 - female - 682981 - England vs India
2014-03-26 - international - T20 - female - 682979 - Bangladesh vs West Indies
2014-03-25 - international - T20 - female - 682975 - Ireland vs New Zealand
2014-03-24 - international - T20 - female - 682973 - India vs Sri Lanka
2014-03-24 - international - T20 - female - 682971 - England vs West Indies
2014-03-23 - international - T20 - female - 682967 - Australia vs New Zealand
2014-02-02 - international - T20 - female - 666049 - Australia vs England
2014-01-31 - international - T20 - female - 666047 - Australia vs England
2014-01-26 - international - ODI - female - 666043 - Australia vs England
2014-01-24 - international - T20 - female - 698995 - Pakistan vs South Africa
2014-01-23 - international - ODI - female - 666041 - Australia vs England
2014-01-20 - international - T20 - female - 698987 - Ireland vs South Africa
2014-01-19 - international - T20 - female - 698985 - Ireland vs Pakistan
2014-01-19 - international - T20 - female - 698983 - Pakistan vs South Africa
2014-01-19 - international - ODI - female - 666039 - Australia vs England
2013-11-04 - international - T20 - female - 668519 - South Africa vs Sri Lanka
2013-11-02 - international - T20 - female - 668517 - South Africa vs Sri Lanka
2013-10-31 - international - T20 - female - 668515 - South Africa vs Sri Lanka
2013-10-28 - international - ODI - female - 668513 - South Africa vs Sri Lanka
2013-10-26 - international - ODI - female - 668511 - South Africa vs Sri Lanka
2013-09-24 - international - ODI - female - 664303 - South Africa vs Bangladesh
2013-09-20 - international - ODI - female - 664299 - South Africa vs Bangladesh
2013-09-15 - international - T20 - female - 664295 - South Africa vs Bangladesh
2013-09-14 - international - T20 - female - 664293 - South Africa vs Bangladesh
2013-08-31 - international - T20 - female - 593728 - England vs Australia
2013-08-29 - international - T20 - female - 593727 - England vs Australia
2013-08-27 - international - T20 - female - 593726 - England vs Australia
2013-08-25 - international - ODI - female - 593725 - England vs Australia
2013-08-23 - international - ODI - female - 593724 - England vs Australia
2013-08-20 - international - ODI - female - 593723 - England vs Australia
2013-08-11 - international - Test - female - 593722 - England vs Australia
2013-07-31 - international - T20 - female - 640955 - Pakistan vs Sri Lanka
2013-07-31 - international - IT20 - female - 640959 - Ireland vs Netherlands
2013-07-29 - international - T20 - female - 640947 - Ireland vs Pakistan
2013-07-29 - international - IT20 - female - 640951 - Netherlands vs Sri Lanka
2013-07-29 - international - IT20 - female - 640949 - Japan vs Zimbabwe
2013-07-27 - international - IT20 - female - 640943 - Canada vs Japan
2013-07-27 - international - IT20 - female - 640941 - Netherlands vs Pakistan
2013-07-27 - international - IT20 - female - 640939 - Thailand vs Zimbabwe
2013-07-25 - international - IT20 - female - 640935 - Japan vs Sri Lanka
2013-07-25 - international - IT20 - female - 640931 - Ireland vs Canada
2013-07-23 - international - IT20 - female - 640929 - Pakistan vs Thailand
2013-07-19 - international - ODI - female - 644945 - Ireland vs Pakistan
2013-07-17 - international - ODI - female - 644943 - Ireland vs Pakistan
2013-07-16 - international - T20 - female - 644941 - Ireland vs Pakistan
2013-07-05 - international - T20 - female - 627009 - England vs Pakistan
2013-07-05 - international - T20 - female - 627008 - England vs Pakistan
2013-07-03 - international - ODI - female - 627007 - England vs Pakistan
2013-07-01 - international - ODI - female - 627006 - England vs Pakistan
2013-03-08 - international - T20 - female - 603246 - Sri Lanka vs West Indies
2013-03-05 - international - T20 - female - 603244 - Sri Lanka vs West Indies
2013-03-03 - international - T20 - female - 603243 - Sri Lanka vs West Indies
2013-02-26 - international - ODI - female - 603241 - Sri Lanka vs West Indies
2013-02-24 - international - ODI - female - 603240 - Sri Lanka vs West Indies
2013-02-22 - international - ODI - female - 603239 - Sri Lanka vs West Indies
2013-02-17 - international - ODI - female - 594915 - Australia vs West Indies
2013-02-15 - international - ODI - female - 594914 - England vs New Zealand
2013-02-13 - international - ODI - female - 594912 - England vs New Zealand
2013-02-11 - international - ODI - female - 594909 - New Zealand vs West Indies
2013-02-10 - international - ODI - female - 594907 - Australia vs Sri Lanka
2013-02-08 - international - ODI - female - 594904 - Australia vs England
2013-02-05 - international - ODI - female - 594901 - India vs Sri Lanka
2013-02-03 - international - ODI - female - 594897 - India vs England
2013-02-01 - international - ODI - female - 594894 - England vs Sri Lanka
2013-01-31 - international - ODI - female - 594891 - India vs West Indies
2013-01-20 - international - T20 - female - 588499 - West Indies vs South Africa
2013-01-19 - international - T20 - female - 588498 - West Indies vs South Africa
2012-12-19 - international - ODI - female - 584549 - Australia vs New Zealand
2012-12-14 - international - ODI - female - 584547 - Australia vs New Zealand
2012-12-12 - international - ODI - female - 584546 - Australia vs New Zealand
2012-10-31 - international - T20 - female - 584929 - India vs Pakistan
2012-10-30 - international - T20 - female - 584928 - Bangladesh vs Pakistan
2012-10-28 - international - T20 - female - 584924 - India vs Pakistan
2012-10-28 - international - T20 - female - 584923 - Bangladesh vs Sri Lanka
2012-10-07 - international - T20 - female - 533313 - Australia vs England
2012-10-05 - international - T20 - female - 533312 - Australia vs West Indies
2012-10-04 - international - T20 - female - 533311 - England vs New Zealand
2012-10-03 - international - T20 - female - 584772 - Sri Lanka vs India
2012-10-01 - international - T20 - female - 533310 - Australia vs England
2012-10-01 - international - T20 - female - 533309 - India vs Pakistan
2012-09-30 - international - T20 - female - 533308 - Sri Lanka vs New Zealand
2012-09-30 - international - T20 - female - 533307 - South Africa vs West Indies
2012-09-29 - international - T20 - female - 533306 - England vs India
2012-09-29 - international - T20 - female - 533305 - Australia vs Pakistan
2012-09-28 - international - T20 - female - 533304 - Sri Lanka vs West Indies
2012-09-28 - international - T20 - female - 533303 - New Zealand vs South Africa
2012-09-27 - international - T20 - female - 533302 - Australia vs India
2012-09-27 - international - T20 - female - 533301 - England vs Pakistan
2012-09-26 - international - T20 - female - 533300 - New Zealand vs West Indies
2012-09-26 - international - T20 - female - 533299 - Sri Lanka vs South Africa
2012-09-16 - international - T20 - female - 551597 - England vs West Indies
2012-09-15 - international - T20 - female - 551596 - England vs West Indies
2012-09-13 - international - T20 - female - 551595 - England vs West Indies
2012-09-10 - international - T20 - female - 551594 - England vs West Indies
2012-09-08 - international - T20 - female - 551593 - England vs West Indies
2012-09-05 - international - T20 - female - 565845 - England vs Pakistan
2012-09-04 - international - T20 - female - 565844 - England vs Pakistan
2012-07-11 - international - ODI - female - 542856 - England vs India
2012-07-05 - international - ODI - female - 542854 - England vs India
2012-07-04 - international - ODI - female - 542853 - England vs India
2012-07-01 - international - ODI - female - 542852 - England vs India
2012-06-28 - international - T20 - female - 542851 - England vs India
2012-06-26 - international - T20 - female - 542850 - England vs India
2012-02-22 - international - T20 - female - 527690 - New Zealand vs England
2012-02-19 - international - T20 - female - 527689 - New Zealand vs England
2012-02-17 - international - T20 - female - 527688 - New Zealand vs England
2011-10-29 - international - T20 - female - 527683 - South Africa vs England
2011-10-25 - international - ODI - female - 527681 - South Africa vs England
2011-10-23 - international - ODI - female - 527680 - South Africa vs England
2011-10-21 - international - ODI - female - 527679 - South Africa vs England
2011-06-26 - international - T20 - female - 492547 - England vs India
2011-01-22 - international - Test - female - 474625 - England vs Australia
2010-12-30 - international - T20 - female - 476947 - New Zealand vs Australia
2010-05-16 - international - T20 - female - 412718 - Australia vs New Zealand
2010-05-14 - international - T20 - female - 412717 - West Indies vs New Zealand
2010-05-13 - international - T20 - female - 412716 - Australia vs India
2009-10-28 - international - T20 - female - 423391 - South Africa vs West Indies
2009-10-21 - international - ODI - female - 423387 - South Africa vs West Indies
2009-07-10 - international - Test - female - 383288 - Australia vs England
2009-06-29 - international - ODI - female - 383283 - England vs Australia
2009-06-25 - international - T20 - female - 391794 - England vs Australia
2009-06-19 - international - T20 - female - 355989 - England vs Australia
2009-06-18 - international - T20 - female - 355988 - India vs New Zealand
2009-03-10 - international - ODI - female - 357962 - England vs India
2008-05-11 - international - ODI - female - 341306 - India vs Sri Lanka
2008-05-08 - international - ODI - female - 341302 - Sri Lanka vs India
2008-02-22 - international - ODI - female - 312296 - Pakistan vs Netherlands
2008-02-22 - international - ODI - female - 312295 - Ireland vs South Africa
2008-02-21 - international - ODI - female - 312291 - South Africa vs Netherlands
2008-02-15 - international - Test - female - 312450 - Australia vs England
2007-03-05 - international - ODI - female - 276226 - New Zealand vs Australia
2007-01-24 - international - ODI - female - 271466 - Pakistan vs South Africa
2007-01-22 - international - ODI - female - 271465 - South Africa vs Pakistan
2006-08-08 - international - Test - female - 225164 - England vs India
2005-08-24 - international - Test - female - 216932 - Australia vs England
2003-02-22 - international - Test - female - 67517 - Australia vs England
